import 'package:flutter/material.dart';
import '../presentation/splash_screen/splash_screen.dart';
import '../presentation/payment_checkout/payment_checkout.dart';
import '../presentation/course_management/course_management.dart';
import '../presentation/progress_tracking/progress_tracking.dart';
import '../presentation/quiz_screen/quiz_screen.dart';
import '../presentation/admin_dashboard/admin_dashboard.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String splash = '/splash-screen';
  static const String paymentCheckout = '/payment-checkout';
  static const String courseManagement = '/course-management';
  static const String progressTracking = '/progress-tracking';
  static const String quiz = '/quiz-screen';
  static const String adminDashboard = '/admin-dashboard';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SplashScreen(),
    splash: (context) => const SplashScreen(),
    paymentCheckout: (context) => const PaymentCheckout(),
    courseManagement: (context) => const CourseManagement(),
    progressTracking: (context) => const ProgressTracking(),
    quiz: (context) => const QuizScreen(),
    adminDashboard: (context) => const AdminDashboard(),
    // TODO: Add your other routes here
  };
}
