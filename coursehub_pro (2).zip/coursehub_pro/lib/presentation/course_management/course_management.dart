import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/analytics_tab_widget.dart';
import './widgets/content_tab_widget.dart';
import './widgets/course_card_widget.dart';
import './widgets/course_info_tab_widget.dart';
import './widgets/quiz_tab_widget.dart';

class CourseManagement extends StatefulWidget {
  const CourseManagement({Key? key}) : super(key: key);

  @override
  State<CourseManagement> createState() => _CourseManagementState();
}

class _CourseManagementState extends State<CourseManagement>
    with TickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = false;
  bool _isMultiSelectMode = false;
  Set<String> _selectedCourseIds = {};
  Map<String, dynamic>? _selectedCourse;

  // Mock data for courses
  List<Map<String, dynamic>> _courses = [
    {
      'id': '1',
      'title': 'Advanced Flutter Development',
      'description':
          'Master advanced Flutter concepts including state management, animations, and performance optimization.',
      'status': 'Published',
      'enrollmentCount': 245,
      'lastModified': '2025-01-02',
      'thumbnail':
          'https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?w=400&h=300&fit=crop',
      'category': 'Technology',
      'price': 149.99,
    },
    {
      'id': '2',
      'title': 'UI/UX Design Fundamentals',
      'description':
          'Learn the principles of user interface and user experience design for mobile applications.',
      'status': 'Draft',
      'enrollmentCount': 0,
      'lastModified': '2025-01-01',
      'thumbnail':
          'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400&h=300&fit=crop',
      'category': 'Design',
      'price': 99.99,
    },
    {
      'id': '3',
      'title': 'Mobile App Marketing Strategy',
      'description':
          'Comprehensive guide to marketing your mobile applications and growing your user base.',
      'status': 'Published',
      'enrollmentCount': 89,
      'lastModified': '2024-12-28',
      'thumbnail':
          'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop',
      'category': 'Marketing',
      'price': 79.99,
    },
    {
      'id': '4',
      'title': 'Database Design for Mobile Apps',
      'description':
          'Learn how to design efficient databases for mobile applications using SQLite and Firebase.',
      'status': 'Archived',
      'enrollmentCount': 156,
      'lastModified': '2024-12-15',
      'thumbnail':
          'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=400&h=300&fit=crop',
      'category': 'Technology',
      'price': 129.99,
    },
  ];

  // Mock data for course modules
  final List<Map<String, dynamic>> _mockModules = [
    {
      'id': '1',
      'title': 'Introduction to Flutter',
      'type': 'video',
      'duration': '15:30',
      'size': '45.2 MB',
      'filePath': '/videos/intro_flutter.mp4',
      'uploadDate': '2025-01-01T10:00:00Z',
      'status': 'uploaded',
    },
    {
      'id': '2',
      'title': 'State Management Guide',
      'type': 'document',
      'size': '2.1 MB',
      'filePath': '/documents/state_management.pdf',
      'uploadDate': '2025-01-01T11:00:00Z',
      'status': 'uploaded',
      'extension': 'pdf',
    },
  ];

  // Mock data for quizzes
  final List<Map<String, dynamic>> _mockQuizzes = [
    {
      'id': '1',
      'title': 'Flutter Basics Quiz',
      'timeLimit': 30,
      'questions': [
        {
          'id': '1',
          'question': 'What is Flutter?',
          'type': 'multiple_choice',
          'options': [
            'A mobile development framework',
            'A programming language',
            'A database system',
            'An operating system'
          ],
          'correctAnswer': 0,
          'points': 1,
        },
        {
          'id': '2',
          'question': 'Which language is used to write Flutter apps?',
          'type': 'multiple_choice',
          'options': ['Java', 'Kotlin', 'Dart', 'Swift'],
          'correctAnswer': 2,
          'points': 1,
        },
      ],
      'createdAt': '2025-01-01T09:00:00Z',
      'updatedAt': '2025-01-01T09:00:00Z',
    },
  ];

  // Mock analytics data
  final Map<String, dynamic> _mockAnalytics = {
    'totalEnrollments': 245,
    'completionRate': 0.68,
    'averageRating': 4.7,
    'totalRevenue': 36757.55,
    'enrollmentData': [
      {'date': '01/01', 'enrollments': 12},
      {'date': '01/02', 'enrollments': 18},
      {'date': '01/03', 'enrollments': 15},
      {'date': '01/04', 'enrollments': 22},
    ],
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _refreshCourses() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(Duration(seconds: 1));

    setState(() {
      _isLoading = false;
    });
  }

  void _createNewCourse() {
    final newCourse = {
      'id': DateTime.now().millisecondsSinceEpoch.toString(),
      'title': 'New Course',
      'description': '',
      'status': 'Draft',
      'enrollmentCount': 0,
      'lastModified': DateTime.now().toString().split(' ')[0],
      'thumbnail': '',
      'category': 'Technology',
      'price': 0.0,
    };

    setState(() {
      _selectedCourse = newCourse;
    });

    _showCourseDetailView();
  }

  void _showCourseDetailView() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.9,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        builder: (context, scrollController) => Container(
          decoration: BoxDecoration(
            color: AppTheme.lightTheme.scaffoldBackgroundColor,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(
            children: [
              // Handle bar
              Container(
                margin: EdgeInsets.only(top: 2.h),
                width: 12.w,
                height: 0.5.h,
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),

              // Header
              Container(
                padding: EdgeInsets.all(4.w),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      _selectedCourse?['title'] ?? 'Course Details',
                      style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Row(
                      children: [
                        IconButton(
                          onPressed: _previewCourse,
                          icon: CustomIconWidget(
                            iconName: 'visibility',
                            size: 6.w,
                            color: AppTheme.lightTheme.colorScheme.primary,
                          ),
                        ),
                        IconButton(
                          onPressed: () => Navigator.pop(context),
                          icon: CustomIconWidget(
                            iconName: 'close',
                            size: 6.w,
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Tab Bar
              Container(
                margin: EdgeInsets.symmetric(horizontal: 4.w),
                child: TabBar(
                  controller: _tabController,
                  isScrollable: true,
                  tabs: [
                    Tab(text: 'Course Info'),
                    Tab(text: 'Content'),
                    Tab(text: 'Quizzes'),
                    Tab(text: 'Analytics'),
                  ],
                ),
              ),

              // Tab Views
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    CourseInfoTabWidget(
                      courseData: _selectedCourse ?? {},
                      onDataChanged: (updatedData) {
                        setState(() {
                          _selectedCourse = updatedData;
                        });
                        _saveCourseData(updatedData);
                      },
                    ),
                    ContentTabWidget(
                      modules: _mockModules,
                      onModulesChanged: (modules) {
                        // Handle modules update
                      },
                    ),
                    QuizTabWidget(
                      quizzes: _mockQuizzes,
                      onQuizzesChanged: (quizzes) {
                        // Handle quizzes update
                      },
                    ),
                    AnalyticsTabWidget(
                      courseAnalytics: _mockAnalytics,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _saveCourseData(Map<String, dynamic> courseData) {
    final existingIndex =
        _courses.indexWhere((course) => course['id'] == courseData['id']);

    if (existingIndex != -1) {
      setState(() {
        _courses[existingIndex] = courseData;
      });
    } else {
      setState(() {
        _courses.add(courseData);
      });
    }
  }

  void _editCourse(Map<String, dynamic> course) {
    setState(() {
      _selectedCourse = course;
    });
    _showCourseDetailView();
  }

  void _duplicateCourse(Map<String, dynamic> course) {
    final duplicatedCourse = {
      ...course,
      'id': DateTime.now().millisecondsSinceEpoch.toString(),
      'title': '${course['title']} (Copy)',
      'status': 'Draft',
      'enrollmentCount': 0,
      'lastModified': DateTime.now().toString().split(' ')[0],
    };

    setState(() {
      _courses.add(duplicatedCourse);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Course duplicated successfully'),
        backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
      ),
    );
  }

  void _archiveCourse(Map<String, dynamic> course) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Archive Course'),
        content: Text('Are you sure you want to archive "${course['title']}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final index = _courses.indexWhere((c) => c['id'] == course['id']);
              if (index != -1) {
                setState(() {
                  _courses[index]['status'] = 'Archived';
                });
              }
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Course archived successfully'),
                  backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
            ),
            child: Text('Archive'),
          ),
        ],
      ),
    );
  }

  void _togglePublishStatus(Map<String, dynamic> course) {
    final index = _courses.indexWhere((c) => c['id'] == course['id']);
    if (index != -1) {
      setState(() {
        _courses[index]['status'] =
            course['status'] == 'Published' ? 'Draft' : 'Published';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(course['status'] == 'Published'
              ? 'Course unpublished successfully'
              : 'Course published successfully'),
          backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
        ),
      );
    }
  }

  void _previewCourse() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Course preview functionality will be implemented'),
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
      ),
    );
  }

  void _toggleMultiSelectMode() {
    setState(() {
      _isMultiSelectMode = !_isMultiSelectMode;
      if (!_isMultiSelectMode) {
        _selectedCourseIds.clear();
      }
    });
  }

  void _toggleCourseSelection(String courseId) {
    setState(() {
      _selectedCourseIds.contains(courseId)
          ? _selectedCourseIds.remove(courseId)
          : _selectedCourseIds.add(courseId);
    });
  }

  void _performBulkAction(String action) {
    switch (action) {
      case 'publish':
        for (String courseId in _selectedCourseIds) {
          final index = _courses.indexWhere((c) => c['id'] == courseId);
          if (index != -1) {
            _courses[index]['status'] = 'Published';
          }
        }
        break;
      case 'archive':
        for (String courseId in _selectedCourseIds) {
          final index = _courses.indexWhere((c) => c['id'] == courseId);
          if (index != -1) {
            _courses[index]['status'] = 'Archived';
          }
        }
        break;
      case 'delete':
        _courses
            .removeWhere((course) => _selectedCourseIds.contains(course['id']));
        break;
    }

    setState(() {
      _selectedCourseIds.clear();
      _isMultiSelectMode = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Bulk action completed successfully'),
        backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Course Management'),
        actions: [
          if (_isMultiSelectMode) ...[
            PopupMenuButton<String>(
              icon: CustomIconWidget(
                iconName: 'more_vert',
                size: 6.w,
                color: AppTheme.lightTheme.colorScheme.onSurface,
              ),
              itemBuilder: (context) => [
                PopupMenuItem(
                  value: 'publish',
                  child: Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'publish',
                        size: 5.w,
                        color: AppTheme.lightTheme.colorScheme.tertiary,
                      ),
                      SizedBox(width: 2.w),
                      Text('Publish Selected'),
                    ],
                  ),
                ),
                PopupMenuItem(
                  value: 'archive',
                  child: Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'archive',
                        size: 5.w,
                        color: AppTheme.lightTheme.colorScheme.secondary,
                      ),
                      SizedBox(width: 2.w),
                      Text('Archive Selected'),
                    ],
                  ),
                ),
                PopupMenuItem(
                  value: 'delete',
                  child: Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'delete',
                        size: 5.w,
                        color: AppTheme.lightTheme.colorScheme.error,
                      ),
                      SizedBox(width: 2.w),
                      Text('Delete Selected'),
                    ],
                  ),
                ),
              ],
              onSelected: _performBulkAction,
            ),
          ] else ...[
            IconButton(
              onPressed: _toggleMultiSelectMode,
              icon: CustomIconWidget(
                iconName: 'checklist',
                size: 6.w,
                color: AppTheme.lightTheme.colorScheme.onSurface,
              ),
            ),
          ],
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refreshCourses,
        child: _isLoading
            ? Center(
                child: CircularProgressIndicator(
                  color: AppTheme.lightTheme.colorScheme.primary,
                ),
              )
            : _courses.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomIconWidget(
                          iconName: 'school',
                          size: 20.w,
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                        SizedBox(height: 2.h),
                        Text(
                          'No courses created yet',
                          style: AppTheme.lightTheme.textTheme.titleMedium
                              ?.copyWith(
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                        SizedBox(height: 1.h),
                        Text(
                          'Create your first course to get started',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 4.h),
                        ElevatedButton.icon(
                          onPressed: _createNewCourse,
                          icon: CustomIconWidget(
                            iconName: 'add',
                            size: 5.w,
                            color: Colors.white,
                          ),
                          label: Text('Create Course'),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: _courses.length,
                    itemBuilder: (context, index) {
                      final course = _courses[index];
                      final isSelected =
                          _selectedCourseIds.contains(course['id']);

                      return Stack(
                        children: [
                          CourseCardWidget(
                            course: course,
                            onTap: () {
                              if (_isMultiSelectMode) {
                                _toggleCourseSelection(course['id']);
                              } else {
                                setState(() {
                                  _selectedCourse = course;
                                });
                                _showCourseDetailView();
                              }
                            },
                            onEdit: () => _editCourse(course),
                            onDuplicate: () => _duplicateCourse(course),
                            onArchive: () => _archiveCourse(course),
                            onPublishToggle: () => _togglePublishStatus(course),
                          ),
                          if (_isMultiSelectMode)
                            Positioned(
                              top: 2.h,
                              right: 8.w,
                              child: Checkbox(
                                value: isSelected,
                                onChanged: (_) =>
                                    _toggleCourseSelection(course['id']),
                              ),
                            ),
                        ],
                      );
                    },
                  ),
      ),
      floatingActionButton: _isMultiSelectMode
          ? null
          : FloatingActionButton(
              onPressed: _createNewCourse,
              child: CustomIconWidget(
                iconName: 'add',
                size: 7.w,
                color: Colors.white,
              ),
            ),
    );
  }
}
