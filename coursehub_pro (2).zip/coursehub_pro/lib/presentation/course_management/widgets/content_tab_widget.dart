import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ContentTabWidget extends StatefulWidget {
  final List<Map<String, dynamic>> modules;
  final Function(List<Map<String, dynamic>>) onModulesChanged;

  const ContentTabWidget({
    Key? key,
    required this.modules,
    required this.onModulesChanged,
  }) : super(key: key);

  @override
  State<ContentTabWidget> createState() => _ContentTabWidgetState();
}

class _ContentTabWidgetState extends State<ContentTabWidget> {
  late List<Map<String, dynamic>> _modules;
  bool _isUploading = false;
  double _uploadProgress = 0.0;

  @override
  void initState() {
    super.initState();
    _modules = List.from(widget.modules);
  }

  Future<void> _addVideoModule() async {
    try {
      final hasPermission = await _requestStoragePermission();
      if (!hasPermission) {
        _showErrorSnackBar('Storage permission required');
        return;
      }

      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.video,
        allowMultiple: false,
      );

      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        await _simulateVideoUpload(file);

        final newModule = {
          'id': DateTime.now().millisecondsSinceEpoch.toString(),
          'title': file.name.split('.').first,
          'type': 'video',
          'duration': '00:00',
          'size': _formatFileSize(file.size),
          'filePath': file.path ?? '',
          'uploadDate': DateTime.now().toIso8601String(),
          'status': 'uploaded',
        };

        setState(() {
          _modules.add(newModule);
        });
        widget.onModulesChanged(_modules);
      }
    } catch (e) {
      _showErrorSnackBar('Failed to upload video');
    }
  }

  Future<void> _addDocumentModule() async {
    try {
      final hasPermission = await _requestStoragePermission();
      if (!hasPermission) {
        _showErrorSnackBar('Storage permission required');
        return;
      }

      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'doc', 'docx', 'ppt', 'pptx'],
        allowMultiple: false,
      );

      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;

        final newModule = {
          'id': DateTime.now().millisecondsSinceEpoch.toString(),
          'title': file.name.split('.').first,
          'type': 'document',
          'size': _formatFileSize(file.size),
          'filePath': file.path ?? '',
          'uploadDate': DateTime.now().toIso8601String(),
          'status': 'uploaded',
          'extension': file.extension ?? '',
        };

        setState(() {
          _modules.add(newModule);
        });
        widget.onModulesChanged(_modules);
      }
    } catch (e) {
      _showErrorSnackBar('Failed to upload document');
    }
  }

  Future<bool> _requestStoragePermission() async {
    final status = await Permission.storage.request();
    return status.isGranted;
  }

  Future<void> _simulateVideoUpload(PlatformFile file) async {
    setState(() {
      _isUploading = true;
      _uploadProgress = 0.0;
    });

    // Simulate upload progress
    for (int i = 0; i <= 100; i += 10) {
      await Future.delayed(Duration(milliseconds: 100));
      setState(() {
        _uploadProgress = i / 100;
      });
    }

    setState(() {
      _isUploading = false;
      _uploadProgress = 0.0;
    });
  }

  String _formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024)
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }

  void _reorderModules(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) {
        newIndex -= 1;
      }
      final item = _modules.removeAt(oldIndex);
      _modules.insert(newIndex, item);
    });
    widget.onModulesChanged(_modules);
  }

  void _showModuleOptions(Map<String, dynamic> module, int index) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Module Options',
              style: AppTheme.lightTheme.textTheme.titleMedium,
            ),
            SizedBox(height: 2.h),
            _buildOptionTile(
              icon: 'edit',
              title: 'Edit',
              onTap: () {
                Navigator.pop(context);
                _editModule(module, index);
              },
            ),
            _buildOptionTile(
              icon: 'visibility',
              title: 'Preview',
              onTap: () {
                Navigator.pop(context);
                _previewModule(module);
              },
            ),
            _buildOptionTile(
              icon: 'download',
              title: 'Download',
              onTap: () {
                Navigator.pop(context);
                _downloadModule(module);
              },
            ),
            _buildOptionTile(
              icon: 'delete',
              title: 'Delete',
              onTap: () {
                Navigator.pop(context);
                _deleteModule(index);
              },
              isDestructive: true,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOptionTile({
    required String icon,
    required String title,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: icon,
        size: 6.w,
        color: isDestructive
            ? AppTheme.lightTheme.colorScheme.error
            : AppTheme.lightTheme.colorScheme.primary,
      ),
      title: Text(
        title,
        style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
          color: isDestructive ? AppTheme.lightTheme.colorScheme.error : null,
        ),
      ),
      onTap: onTap,
    );
  }

  void _editModule(Map<String, dynamic> module, int index) {
    final titleController = TextEditingController(text: module['title']);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit Module'),
        content: TextField(
          controller: titleController,
          decoration: InputDecoration(
            labelText: 'Module Title',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _modules[index]['title'] = titleController.text;
              });
              widget.onModulesChanged(_modules);
              Navigator.pop(context);
            },
            child: Text('Save'),
          ),
        ],
      ),
    );
  }

  void _previewModule(Map<String, dynamic> module) {
    _showErrorSnackBar('Preview functionality will be implemented');
  }

  void _downloadModule(Map<String, dynamic> module) {
    _showErrorSnackBar('Download functionality will be implemented');
  }

  void _deleteModule(int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Delete Module'),
        content: Text('Are you sure you want to delete this module?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _modules.removeAt(index);
              });
              widget.onModulesChanged(_modules);
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
            ),
            child: Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Upload Progress Indicator
        if (_isUploading)
          Container(
            padding: EdgeInsets.all(4.w),
            child: Column(
              children: [
                Text(
                  'Uploading video...',
                  style: AppTheme.lightTheme.textTheme.bodyMedium,
                ),
                SizedBox(height: 1.h),
                LinearProgressIndicator(
                  value: _uploadProgress,
                  backgroundColor: AppTheme.lightTheme.colorScheme.outline,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    AppTheme.lightTheme.colorScheme.primary,
                  ),
                ),
                SizedBox(height: 1.h),
                Text(
                  '${(_uploadProgress * 100).toInt()}%',
                  style: AppTheme.lightTheme.textTheme.bodySmall,
                ),
              ],
            ),
          ),

        // Add Content Buttons
        Container(
          padding: EdgeInsets.all(4.w),
          child: Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _isUploading ? null : _addVideoModule,
                  icon: CustomIconWidget(
                    iconName: 'video_library',
                    size: 5.w,
                    color: Colors.white,
                  ),
                  label: Text('Add Video'),
                ),
              ),
              SizedBox(width: 4.w),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _isUploading ? null : _addDocumentModule,
                  icon: CustomIconWidget(
                    iconName: 'description',
                    size: 5.w,
                    color: AppTheme.lightTheme.colorScheme.primary,
                  ),
                  label: Text('Add Document'),
                ),
              ),
            ],
          ),
        ),

        // Modules List
        Expanded(
          child: _modules.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'video_library',
                        size: 20.w,
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                      SizedBox(height: 2.h),
                      Text(
                        'No content added yet',
                        style:
                            AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                      SizedBox(height: 1.h),
                      Text(
                        'Add videos or documents to get started',
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                )
              : ReorderableListView.builder(
                  padding: EdgeInsets.symmetric(horizontal: 4.w),
                  itemCount: _modules.length,
                  onReorder: _reorderModules,
                  itemBuilder: (context, index) {
                    final module = _modules[index];
                    return Card(
                      key: ValueKey(module['id']),
                      margin: EdgeInsets.only(bottom: 2.h),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: module['type'] == 'video'
                              ? AppTheme.lightTheme.colorScheme.primary
                              : AppTheme.lightTheme.colorScheme.secondary,
                          child: CustomIconWidget(
                            iconName: module['type'] == 'video'
                                ? 'play_arrow'
                                : 'description',
                            size: 6.w,
                            color: Colors.white,
                          ),
                        ),
                        title: Text(
                          module['title'] ?? 'Untitled',
                          style: AppTheme.lightTheme.textTheme.titleSmall,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              module['type'] == 'video'
                                  ? 'Duration: ${module['duration']} • ${module['size']}'
                                  : 'Document • ${module['size']}',
                              style: AppTheme.lightTheme.textTheme.bodySmall,
                            ),
                            Text(
                              'Uploaded: ${DateTime.parse(module['uploadDate']).toString().split(' ')[0]}',
                              style: AppTheme.lightTheme.textTheme.bodySmall
                                  ?.copyWith(
                                color: AppTheme
                                    .lightTheme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CustomIconWidget(
                              iconName: 'drag_handle',
                              size: 6.w,
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                            ),
                            SizedBox(width: 2.w),
                            GestureDetector(
                              onTap: () => _showModuleOptions(module, index),
                              child: CustomIconWidget(
                                iconName: 'more_vert',
                                size: 6.w,
                                color: AppTheme
                                    .lightTheme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                        ),
                        onTap: () => _showModuleOptions(module, index),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
