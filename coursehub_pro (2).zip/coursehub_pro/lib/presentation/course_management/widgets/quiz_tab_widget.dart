import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class QuizTabWidget extends StatefulWidget {
  final List<Map<String, dynamic>> quizzes;
  final Function(List<Map<String, dynamic>>) onQuizzesChanged;

  const QuizTabWidget({
    Key? key,
    required this.quizzes,
    required this.onQuizzesChanged,
  }) : super(key: key);

  @override
  State<QuizTabWidget> createState() => _QuizTabWidgetState();
}

class _QuizTabWidgetState extends State<QuizTabWidget> {
  late List<Map<String, dynamic>> _quizzes;

  @override
  void initState() {
    super.initState();
    _quizzes = List.from(widget.quizzes);
  }

  void _createNewQuiz() {
    showDialog(
      context: context,
      builder: (context) => _QuizCreationDialog(
        onQuizCreated: (quiz) {
          setState(() {
            _quizzes.add(quiz);
          });
          widget.onQuizzesChanged(_quizzes);
        },
      ),
    );
  }

  void _editQuiz(Map<String, dynamic> quiz, int index) {
    showDialog(
      context: context,
      builder: (context) => _QuizCreationDialog(
        existingQuiz: quiz,
        onQuizCreated: (updatedQuiz) {
          setState(() {
            _quizzes[index] = updatedQuiz;
          });
          widget.onQuizzesChanged(_quizzes);
        },
      ),
    );
  }

  void _deleteQuiz(int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Delete Quiz'),
        content: Text('Are you sure you want to delete this quiz?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                _quizzes.removeAt(index);
              });
              widget.onQuizzesChanged(_quizzes);
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
            ),
            child: Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _previewQuiz(Map<String, dynamic> quiz) {
    Navigator.pushNamed(context, '/quiz-screen');
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Create Quiz Button
        Container(
          padding: EdgeInsets.all(4.w),
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _createNewQuiz,
            icon: CustomIconWidget(
              iconName: 'add',
              size: 5.w,
              color: Colors.white,
            ),
            label: Text('Create New Quiz'),
          ),
        ),

        // Quizzes List
        Expanded(
          child: _quizzes.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomIconWidget(
                        iconName: 'quiz',
                        size: 20.w,
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                      SizedBox(height: 2.h),
                      Text(
                        'No quizzes created yet',
                        style:
                            AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                      SizedBox(height: 1.h),
                      Text(
                        'Create your first quiz to test student knowledge',
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: EdgeInsets.symmetric(horizontal: 4.w),
                  itemCount: _quizzes.length,
                  itemBuilder: (context, index) {
                    final quiz = _quizzes[index];
                    return Card(
                      margin: EdgeInsets.only(bottom: 2.h),
                      child: ExpansionTile(
                        leading: CircleAvatar(
                          backgroundColor:
                              AppTheme.lightTheme.colorScheme.tertiary,
                          child: CustomIconWidget(
                            iconName: 'quiz',
                            size: 6.w,
                            color: Colors.white,
                          ),
                        ),
                        title: Text(
                          quiz['title'] ?? 'Untitled Quiz',
                          style: AppTheme.lightTheme.textTheme.titleSmall,
                        ),
                        subtitle: Text(
                          '${(quiz['questions'] as List).length} questions • ${quiz['timeLimit']} minutes',
                          style: AppTheme.lightTheme.textTheme.bodySmall,
                        ),
                        trailing: PopupMenuButton(
                          icon: CustomIconWidget(
                            iconName: 'more_vert',
                            size: 6.w,
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                          itemBuilder: (context) => [
                            PopupMenuItem(
                              value: 'edit',
                              child: Row(
                                children: [
                                  CustomIconWidget(
                                    iconName: 'edit',
                                    size: 5.w,
                                    color:
                                        AppTheme.lightTheme.colorScheme.primary,
                                  ),
                                  SizedBox(width: 2.w),
                                  Text('Edit'),
                                ],
                              ),
                            ),
                            PopupMenuItem(
                              value: 'preview',
                              child: Row(
                                children: [
                                  CustomIconWidget(
                                    iconName: 'visibility',
                                    size: 5.w,
                                    color:
                                        AppTheme.lightTheme.colorScheme.primary,
                                  ),
                                  SizedBox(width: 2.w),
                                  Text('Preview'),
                                ],
                              ),
                            ),
                            PopupMenuItem(
                              value: 'delete',
                              child: Row(
                                children: [
                                  CustomIconWidget(
                                    iconName: 'delete',
                                    size: 5.w,
                                    color:
                                        AppTheme.lightTheme.colorScheme.error,
                                  ),
                                  SizedBox(width: 2.w),
                                  Text('Delete'),
                                ],
                              ),
                            ),
                          ],
                          onSelected: (value) {
                            switch (value) {
                              case 'edit':
                                _editQuiz(quiz, index);
                                break;
                              case 'preview':
                                _previewQuiz(quiz);
                                break;
                              case 'delete':
                                _deleteQuiz(index);
                                break;
                            }
                          },
                        ),
                        children: [
                          Container(
                            padding: EdgeInsets.all(4.w),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Questions:',
                                  style: AppTheme
                                      .lightTheme.textTheme.titleSmall
                                      ?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                SizedBox(height: 1.h),
                                ...(quiz['questions'] as List)
                                    .asMap()
                                    .entries
                                    .map((entry) {
                                  final questionIndex = entry.key;
                                  final question =
                                      entry.value as Map<String, dynamic>;
                                  return Container(
                                    margin: EdgeInsets.only(bottom: 1.h),
                                    padding: EdgeInsets.all(3.w),
                                    decoration: BoxDecoration(
                                      color: AppTheme
                                          .lightTheme.colorScheme.surface,
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: AppTheme
                                            .lightTheme.colorScheme.outline,
                                      ),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Q${questionIndex + 1}: ${question['question']}',
                                          style: AppTheme
                                              .lightTheme.textTheme.bodyMedium
                                              ?.copyWith(
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                        SizedBox(height: 0.5.h),
                                        Text(
                                          'Type: ${question['type']}',
                                          style: AppTheme
                                              .lightTheme.textTheme.bodySmall
                                              ?.copyWith(
                                            color: AppTheme.lightTheme
                                                .colorScheme.onSurfaceVariant,
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                }).toList(),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

class _QuizCreationDialog extends StatefulWidget {
  final Map<String, dynamic>? existingQuiz;
  final Function(Map<String, dynamic>) onQuizCreated;

  const _QuizCreationDialog({
    Key? key,
    this.existingQuiz,
    required this.onQuizCreated,
  }) : super(key: key);

  @override
  State<_QuizCreationDialog> createState() => _QuizCreationDialogState();
}

class _QuizCreationDialogState extends State<_QuizCreationDialog> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _titleController;
  late TextEditingController _timeLimitController;
  late List<Map<String, dynamic>> _questions;

  @override
  void initState() {
    super.initState();
    _titleController =
        TextEditingController(text: widget.existingQuiz?['title'] ?? '');
    _timeLimitController = TextEditingController(
        text: widget.existingQuiz?['timeLimit']?.toString() ?? '30');
    _questions = widget.existingQuiz != null
        ? List.from(widget.existingQuiz!['questions'])
        : [];
  }

  @override
  void dispose() {
    _titleController.dispose();
    _timeLimitController.dispose();
    super.dispose();
  }

  void _addQuestion() {
    setState(() {
      _questions.add({
        'id': DateTime.now().millisecondsSinceEpoch.toString(),
        'question': '',
        'type': 'multiple_choice',
        'options': ['', '', '', ''],
        'correctAnswer': 0,
        'points': 1,
      });
    });
  }

  void _removeQuestion(int index) {
    setState(() {
      _questions.removeAt(index);
    });
  }

  void _saveQuiz() {
    if (_formKey.currentState?.validate() ?? false) {
      final quiz = {
        'id': widget.existingQuiz?['id'] ??
            DateTime.now().millisecondsSinceEpoch.toString(),
        'title': _titleController.text,
        'timeLimit': int.tryParse(_timeLimitController.text) ?? 30,
        'questions': _questions,
        'createdAt': widget.existingQuiz?['createdAt'] ??
            DateTime.now().toIso8601String(),
        'updatedAt': DateTime.now().toIso8601String(),
      };

      widget.onQuizCreated(quiz);
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        width: 90.w,
        height: 80.h,
        padding: EdgeInsets.all(4.w),
        child: Column(
          children: [
            Text(
              widget.existingQuiz != null ? 'Edit Quiz' : 'Create New Quiz',
              style: AppTheme.lightTheme.textTheme.titleLarge,
            ),
            SizedBox(height: 2.h),
            Expanded(
              child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextFormField(
                        controller: _titleController,
                        decoration: InputDecoration(
                          labelText: 'Quiz Title',
                          prefixIcon: CustomIconWidget(
                            iconName: 'title',
                            size: 6.w,
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter a quiz title';
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 2.h),
                      TextFormField(
                        controller: _timeLimitController,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: 'Time Limit (minutes)',
                          prefixIcon: CustomIconWidget(
                            iconName: 'timer',
                            size: 6.w,
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter time limit';
                          }
                          if (int.tryParse(value) == null) {
                            return 'Please enter a valid number';
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 3.h),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Questions (${_questions.length})',
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          TextButton.icon(
                            onPressed: _addQuestion,
                            icon: CustomIconWidget(
                              iconName: 'add',
                              size: 5.w,
                              color: AppTheme.lightTheme.colorScheme.primary,
                            ),
                            label: Text('Add Question'),
                          ),
                        ],
                      ),
                      SizedBox(height: 1.h),
                      ..._questions.asMap().entries.map((entry) {
                        final index = entry.key;
                        final question = entry.value;
                        return Card(
                          margin: EdgeInsets.only(bottom: 2.h),
                          child: Padding(
                            padding: EdgeInsets.all(3.w),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Question ${index + 1}',
                                      style: AppTheme
                                          .lightTheme.textTheme.titleSmall
                                          ?.copyWith(
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    IconButton(
                                      onPressed: () => _removeQuestion(index),
                                      icon: CustomIconWidget(
                                        iconName: 'delete',
                                        size: 5.w,
                                        color: AppTheme
                                            .lightTheme.colorScheme.error,
                                      ),
                                    ),
                                  ],
                                ),
                                TextFormField(
                                  initialValue: question['question'],
                                  decoration: InputDecoration(
                                    labelText: 'Question Text',
                                    border: OutlineInputBorder(),
                                  ),
                                  onChanged: (value) {
                                    _questions[index]['question'] = value;
                                  },
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter question text';
                                    }
                                    return null;
                                  },
                                ),
                                SizedBox(height: 1.h),
                                Text(
                                  'Options:',
                                  style: AppTheme
                                      .lightTheme.textTheme.bodyMedium
                                      ?.copyWith(
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                SizedBox(height: 0.5.h),
                                ...List.generate(4, (optionIndex) {
                                  return Padding(
                                    padding: EdgeInsets.only(bottom: 1.h),
                                    child: TextFormField(
                                      initialValue: (question['options']
                                          as List)[optionIndex],
                                      decoration: InputDecoration(
                                        labelText: 'Option ${optionIndex + 1}',
                                        border: OutlineInputBorder(),
                                        prefixIcon: Radio<int>(
                                          value: optionIndex,
                                          groupValue: question['correctAnswer'],
                                          onChanged: (value) {
                                            setState(() {
                                              _questions[index]
                                                  ['correctAnswer'] = value;
                                            });
                                          },
                                        ),
                                      ),
                                      onChanged: (value) {
                                        (_questions[index]['options']
                                            as List)[optionIndex] = value;
                                      },
                                    ),
                                  );
                                }),
                              ],
                            ),
                          ),
                        );
                      }).toList(),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 2.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text('Cancel'),
                  ),
                ),
                SizedBox(width: 4.w),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _saveQuiz,
                    child: Text('Save Quiz'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
