import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AnalyticsTabWidget extends StatefulWidget {
  final Map<String, dynamic> courseAnalytics;

  const AnalyticsTabWidget({
    Key? key,
    required this.courseAnalytics,
  }) : super(key: key);

  @override
  State<AnalyticsTabWidget> createState() => _AnalyticsTabWidgetState();
}

class _AnalyticsTabWidgetState extends State<AnalyticsTabWidget> {
  String _selectedPeriod = '7 days';
  final List<String> _periods = ['7 days', '30 days', '90 days', '1 year'];

  @override
  Widget build(BuildContext context) {
    final analytics = widget.courseAnalytics;
    final enrollmentData =
        analytics['enrollmentData'] as List<Map<String, dynamic>>? ?? [];
    final completionRate = analytics['completionRate'] ?? 0.0;
    final averageRating = analytics['averageRating'] ?? 0.0;
    final totalRevenue = analytics['totalRevenue'] ?? 0.0;

    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Period Selector
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Analytics Overview',
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              DropdownButton<String>(
                value: _selectedPeriod,
                items: _periods.map((period) {
                  return DropdownMenuItem(
                    value: period,
                    child: Text(period),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value != null) {
                    setState(() {
                      _selectedPeriod = value;
                    });
                  }
                },
              ),
            ],
          ),
          SizedBox(height: 3.h),

          // Key Metrics Cards
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            childAspectRatio: 1.5,
            crossAxisSpacing: 4.w,
            mainAxisSpacing: 2.h,
            children: [
              _buildMetricCard(
                title: 'Total Enrollments',
                value: '${analytics['totalEnrollments'] ?? 0}',
                icon: 'people',
                color: AppTheme.lightTheme.colorScheme.primary,
              ),
              _buildMetricCard(
                title: 'Completion Rate',
                value: '${(completionRate * 100).toInt()}%',
                icon: 'check_circle',
                color: AppTheme.lightTheme.colorScheme.tertiary,
              ),
              _buildMetricCard(
                title: 'Average Rating',
                value: averageRating.toStringAsFixed(1),
                icon: 'star',
                color: Colors.amber,
              ),
              _buildMetricCard(
                title: 'Total Revenue',
                value: '\$${totalRevenue.toStringAsFixed(0)}',
                icon: 'attach_money',
                color: AppTheme.lightTheme.colorScheme.secondary,
              ),
            ],
          ),
          SizedBox(height: 4.h),

          // Enrollment Chart
          Text(
            'Enrollment Trends',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          Container(
            height: 30.h,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline,
              ),
            ),
            child: enrollmentData.isNotEmpty
                ? LineChart(
                    LineChartData(
                      gridData: FlGridData(show: true),
                      titlesData: FlTitlesData(
                        leftTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 40,
                            getTitlesWidget: (value, meta) {
                              return Text(
                                value.toInt().toString(),
                                style: AppTheme.lightTheme.textTheme.bodySmall,
                              );
                            },
                          ),
                        ),
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            reservedSize: 30,
                            getTitlesWidget: (value, meta) {
                              final index = value.toInt();
                              if (index >= 0 && index < enrollmentData.length) {
                                return Text(
                                  enrollmentData[index]['date'] ?? '',
                                  style:
                                      AppTheme.lightTheme.textTheme.bodySmall,
                                );
                              }
                              return Text('');
                            },
                          ),
                        ),
                        rightTitles: AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                        topTitles: AxisTitles(
                            sideTitles: SideTitles(showTitles: false)),
                      ),
                      borderData: FlBorderData(show: true),
                      lineBarsData: [
                        LineChartBarData(
                          spots: enrollmentData.asMap().entries.map((entry) {
                            return FlSpot(
                              entry.key.toDouble(),
                              (entry.value['enrollments'] ?? 0).toDouble(),
                            );
                          }).toList(),
                          isCurved: true,
                          color: AppTheme.lightTheme.colorScheme.primary,
                          barWidth: 3,
                          dotData: FlDotData(show: true),
                          belowBarData: BarAreaData(
                            show: true,
                            color: AppTheme.lightTheme.colorScheme.primary
                                .withValues(alpha: 0.1),
                          ),
                        ),
                      ],
                    ),
                  )
                : Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomIconWidget(
                          iconName: 'show_chart',
                          size: 12.w,
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                        SizedBox(height: 1.h),
                        Text(
                          'No enrollment data available',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
          ),
          SizedBox(height: 4.h),

          // Student Progress
          Text(
            'Student Progress Distribution',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          Container(
            height: 25.h,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline,
              ),
            ),
            child: PieChart(
              PieChartData(
                sections: [
                  PieChartSectionData(
                    value: 45,
                    title: 'Completed\n45%',
                    color: AppTheme.lightTheme.colorScheme.tertiary,
                    radius: 60,
                    titleStyle:
                        AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  PieChartSectionData(
                    value: 30,
                    title: 'In Progress\n30%',
                    color: AppTheme.lightTheme.colorScheme.primary,
                    radius: 60,
                    titleStyle:
                        AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  PieChartSectionData(
                    value: 25,
                    title: 'Not Started\n25%',
                    color: AppTheme.lightTheme.colorScheme.secondary,
                    radius: 60,
                    titleStyle:
                        AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
                sectionsSpace: 2,
                centerSpaceRadius: 0,
              ),
            ),
          ),
          SizedBox(height: 4.h),

          // Recent Activity
          Text(
            'Recent Activity',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          Container(
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline,
              ),
            ),
            child: Column(
              children: [
                _buildActivityItem(
                  icon: 'person_add',
                  title: 'New enrollment',
                  subtitle: 'Sarah Johnson enrolled 2 hours ago',
                  time: '2h ago',
                ),
                Divider(height: 1),
                _buildActivityItem(
                  icon: 'quiz',
                  title: 'Quiz completed',
                  subtitle: 'Mike Chen completed Module 3 Quiz',
                  time: '4h ago',
                ),
                Divider(height: 1),
                _buildActivityItem(
                  icon: 'star',
                  title: 'New review',
                  subtitle: 'Emma Davis left a 5-star review',
                  time: '6h ago',
                ),
                Divider(height: 1),
                _buildActivityItem(
                  icon: 'payment',
                  title: 'Payment received',
                  subtitle: 'Course purchase - \$99.00',
                  time: '8h ago',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMetricCard({
    required String title,
    required String value,
    required String icon,
    required Color color,
  }) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  title,
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              CustomIconWidget(
                iconName: icon,
                size: 6.w,
                color: color,
              ),
            ],
          ),
          Text(
            value,
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActivityItem({
    required String icon,
    required String title,
    required String subtitle,
    required String time,
  }) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor:
            AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1),
        child: CustomIconWidget(
          iconName: icon,
          size: 5.w,
          color: AppTheme.lightTheme.colorScheme.primary,
        ),
      ),
      title: Text(
        title,
        style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
          fontWeight: FontWeight.w500,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: AppTheme.lightTheme.textTheme.bodySmall,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      trailing: Text(
        time,
        style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
          color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }
}
