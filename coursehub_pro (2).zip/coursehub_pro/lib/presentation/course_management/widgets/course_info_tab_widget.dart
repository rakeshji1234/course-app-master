import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class CourseInfoTabWidget extends StatefulWidget {
  final Map<String, dynamic> courseData;
  final Function(Map<String, dynamic>) onDataChanged;

  const CourseInfoTabWidget({
    Key? key,
    required this.courseData,
    required this.onDataChanged,
  }) : super(key: key);

  @override
  State<CourseInfoTabWidget> createState() => _CourseInfoTabWidgetState();
}

class _CourseInfoTabWidgetState extends State<CourseInfoTabWidget> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;
  late TextEditingController _priceController;
  late String _selectedCategory;
  String? _thumbnailPath;
  final ImagePicker _imagePicker = ImagePicker();

  final List<String> _categories = [
    'Technology',
    'Business',
    'Design',
    'Marketing',
    'Photography',
    'Music',
    'Health & Fitness',
    'Language',
    'Personal Development',
    'Academic',
  ];

  @override
  void initState() {
    super.initState();
    _titleController =
        TextEditingController(text: widget.courseData['title'] ?? '');
    _descriptionController =
        TextEditingController(text: widget.courseData['description'] ?? '');
    _priceController = TextEditingController(
        text: widget.courseData['price']?.toString() ?? '');
    _selectedCategory = widget.courseData['category'] ?? _categories.first;
    _thumbnailPath = widget.courseData['thumbnail'];
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      final hasPermission = await _requestPermission();
      if (!hasPermission) return;

      showModalBottomSheet(
        context: context,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        ),
        builder: (context) => Container(
          padding: EdgeInsets.all(4.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Select Image Source',
                style: AppTheme.lightTheme.textTheme.titleMedium,
              ),
              SizedBox(height: 2.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildImageSourceOption(
                    icon: 'camera_alt',
                    label: 'Camera',
                    onTap: () => _selectImage(ImageSource.camera),
                  ),
                  _buildImageSourceOption(
                    icon: 'photo_library',
                    label: 'Gallery',
                    onTap: () => _selectImage(ImageSource.gallery),
                  ),
                ],
              ),
              SizedBox(height: 2.h),
            ],
          ),
        ),
      );
    } catch (e) {
      _showErrorSnackBar('Failed to access image picker');
    }
  }

  Widget _buildImageSourceOption({
    required String icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          border: Border.all(color: AppTheme.lightTheme.colorScheme.outline),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            CustomIconWidget(
              iconName: icon,
              size: 8.w,
              color: AppTheme.lightTheme.colorScheme.primary,
            ),
            SizedBox(height: 1.h),
            Text(
              label,
              style: AppTheme.lightTheme.textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }

  Future<bool> _requestPermission() async {
    final cameraStatus = await Permission.camera.request();
    final storageStatus = await Permission.storage.request();
    return cameraStatus.isGranted && storageStatus.isGranted;
  }

  Future<void> _selectImage(ImageSource source) async {
    Navigator.pop(context);
    try {
      final XFile? image = await _imagePicker.pickImage(
        source: source,
        maxWidth: 1024,
        maxHeight: 1024,
        imageQuality: 85,
      );

      if (image != null) {
        setState(() {
          _thumbnailPath = image.path;
        });
        _updateCourseData();
      }
    } catch (e) {
      _showErrorSnackBar('Failed to select image');
    }
  }

  void _updateCourseData() {
    final updatedData = {
      ...widget.courseData,
      'title': _titleController.text,
      'description': _descriptionController.text,
      'price': double.tryParse(_priceController.text) ?? 0.0,
      'category': _selectedCategory,
      'thumbnail': _thumbnailPath,
    };
    widget.onDataChanged(updatedData);
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Thumbnail Section
            Text(
              'Course Thumbnail',
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 2.h),
            GestureDetector(
              onTap: _pickImage,
              child: Container(
                width: double.infinity,
                height: 25.h,
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: AppTheme.lightTheme.colorScheme.outline,
                    style: BorderStyle.solid,
                  ),
                ),
                child: _thumbnailPath != null
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: CustomImageWidget(
                          imageUrl: _thumbnailPath!,
                          width: double.infinity,
                          height: 25.h,
                          fit: BoxFit.cover,
                        ),
                      )
                    : Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomIconWidget(
                            iconName: 'add_photo_alternate',
                            size: 12.w,
                            color: AppTheme.lightTheme.colorScheme.primary,
                          ),
                          SizedBox(height: 1.h),
                          Text(
                            'Tap to add thumbnail',
                            style: AppTheme.lightTheme.textTheme.bodyMedium
                                ?.copyWith(
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
            SizedBox(height: 3.h),

            // Course Title
            Text(
              'Course Title',
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 1.h),
            TextFormField(
              controller: _titleController,
              decoration: InputDecoration(
                hintText: 'Enter course title',
                prefixIcon: CustomIconWidget(
                  iconName: 'title',
                  size: 6.w,
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter a course title';
                }
                return null;
              },
              onChanged: (_) => _updateCourseData(),
            ),
            SizedBox(height: 3.h),

            // Course Description
            Text(
              'Course Description',
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 1.h),
            TextFormField(
              controller: _descriptionController,
              maxLines: 4,
              decoration: InputDecoration(
                hintText: 'Enter course description',
                alignLabelWithHint: true,
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter a course description';
                }
                return null;
              },
              onChanged: (_) => _updateCourseData(),
            ),
            SizedBox(height: 3.h),

            // Price and Category Row
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Price (\$)',
                        style:
                            AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 1.h),
                      TextFormField(
                        controller: _priceController,
                        keyboardType:
                            TextInputType.numberWithOptions(decimal: true),
                        decoration: InputDecoration(
                          hintText: '0.00',
                          prefixIcon: CustomIconWidget(
                            iconName: 'attach_money',
                            size: 6.w,
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Enter price';
                          }
                          if (double.tryParse(value) == null) {
                            return 'Invalid price';
                          }
                          return null;
                        },
                        onChanged: (_) => _updateCourseData(),
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 4.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Category',
                        style:
                            AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 1.h),
                      DropdownButtonFormField<String>(
                        value: _selectedCategory,
                        decoration: InputDecoration(
                          prefixIcon: CustomIconWidget(
                            iconName: 'category',
                            size: 6.w,
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                        items: _categories.map((category) {
                          return DropdownMenuItem(
                            value: category,
                            child: Text(
                              category,
                              style: AppTheme.lightTheme.textTheme.bodyMedium,
                              overflow: TextOverflow.ellipsis,
                            ),
                          );
                        }).toList(),
                        onChanged: (value) {
                          if (value != null) {
                            setState(() {
                              _selectedCategory = value;
                            });
                            _updateCourseData();
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 4.h),

            // Save Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState?.validate() ?? false) {
                    _updateCourseData();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Course information saved successfully'),
                        backgroundColor:
                            AppTheme.lightTheme.colorScheme.tertiary,
                      ),
                    );
                  }
                },
                child: Text('Save Course Information'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
