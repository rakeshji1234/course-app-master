import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ProgressIndicatorWidget extends StatelessWidget {
  final int currentStep;
  final List<String> steps;

  const ProgressIndicatorWidget({
    Key? key,
    required this.currentStep,
    required this.steps,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: AppTheme.lightTheme.colorScheme.shadow,
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: List.generate(
              steps.length,
              (index) => Expanded(
                child: Row(
                  children: [
                    Expanded(
                      child: _buildStepIndicator(index),
                    ),
                    if (index < steps.length - 1)
                      Container(
                        width: 8.w,
                        height: 2,
                        color: index < currentStep
                            ? AppTheme.lightTheme.colorScheme.primary
                            : AppTheme.lightTheme.colorScheme.outline
                                .withValues(alpha: 0.3),
                      ),
                  ],
                ),
              ),
            ),
          ),
          SizedBox(height: 1.h),
          Row(
            children: List.generate(
              steps.length,
              (index) => Expanded(
                child: Text(
                  steps[index],
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: index <= currentStep
                        ? AppTheme.lightTheme.colorScheme.primary
                        : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    fontWeight: index == currentStep
                        ? FontWeight.w600
                        : FontWeight.w400,
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepIndicator(int index) {
    final isCompleted = index < currentStep;
    final isCurrent = index == currentStep;
    final isUpcoming = index > currentStep;

    return Container(
      width: 8.w,
      height: 4.h,
      decoration: BoxDecoration(
        color: isCompleted || isCurrent
            ? AppTheme.lightTheme.colorScheme.primary
            : AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3),
        shape: BoxShape.circle,
        border: isCurrent
            ? Border.all(
                color: AppTheme.lightTheme.colorScheme.primary,
                width: 3,
              )
            : null,
      ),
      child: Center(
        child: isCompleted
            ? CustomIconWidget(
                iconName: 'check',
                size: 16,
                color: Colors.white,
              )
            : Text(
                '${index + 1}',
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: isUpcoming
                      ? AppTheme.lightTheme.colorScheme.onSurfaceVariant
                      : Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
      ),
    );
  }
}
