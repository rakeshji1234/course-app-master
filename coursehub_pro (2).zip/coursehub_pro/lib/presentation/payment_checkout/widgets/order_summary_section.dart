import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class OrderSummarySection extends StatelessWidget {
  final Map<String, dynamic> orderData;

  const OrderSummarySection({
    Key? key,
    required this.orderData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final coursePrice = (orderData['coursePrice'] as num?)?.toDouble() ?? 0.0;
    final discount = (orderData['discount'] as num?)?.toDouble() ?? 0.0;
    final tax = (orderData['tax'] as num?)?.toDouble() ?? 0.0;
    final processingFee =
        (orderData['processingFee'] as num?)?.toDouble() ?? 0.0;
    final total = coursePrice - discount + tax + processingFee;

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'receipt',
                size: 20,
                color: AppTheme.lightTheme.colorScheme.primary,
              ),
              SizedBox(width: 2.w),
              Text(
                'Order Summary',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          // Course Price
          _buildSummaryRow(
            'Course Price',
            '\$${coursePrice.toStringAsFixed(2)}',
            isSubtotal: true,
          ),
          if (discount > 0) ...[
            SizedBox(height: 1.h),
            _buildSummaryRow(
              'Discount Applied',
              '-\$${discount.toStringAsFixed(2)}',
              isDiscount: true,
            ),
          ],
          SizedBox(height: 1.h),
          _buildSummaryRow(
            'Tax',
            '\$${tax.toStringAsFixed(2)}',
            isSubtotal: true,
          ),
          if (processingFee > 0) ...[
            SizedBox(height: 1.h),
            _buildSummaryRow(
              'Processing Fee',
              '\$${processingFee.toStringAsFixed(2)}',
              isSubtotal: true,
            ),
          ],
          SizedBox(height: 2.h),
          Container(
            height: 1,
            width: double.infinity,
            color:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3),
          ),
          SizedBox(height: 2.h),
          // Total
          _buildSummaryRow(
            'Total Amount',
            '\$${total.toStringAsFixed(2)}',
            isTotal: true,
          ),
          SizedBox(height: 2.h),
          // Payment terms
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.tertiary
                  .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.tertiary
                    .withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'info',
                      size: 16,
                      color: AppTheme.lightTheme.colorScheme.tertiary,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Payment Terms',
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w500,
                        color: AppTheme.lightTheme.colorScheme.tertiary,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 1.h),
                Text(
                  '• Instant access after successful payment\n• 30-day money-back guarantee\n• Lifetime access to course content\n• Free updates and new materials',
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryRow(
    String label,
    String amount, {
    bool isTotal = false,
    bool isDiscount = false,
    bool isSubtotal = false,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            fontWeight: isTotal ? FontWeight.w600 : FontWeight.w400,
            color: isTotal
                ? AppTheme.lightTheme.colorScheme.onSurface
                : isDiscount
                    ? AppTheme.lightTheme.colorScheme.tertiary
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          ),
        ),
        Text(
          amount,
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            fontWeight: isTotal ? FontWeight.w700 : FontWeight.w500,
            color: isTotal
                ? AppTheme.lightTheme.colorScheme.primary
                : isDiscount
                    ? AppTheme.lightTheme.colorScheme.tertiary
                    : AppTheme.lightTheme.colorScheme.onSurface,
          ),
        ),
      ],
    );
  }
}
