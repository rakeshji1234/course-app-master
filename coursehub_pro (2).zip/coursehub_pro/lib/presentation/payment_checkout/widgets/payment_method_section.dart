import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class PaymentMethodSection extends StatefulWidget {
  final Function(String) onPaymentMethodChanged;
  final String selectedMethod;

  const PaymentMethodSection({
    Key? key,
    required this.onPaymentMethodChanged,
    required this.selectedMethod,
  }) : super(key: key);

  @override
  State<PaymentMethodSection> createState() => _PaymentMethodSectionState();
}

class _PaymentMethodSectionState extends State<PaymentMethodSection> {
  final List<Map<String, dynamic>> paymentMethods = [
    {
      'id': 'card',
      'title': 'Credit/Debit Card',
      'subtitle': 'Visa, Mastercard, American Express',
      'icon': 'credit_card',
      'available': true,
    },
    {
      'id': 'paypal',
      'title': 'PayPal',
      'subtitle': 'Pay with your PayPal account',
      'icon': 'account_balance_wallet',
      'available': true,
    },
    {
      'id': 'google_pay',
      'title': 'Google Pay',
      'subtitle': 'Quick and secure payments',
      'icon': 'payment',
      'available': !kIsWeb && defaultTargetPlatform == TargetPlatform.android,
    },
    {
      'id': 'apple_pay',
      'title': 'Apple Pay',
      'subtitle': 'Touch ID or Face ID',
      'icon': 'fingerprint',
      'available': !kIsWeb && defaultTargetPlatform == TargetPlatform.iOS,
    },
    {
      'id': 'razorpay',
      'title': 'Razorpay',
      'subtitle': 'UPI, Net Banking, Wallets',
      'icon': 'account_balance',
      'available': true,
    },
  ];

  @override
  Widget build(BuildContext context) {
    final availableMethods =
        paymentMethods.where((method) => method['available'] as bool).toList();

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'payment',
                size: 20,
                color: AppTheme.lightTheme.colorScheme.primary,
              ),
              SizedBox(width: 2.w),
              Text(
                'Payment Method',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          ...availableMethods
              .map((method) => _buildPaymentMethodTile(method))
              .toList(),
        ],
      ),
    );
  }

  Widget _buildPaymentMethodTile(Map<String, dynamic> method) {
    final isSelected = widget.selectedMethod == method['id'];

    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      child: InkWell(
        onTap: () => widget.onPaymentMethodChanged(method['id'] as String),
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            color: isSelected
                ? AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: isSelected
                  ? AppTheme.lightTheme.colorScheme.primary
                  : AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
              width: isSelected ? 2 : 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 12.w,
                height: 6.h,
                decoration: BoxDecoration(
                  color: isSelected
                      ? AppTheme.lightTheme.colorScheme.primary
                          .withValues(alpha: 0.1)
                      : AppTheme.lightTheme.colorScheme.surface
                          .withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: CustomIconWidget(
                    iconName: method['icon'] as String,
                    size: 24,
                    color: isSelected
                        ? AppTheme.lightTheme.colorScheme.primary
                        : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      method['title'] as String,
                      style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                        fontWeight: FontWeight.w500,
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                      ),
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      method['subtitle'] as String,
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Radio<String>(
                value: method['id'] as String,
                groupValue: widget.selectedMethod,
                onChanged: (value) {
                  if (value != null) {
                    widget.onPaymentMethodChanged(value);
                  }
                },
                activeColor: AppTheme.lightTheme.colorScheme.primary,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
