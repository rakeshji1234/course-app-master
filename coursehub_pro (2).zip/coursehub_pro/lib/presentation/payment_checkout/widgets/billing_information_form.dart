import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class BillingInformationForm extends StatefulWidget {
  final Function(Map<String, String>) onBillingDataChanged;
  final bool isVisible;

  const BillingInformationForm({
    Key? key,
    required this.onBillingDataChanged,
    required this.isVisible,
  }) : super(key: key);

  @override
  State<BillingInformationForm> createState() => _BillingInformationFormState();
}

class _BillingInformationFormState extends State<BillingInformationForm> {
  final _emailController = TextEditingController();
  final _addressController = TextEditingController();
  final _cityController = TextEditingController();
  final _stateController = TextEditingController();
  final _zipController = TextEditingController();
  final _countryController = TextEditingController();

  final _emailFocus = FocusNode();
  final _addressFocus = FocusNode();
  final _cityFocus = FocusNode();
  final _stateFocus = FocusNode();
  final _zipFocus = FocusNode();
  final _countryFocus = FocusNode();

  bool _isEmailValid = false;
  bool _isAddressValid = false;
  bool _isCityValid = false;
  bool _isStateValid = false;
  bool _isZipValid = false;
  bool _isCountryValid = false;

  @override
  void initState() {
    super.initState();
    _emailController.addListener(_onEmailChanged);
    _addressController.addListener(_onAddressChanged);
    _cityController.addListener(_onCityChanged);
    _stateController.addListener(_onStateChanged);
    _zipController.addListener(_onZipChanged);
    _countryController.addListener(_onCountryChanged);

    // Pre-fill with sample data
    _emailController.text = 'john.doe@email.com';
    _addressController.text = '123 Main Street';
    _cityController.text = 'New York';
    _stateController.text = 'NY';
    _zipController.text = '10001';
    _countryController.text = 'United States';
  }

  @override
  void dispose() {
    _emailController.dispose();
    _addressController.dispose();
    _cityController.dispose();
    _stateController.dispose();
    _zipController.dispose();
    _countryController.dispose();
    _emailFocus.dispose();
    _addressFocus.dispose();
    _cityFocus.dispose();
    _stateFocus.dispose();
    _zipFocus.dispose();
    _countryFocus.dispose();
    super.dispose();
  }

  void _onEmailChanged() {
    setState(() {
      _isEmailValid = _validateEmail(_emailController.text);
    });
    _updateBillingData();
  }

  void _onAddressChanged() {
    setState(() {
      _isAddressValid = _validateAddress(_addressController.text);
    });
    _updateBillingData();
  }

  void _onCityChanged() {
    setState(() {
      _isCityValid = _validateCity(_cityController.text);
    });
    _updateBillingData();
  }

  void _onStateChanged() {
    setState(() {
      _isStateValid = _validateState(_stateController.text);
    });
    _updateBillingData();
  }

  void _onZipChanged() {
    setState(() {
      _isZipValid = _validateZip(_zipController.text);
    });
    _updateBillingData();
  }

  void _onCountryChanged() {
    setState(() {
      _isCountryValid = _validateCountry(_countryController.text);
    });
    _updateBillingData();
  }

  void _updateBillingData() {
    widget.onBillingDataChanged({
      'email': _emailController.text,
      'address': _addressController.text,
      'city': _cityController.text,
      'state': _stateController.text,
      'zip': _zipController.text,
      'country': _countryController.text,
      'isValid': (_isEmailValid &&
              _isAddressValid &&
              _isCityValid &&
              _isStateValid &&
              _isZipValid &&
              _isCountryValid)
          .toString(),
    });
  }

  bool _validateEmail(String email) {
    return RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
  }

  bool _validateAddress(String address) {
    return address.trim().length >= 5;
  }

  bool _validateCity(String city) {
    return city.trim().length >= 2;
  }

  bool _validateState(String state) {
    return state.trim().length >= 2;
  }

  bool _validateZip(String zip) {
    return zip.trim().length >= 5;
  }

  bool _validateCountry(String country) {
    return country.trim().length >= 2;
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isVisible) return const SizedBox.shrink();

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'location_on',
                size: 20,
                color: AppTheme.lightTheme.colorScheme.primary,
              ),
              SizedBox(width: 2.w),
              Text(
                'Billing Information',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          // Email
          TextFormField(
            controller: _emailController,
            focusNode: _emailFocus,
            keyboardType: TextInputType.emailAddress,
            decoration: InputDecoration(
              labelText: 'Email Address',
              hintText: 'john.doe@email.com',
              prefixIcon: Padding(
                padding: EdgeInsets.all(2.w),
                child: CustomIconWidget(
                  iconName: 'email',
                  size: 20,
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                  color: AppTheme.lightTheme.colorScheme.outline,
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                  color: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.5),
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                  color: AppTheme.lightTheme.colorScheme.primary,
                  width: 2,
                ),
              ),
            ),
            onFieldSubmitted: (_) => _addressFocus.requestFocus(),
          ),
          SizedBox(height: 2.h),
          // Address
          TextFormField(
            controller: _addressController,
            focusNode: _addressFocus,
            keyboardType: TextInputType.streetAddress,
            decoration: InputDecoration(
              labelText: 'Street Address',
              hintText: '123 Main Street',
              prefixIcon: Padding(
                padding: EdgeInsets.all(2.w),
                child: CustomIconWidget(
                  iconName: 'home',
                  size: 20,
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                  color: AppTheme.lightTheme.colorScheme.outline,
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                  color: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.5),
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(
                  color: AppTheme.lightTheme.colorScheme.primary,
                  width: 2,
                ),
              ),
            ),
            onFieldSubmitted: (_) => _cityFocus.requestFocus(),
          ),
          SizedBox(height: 2.h),
          // City and State Row
          Row(
            children: [
              Expanded(
                flex: 2,
                child: TextFormField(
                  controller: _cityController,
                  focusNode: _cityFocus,
                  keyboardType: TextInputType.text,
                  textCapitalization: TextCapitalization.words,
                  decoration: InputDecoration(
                    labelText: 'City',
                    hintText: 'New York',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.outline,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.outline
                            .withValues(alpha: 0.5),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.primary,
                        width: 2,
                      ),
                    ),
                  ),
                  onFieldSubmitted: (_) => _stateFocus.requestFocus(),
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: TextFormField(
                  controller: _stateController,
                  focusNode: _stateFocus,
                  keyboardType: TextInputType.text,
                  textCapitalization: TextCapitalization.characters,
                  decoration: InputDecoration(
                    labelText: 'State',
                    hintText: 'NY',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.outline,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.outline
                            .withValues(alpha: 0.5),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.primary,
                        width: 2,
                      ),
                    ),
                  ),
                  onFieldSubmitted: (_) => _zipFocus.requestFocus(),
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          // ZIP and Country Row
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: _zipController,
                  focusNode: _zipFocus,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: 'ZIP Code',
                    hintText: '10001',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.outline,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.outline
                            .withValues(alpha: 0.5),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.primary,
                        width: 2,
                      ),
                    ),
                  ),
                  onFieldSubmitted: (_) => _countryFocus.requestFocus(),
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                flex: 2,
                child: TextFormField(
                  controller: _countryController,
                  focusNode: _countryFocus,
                  keyboardType: TextInputType.text,
                  textCapitalization: TextCapitalization.words,
                  decoration: InputDecoration(
                    labelText: 'Country',
                    hintText: 'United States',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.outline,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.outline
                            .withValues(alpha: 0.5),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.primary,
                        width: 2,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
