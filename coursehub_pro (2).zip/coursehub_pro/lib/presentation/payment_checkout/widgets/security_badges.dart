import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SecurityBadges extends StatelessWidget {
  const SecurityBadges({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> securityFeatures = [
      {
        'icon': 'security',
        'title': 'SSL Secured',
        'subtitle': '256-bit encryption',
      },
      {
        'icon': 'verified_user',
        'title': 'PCI Compliant',
        'subtitle': 'Secure payments',
      },
      {
        'icon': 'shield',
        'title': 'Money Back',
        'subtitle': '30-day guarantee',
      },
    ];

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.1),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'lock',
                size: 18,
                color: AppTheme.lightTheme.colorScheme.tertiary,
              ),
              SizedBox(width: 2.w),
              Text(
                'Your payment is secure and protected',
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: securityFeatures
                .map((feature) => _buildSecurityBadge(feature))
                .toList(),
          ),
          SizedBox(height: 2.h),
          Text(
            'We use industry-standard security measures to protect your personal and payment information. Your data is encrypted and never stored on our servers.',
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              height: 1.4,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildSecurityBadge(Map<String, dynamic> feature) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 12.w,
            height: 6.h,
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.tertiary
                  .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(
              child: CustomIconWidget(
                iconName: feature['icon'] as String,
                size: 24,
                color: AppTheme.lightTheme.colorScheme.tertiary,
              ),
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            feature['title'] as String,
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              fontWeight: FontWeight.w600,
              color: AppTheme.lightTheme.colorScheme.onSurface,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 0.5.h),
          Text(
            feature['subtitle'] as String,
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              fontSize: 10.sp,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
