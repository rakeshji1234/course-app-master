import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/billing_information_form.dart';
import './widgets/card_input_form.dart';
import './widgets/course_summary_card.dart';
import './widgets/order_summary_section.dart';
import './widgets/payment_method_section.dart';
import './widgets/progress_indicator_widget.dart';
import './widgets/security_badges.dart';

class PaymentCheckout extends StatefulWidget {
  const PaymentCheckout({Key? key}) : super(key: key);

  @override
  State<PaymentCheckout> createState() => _PaymentCheckoutState();
}

class _PaymentCheckoutState extends State<PaymentCheckout> {
  String _selectedPaymentMethod = 'card';
  Map<String, String> _cardData = {};
  Map<String, String> _billingData = {};
  bool _isProcessing = false;
  bool _acceptedTerms = false;
  int _currentStep = 0;

  final List<String> _checkoutSteps = [
    'Course',
    'Payment',
    'Billing',
    'Complete'
  ];

  // Mock course data
  final Map<String, dynamic> _courseData = {
    'id': 'course_001',
    'title': 'Complete Flutter Development Bootcamp',
    'instructor': 'Dr. Angela Yu',
    'thumbnail':
        'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3',
    'duration': '65h 30m',
    'originalPrice': 199.99,
    'discount': 50.00,
  };

  // Mock order data
  final Map<String, dynamic> _orderData = {
    'coursePrice': 199.99,
    'discount': 50.00,
    'tax': 12.00,
    'processingFee': 2.99,
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          ProgressIndicatorWidget(
            currentStep: _currentStep,
            steps: _checkoutSteps,
          ),
          Expanded(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                children: [
                  SizedBox(height: 2.h),
                  CourseSummaryCard(courseData: _courseData),
                  PaymentMethodSection(
                    selectedMethod: _selectedPaymentMethod,
                    onPaymentMethodChanged: _onPaymentMethodChanged,
                  ),
                  CardInputForm(
                    isVisible: _selectedPaymentMethod == 'card',
                    onCardDataChanged: _onCardDataChanged,
                  ),
                  BillingInformationForm(
                    isVisible: _shouldShowBillingForm(),
                    onBillingDataChanged: _onBillingDataChanged,
                  ),
                  OrderSummarySection(orderData: _orderData),
                  SecurityBadges(),
                  _buildTermsAndConditions(),
                  SizedBox(height: 2.h),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomBar(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      elevation: 0,
      leading: IconButton(
        onPressed: () => Navigator.pop(context),
        icon: CustomIconWidget(
          iconName: 'arrow_back',
          size: 24,
          color: AppTheme.lightTheme.colorScheme.onSurface,
        ),
      ),
      title: Text(
        'Secure Checkout',
        style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.w600,
          color: AppTheme.lightTheme.colorScheme.onSurface,
        ),
      ),
      actions: [
        Container(
          margin: EdgeInsets.only(right: 4.w),
          padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
          decoration: BoxDecoration(
            color:
                AppTheme.lightTheme.colorScheme.tertiary.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              CustomIconWidget(
                iconName: 'lock',
                size: 16,
                color: AppTheme.lightTheme.colorScheme.tertiary,
              ),
              SizedBox(width: 1.w),
              Text(
                'SSL',
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.tertiary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTermsAndConditions() {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Checkbox(
                value: _acceptedTerms,
                onChanged: (value) {
                  setState(() {
                    _acceptedTerms = value ?? false;
                  });
                },
                activeColor: AppTheme.lightTheme.colorScheme.primary,
              ),
              Expanded(
                child: Padding(
                  padding: EdgeInsets.only(top: 1.h),
                  child: RichText(
                    text: TextSpan(
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        height: 1.4,
                      ),
                      children: [
                        const TextSpan(text: 'I agree to the '),
                        TextSpan(
                          text: 'Terms of Service',
                          style: TextStyle(
                            color: AppTheme.lightTheme.colorScheme.primary,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                        const TextSpan(text: ' and '),
                        TextSpan(
                          text: 'Refund Policy',
                          style: TextStyle(
                            color: AppTheme.lightTheme.colorScheme.primary,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                        const TextSpan(
                            text:
                                '. I understand that I will receive instant access to the course content after successful payment.'),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBottomBar() {
    final totalAmount = (_orderData['coursePrice'] as double) -
        (_orderData['discount'] as double) +
        (_orderData['tax'] as double) +
        (_orderData['processingFee'] as double);

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: AppTheme.lightTheme.colorScheme.shadow,
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Total Amount:',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: AppTheme.lightTheme.colorScheme.onSurface,
                  ),
                ),
                Text(
                  '\$${totalAmount.toStringAsFixed(2)}',
                  style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: AppTheme.lightTheme.colorScheme.primary,
                  ),
                ),
              ],
            ),
            SizedBox(height: 2.h),
            SizedBox(
              width: double.infinity,
              height: 6.h,
              child: ElevatedButton(
                onPressed: _canCompletePurchase() ? _completePurchase : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.lightTheme.colorScheme.primary,
                  foregroundColor: Colors.white,
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  disabledBackgroundColor: AppTheme
                      .lightTheme.colorScheme.outline
                      .withValues(alpha: 0.3),
                ),
                child: _isProcessing
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor:
                                  AlwaysStoppedAnimation<Color>(Colors.white),
                            ),
                          ),
                          SizedBox(width: 3.w),
                          Text(
                            'Processing...',
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomIconWidget(
                            iconName: _getPaymentIcon(),
                            size: 20,
                            color: Colors.white,
                          ),
                          SizedBox(width: 2.w),
                          Text(
                            _getPaymentButtonText(),
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _onPaymentMethodChanged(String method) {
    setState(() {
      _selectedPaymentMethod = method;
      _currentStep = 1;
    });
  }

  void _onCardDataChanged(Map<String, String> cardData) {
    setState(() {
      _cardData = cardData;
    });
  }

  void _onBillingDataChanged(Map<String, String> billingData) {
    setState(() {
      _billingData = billingData;
      if (billingData['isValid'] == 'true') {
        _currentStep = 2;
      }
    });
  }

  bool _shouldShowBillingForm() {
    return _selectedPaymentMethod == 'card' ||
        _selectedPaymentMethod == 'paypal' ||
        _selectedPaymentMethod == 'razorpay';
  }

  bool _canCompletePurchase() {
    if (!_acceptedTerms) return false;

    switch (_selectedPaymentMethod) {
      case 'card':
        return _cardData['isValid'] == 'true' &&
            _billingData['isValid'] == 'true';
      case 'paypal':
      case 'razorpay':
        return _billingData['isValid'] == 'true';
      case 'google_pay':
      case 'apple_pay':
        return true;
      default:
        return false;
    }
  }

  String _getPaymentIcon() {
    switch (_selectedPaymentMethod) {
      case 'card':
        return 'credit_card';
      case 'paypal':
        return 'account_balance_wallet';
      case 'google_pay':
        return 'payment';
      case 'apple_pay':
        return 'fingerprint';
      case 'razorpay':
        return 'account_balance';
      default:
        return 'payment';
    }
  }

  String _getPaymentButtonText() {
    switch (_selectedPaymentMethod) {
      case 'card':
        return 'Complete Purchase';
      case 'paypal':
        return 'Pay with PayPal';
      case 'google_pay':
        return 'Pay with Google Pay';
      case 'apple_pay':
        return 'Pay with Apple Pay';
      case 'razorpay':
        return 'Pay with Razorpay';
      default:
        return 'Complete Purchase';
    }
  }

  Future<void> _completePurchase() async {
    setState(() {
      _isProcessing = true;
      _currentStep = 3;
    });

    try {
      // Simulate payment processing
      await Future.delayed(const Duration(seconds: 3));

      // Simulate different payment methods
      await _processPaymentMethod();

      // Show success message
      _showSuccessDialog();
    } catch (e) {
      _showErrorMessage('Payment failed. Please try again.');
    } finally {
      setState(() {
        _isProcessing = false;
      });
    }
  }

  Future<void> _processPaymentMethod() async {
    switch (_selectedPaymentMethod) {
      case 'card':
        await _processCreditCardPayment();
        break;
      case 'paypal':
        await _processPayPalPayment();
        break;
      case 'google_pay':
        await _processGooglePayPayment();
        break;
      case 'apple_pay':
        await _processApplePayPayment();
        break;
      case 'razorpay':
        await _processRazorpayPayment();
        break;
    }
  }

  Future<void> _processCreditCardPayment() async {
    // Simulate credit card processing with validation
    final cardNumber = _cardData['cardNumber'] ?? '';
    if (cardNumber.length < 13) {
      throw Exception('Invalid card number');
    }

    // Simulate network call
    await Future.delayed(const Duration(seconds: 2));

    // Mock success response
    print('Credit card payment processed successfully');
  }

  Future<void> _processPayPalPayment() async {
    // Simulate PayPal redirect and processing
    await Future.delayed(const Duration(seconds: 2));
    print('PayPal payment processed successfully');
  }

  Future<void> _processGooglePayPayment() async {
    if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
      // Simulate Google Pay processing
      await Future.delayed(const Duration(seconds: 1));
      print('Google Pay payment processed successfully');
    } else {
      throw Exception('Google Pay not available on this platform');
    }
  }

  Future<void> _processApplePayPayment() async {
    if (!kIsWeb && defaultTargetPlatform == TargetPlatform.iOS) {
      // Simulate Apple Pay processing with biometric authentication
      await Future.delayed(const Duration(seconds: 1));
      print('Apple Pay payment processed successfully');
    } else {
      throw Exception('Apple Pay not available on this platform');
    }
  }

  Future<void> _processRazorpayPayment() async {
    // Simulate Razorpay processing
    await Future.delayed(const Duration(seconds: 2));
    print('Razorpay payment processed successfully');
  }

  void _showSuccessDialog() {
    final orderNumber =
        'CH${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}';

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 20.w,
              height: 10.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.tertiary
                    .withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: CustomIconWidget(
                  iconName: 'check_circle',
                  size: 48,
                  color: AppTheme.lightTheme.colorScheme.tertiary,
                ),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Payment Successful!',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w700,
                color: AppTheme.lightTheme.colorScheme.onSurface,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 2.h),
            Text(
              'Your course enrollment is complete. You now have lifetime access to all course materials.',
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                height: 1.4,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 2.h),
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface
                    .withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                children: [
                  Text(
                    'Order Number',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  SizedBox(height: 0.5.h),
                  Text(
                    orderNumber,
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: AppTheme.lightTheme.colorScheme.primary,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 3.h),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                  _showToast('Receipt sent to your email!');
                },
                child: Text('Continue Learning'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showErrorMessage(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'error',
              size: 24,
              color: AppTheme.lightTheme.colorScheme.error,
            ),
            SizedBox(width: 2.w),
            Text(
              'Payment Failed',
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.error,
              ),
            ),
          ],
        ),
        content: Text(
          message,
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Try Again'),
          ),
        ],
      ),
    );
  }

  void _showToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: AppTheme.lightTheme.colorScheme.onSurface,
      textColor: AppTheme.lightTheme.colorScheme.surface,
    );
  }
}
