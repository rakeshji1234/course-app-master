import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/achievement_badges_widget.dart';
import './widgets/current_courses_widget.dart';
import './widgets/overall_stats_widget.dart';
import './widgets/performance_analytics_widget.dart';
import './widgets/recent_activity_widget.dart';

class ProgressTracking extends StatefulWidget {
  const ProgressTracking({Key? key}) : super(key: key);

  @override
  State<ProgressTracking> createState() => _ProgressTrackingState();
}

class _ProgressTrackingState extends State<ProgressTracking> {
  bool _isLoading = false;

  // Mock data for overall statistics
  final Map<String, dynamic> _overallStats = {
    "completedCourses": 12,
    "hoursLearned": 156.5,
    "currentStreak": 15,
    "achievementLevel": "Advanced Learner",
    "progressPercentage": 78.0,
  };

  // Mock data for current courses
  final List<Map<String, dynamic>> _currentCourses = [
    {
      "id": 1,
      "name": "Advanced Flutter Development",
      "instructor": "Sarah Johnson",
      "progress": 75.0,
      "timeRemaining": "2h 30m",
      "image":
          "https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "totalModules": 12,
      "completedModules": 9,
    },
    {
      "id": 2,
      "name": "Machine Learning Fundamentals",
      "instructor": "Dr. Michael Chen",
      "progress": 45.0,
      "timeRemaining": "5h 15m",
      "image":
          "https://images.unsplash.com/photo-1555949963-aa79dcee981c?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "totalModules": 15,
      "completedModules": 7,
    },
    {
      "id": 3,
      "name": "UI/UX Design Principles",
      "instructor": "Emma Rodriguez",
      "progress": 90.0,
      "timeRemaining": "45m",
      "image":
          "https://images.unsplash.com/photo-1561070791-2526d30994b5?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "totalModules": 8,
      "completedModules": 7,
    },
  ];

  // Mock data for recent activities
  final List<Map<String, dynamic>> _recentActivities = [
    {
      "id": 1,
      "type": "quiz",
      "title": "Flutter State Management Quiz",
      "description": "Completed advanced quiz on Provider and Bloc patterns",
      "timestamp": DateTime.now().subtract(const Duration(hours: 2)),
      "score": 92,
    },
    {
      "id": 2,
      "type": "lesson",
      "title": "Custom Animations in Flutter",
      "description": "Watched lesson on creating smooth custom animations",
      "timestamp": DateTime.now().subtract(const Duration(hours: 5)),
      "score": null,
    },
    {
      "id": 3,
      "type": "achievement",
      "title": "Week Streak Champion",
      "description": "Maintained 7-day learning streak",
      "timestamp": DateTime.now().subtract(const Duration(days: 1)),
      "score": null,
    },
    {
      "id": 4,
      "type": "milestone",
      "title": "Course Completion",
      "description": "Successfully completed React Native Basics course",
      "timestamp": DateTime.now().subtract(const Duration(days: 2)),
      "score": 88,
    },
    {
      "id": 5,
      "type": "quiz",
      "title": "JavaScript ES6 Features",
      "description": "Completed quiz on modern JavaScript features",
      "timestamp": DateTime.now().subtract(const Duration(days: 3)),
      "score": 85,
    },
  ];

  // Mock data for quiz scores
  final List<Map<String, dynamic>> _quizScores = [
    {"quiz": "Flutter Basics", "score": 78},
    {"quiz": "State Management", "score": 85},
    {"quiz": "Animations", "score": 92},
    {"quiz": "Testing", "score": 88},
    {"quiz": "Performance", "score": 95},
    {"quiz": "Architecture", "score": 90},
  ];

  // Mock data for weekly progress
  final List<Map<String, dynamic>> _weeklyProgress = [
    {"day": "Mon", "hours": 2.5},
    {"day": "Tue", "hours": 3.2},
    {"day": "Wed", "hours": 1.8},
    {"day": "Thu", "hours": 4.1},
    {"day": "Fri", "hours": 2.9},
    {"day": "Sat", "hours": 3.7},
    {"day": "Sun", "hours": 2.3},
  ];

  // Mock data for weak areas
  final List<String> _weakAreas = [
    "Advanced Algorithms",
    "Database Design",
    "System Architecture",
  ];

  // Mock data for achievements
  final List<Map<String, dynamic>> _achievements = [
    {
      "id": 1,
      "title": "First Course",
      "description": "Complete your first course",
      "icon": "school",
      "category": "completion",
      "isEarned": true,
      "earnedDate": DateTime.now().subtract(const Duration(days: 30)),
    },
    {
      "id": 2,
      "title": "Quiz Master",
      "description": "Score 90%+ on 5 quizzes",
      "icon": "quiz",
      "category": "performance",
      "isEarned": true,
      "earnedDate": DateTime.now().subtract(const Duration(days: 15)),
    },
    {
      "id": 3,
      "title": "Streak Hero",
      "description": "Maintain 30-day streak",
      "icon": "local_fire_department",
      "category": "streak",
      "isEarned": false,
      "earnedDate": null,
    },
    {
      "id": 4,
      "title": "Speed Learner",
      "description": "Complete course in record time",
      "icon": "speed",
      "category": "special",
      "isEarned": true,
      "earnedDate": DateTime.now().subtract(const Duration(days: 7)),
    },
    {
      "id": 5,
      "title": "Knowledge Seeker",
      "description": "Complete 10 courses",
      "icon": "auto_stories",
      "category": "milestone",
      "isEarned": true,
      "earnedDate": DateTime.now().subtract(const Duration(days: 5)),
    },
    {
      "id": 6,
      "title": "Perfect Score",
      "description": "Get 100% on any quiz",
      "icon": "star",
      "category": "performance",
      "isEarned": false,
      "earnedDate": null,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: RefreshIndicator(
        onRefresh: _handleRefresh,
        color: AppTheme.lightTheme.colorScheme.primary,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Overall Statistics
              OverallStatsWidget(
                completedCourses: _overallStats['completedCourses'] as int,
                hoursLearned: (_overallStats['hoursLearned'] as num).toDouble(),
                currentStreak: _overallStats['currentStreak'] as int,
                achievementLevel: _overallStats['achievementLevel'] as String,
                progressPercentage:
                    (_overallStats['progressPercentage'] as num).toDouble(),
              ),

              // Current Courses
              CurrentCoursesWidget(
                courses: _currentCourses,
                onCoursePressed: _handleCoursePressed,
                onCourseLongPressed: _handleCourseLongPressed,
              ),

              // Recent Activity
              RecentActivityWidget(
                activities: _recentActivities,
              ),

              // Performance Analytics
              PerformanceAnalyticsWidget(
                quizScores: _quizScores,
                weeklyProgress: _weeklyProgress,
                weakAreas: _weakAreas,
              ),

              // Achievement Badges
              AchievementBadgesWidget(
                achievements: _achievements,
                onBadgePressed: _handleBadgePressed,
              ),

              SizedBox(height: 4.h),
            ],
          ),
        ),
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: Text(
        'Progress Tracking',
        style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.w600,
        ),
      ),
      centerTitle: true,
      actions: [
        IconButton(
          onPressed: _handleExportProgress,
          icon: CustomIconWidget(
            iconName: 'file_download',
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 24,
          ),
          tooltip: 'Export Progress Report',
        ),
        IconButton(
          onPressed: _handleCalendarView,
          icon: CustomIconWidget(
            iconName: 'calendar_today',
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 24,
          ),
          tooltip: 'Calendar View',
        ),
      ],
    );
  }

  Widget _buildBottomNavigationBar() {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      currentIndex: 2, // Progress tab is active
      selectedItemColor: AppTheme.lightTheme.colorScheme.primary,
      unselectedItemColor: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
      onTap: _handleBottomNavTap,
      items: [
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'home',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 24,
          ),
          activeIcon: CustomIconWidget(
            iconName: 'home',
            color: AppTheme.lightTheme.colorScheme.primary,
            size: 24,
          ),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'school',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 24,
          ),
          activeIcon: CustomIconWidget(
            iconName: 'school',
            color: AppTheme.lightTheme.colorScheme.primary,
            size: 24,
          ),
          label: 'Courses',
        ),
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'analytics',
            color: AppTheme.lightTheme.colorScheme.primary,
            size: 24,
          ),
          activeIcon: CustomIconWidget(
            iconName: 'analytics',
            color: AppTheme.lightTheme.colorScheme.primary,
            size: 24,
          ),
          label: 'Progress',
        ),
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'quiz',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 24,
          ),
          activeIcon: CustomIconWidget(
            iconName: 'quiz',
            color: AppTheme.lightTheme.colorScheme.primary,
            size: 24,
          ),
          label: 'Quizzes',
        ),
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'person',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 24,
          ),
          activeIcon: CustomIconWidget(
            iconName: 'person',
            color: AppTheme.lightTheme.colorScheme.primary,
            size: 24,
          ),
          label: 'Profile',
        ),
      ],
    );
  }

  Future<void> _handleRefresh() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call delay
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      _isLoading = false;
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Progress data refreshed successfully'),
          backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _handleCoursePressed(Map<String, dynamic> course) {
    _showCourseDetailsModal(course);
  }

  void _handleCourseLongPressed(Map<String, dynamic> course) {
    _showDetailedAnalyticsModal(course);
  }

  void _handleBadgePressed(Map<String, dynamic> achievement) {
    _showAchievementDetailsModal(achievement);
  }

  void _handleExportProgress() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Progress report exported successfully'),
        backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
        behavior: SnackBarBehavior.floating,
        action: SnackBarAction(
          label: 'View',
          textColor: Colors.white,
          onPressed: () {},
        ),
      ),
    );
  }

  void _handleCalendarView() {
    Navigator.pushNamed(context, '/calendar-view');
  }

  void _handleBottomNavTap(int index) {
    switch (index) {
      case 0:
        Navigator.pushReplacementNamed(context, '/splash-screen');
        break;
      case 1:
        Navigator.pushReplacementNamed(context, '/course-management');
        break;
      case 2:
        // Already on progress tracking
        break;
      case 3:
        Navigator.pushReplacementNamed(context, '/quiz-screen');
        break;
      case 4:
        Navigator.pushReplacementNamed(context, '/admin-dashboard');
        break;
    }
  }

  void _showCourseDetailsModal(Map<String, dynamic> course) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: 60.h,
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          children: [
            Container(
              width: 10.w,
              height: 0.5.h,
              margin: EdgeInsets.symmetric(vertical: 2.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.outline,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(4.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      course['name'] as String,
                      style:
                          AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      'by ${course['instructor'] as String}',
                      style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    SizedBox(height: 3.h),
                    LinearProgressIndicator(
                      value: (course['progress'] as num).toDouble() / 100,
                      backgroundColor: AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.3),
                      valueColor: AlwaysStoppedAnimation<Color>(
                        AppTheme.lightTheme.colorScheme.primary,
                      ),
                      minHeight: 8,
                    ),
                    SizedBox(height: 2.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '${(course['progress'] as num).toInt()}% Complete',
                          style: AppTheme.lightTheme.textTheme.titleMedium
                              ?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          '${course['timeRemaining'] as String} remaining',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 3.h),
                    Text(
                      'Progress Details',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 2.h),
                    Row(
                      children: [
                        Expanded(
                          child: _buildProgressDetailCard(
                            'Modules',
                            '${course['completedModules']}/${course['totalModules']}',
                            'library_books',
                          ),
                        ),
                        SizedBox(width: 3.w),
                        Expanded(
                          child: _buildProgressDetailCard(
                            'Time Spent',
                            '12.5h',
                            'schedule',
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: const Text('Continue Learning'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showDetailedAnalyticsModal(Map<String, dynamic> course) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: 70.h,
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          children: [
            Container(
              width: 10.w,
              height: 0.5.h,
              margin: EdgeInsets.symmetric(vertical: 2.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.outline,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(4.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Detailed Analytics',
                      style:
                          AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      course['name'] as String,
                      style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    SizedBox(height: 3.h),
                    Text(
                      'Learning Velocity',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    Container(
                      padding: EdgeInsets.all(3.w),
                      decoration: BoxDecoration(
                        color: AppTheme.lightTheme.colorScheme.tertiary
                            .withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'trending_up',
                            color: AppTheme.lightTheme.colorScheme.tertiary,
                            size: 24,
                          ),
                          SizedBox(width: 3.w),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '2.3 modules/week',
                                style: AppTheme.lightTheme.textTheme.titleMedium
                                    ?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color:
                                      AppTheme.lightTheme.colorScheme.tertiary,
                                ),
                              ),
                              Text(
                                'Above average pace',
                                style: AppTheme.lightTheme.textTheme.bodySmall
                                    ?.copyWith(
                                  color: AppTheme
                                      .lightTheme.colorScheme.onSurfaceVariant,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 3.h),
                    Text(
                      'Quiz Performance History',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 2.h),
                    Expanded(
                      child: ListView.separated(
                        itemCount: 3,
                        separatorBuilder: (context, index) =>
                            SizedBox(height: 1.h),
                        itemBuilder: (context, index) {
                          final quizData = [
                            {
                              'name': 'Module 1 Quiz',
                              'score': 85,
                              'attempts': 1
                            },
                            {
                              'name': 'Module 2 Quiz',
                              'score': 92,
                              'attempts': 2
                            },
                            {
                              'name': 'Module 3 Quiz',
                              'score': 78,
                              'attempts': 1
                            },
                          ][index];

                          return Container(
                            padding: EdgeInsets.all(3.w),
                            decoration: BoxDecoration(
                              color: AppTheme.lightTheme.colorScheme.surface,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: AppTheme.lightTheme.colorScheme.outline
                                    .withValues(alpha: 0.3),
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        quizData['name'] as String,
                                        style: AppTheme
                                            .lightTheme.textTheme.titleSmall
                                            ?.copyWith(
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      Text(
                                        '${quizData['attempts']} attempt${(quizData['attempts'] as int) == 1 ? '' : 's'}',
                                        style: AppTheme
                                            .lightTheme.textTheme.bodySmall
                                            ?.copyWith(
                                          color: AppTheme.lightTheme.colorScheme
                                              .onSurfaceVariant,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 3.w, vertical: 1.h),
                                  decoration: BoxDecoration(
                                    color:
                                        _getScoreColor(quizData['score'] as int)
                                            .withValues(alpha: 0.1),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Text(
                                    '${quizData['score']}%',
                                    style: AppTheme
                                        .lightTheme.textTheme.bodySmall
                                        ?.copyWith(
                                      color: _getScoreColor(
                                          quizData['score'] as int),
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAchievementDetailsModal(Map<String, dynamic> achievement) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            Container(
              width: 12.w,
              height: 12.w,
              decoration: BoxDecoration(
                color: achievement['isEarned'] as bool
                    ? AppTheme.lightTheme.colorScheme.tertiary
                    : AppTheme.lightTheme.colorScheme.outline
                        .withValues(alpha: 0.3),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: CustomIconWidget(
                  iconName: achievement['icon'] as String,
                  color: achievement['isEarned'] as bool
                      ? Colors.white
                      : AppTheme.lightTheme.colorScheme.outline,
                  size: 24,
                ),
              ),
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Text(
                achievement['title'] as String,
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              achievement['description'] as String,
              style: AppTheme.lightTheme.textTheme.bodyLarge,
            ),
            if (achievement['isEarned'] as bool &&
                achievement['earnedDate'] != null) ...[
              SizedBox(height: 2.h),
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.tertiary
                      .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'check_circle',
                      color: AppTheme.lightTheme.colorScheme.tertiary,
                      size: 20,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Earned on ${_formatFullDate(achievement['earnedDate'] as DateTime)}',
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.tertiary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
        actions: [
          if (achievement['isEarned'] as bool)
            TextButton.icon(
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: const Text('Achievement shared successfully!'),
                    backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              },
              icon: CustomIconWidget(
                iconName: 'share',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 16,
              ),
              label: const Text('Share'),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressDetailCard(String title, String value, String iconName) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          CustomIconWidget(
            iconName: iconName,
            color: AppTheme.lightTheme.colorScheme.primary,
            size: 24,
          ),
          SizedBox(height: 1.h),
          Text(
            value,
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w700,
              color: AppTheme.lightTheme.colorScheme.primary,
            ),
          ),
          Text(
            title,
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Color _getScoreColor(int score) {
    if (score >= 90) return AppTheme.lightTheme.colorScheme.tertiary;
    if (score >= 70) return Colors.orange;
    return AppTheme.lightTheme.colorScheme.error;
  }

  String _formatFullDate(DateTime date) {
    final months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ];
    return '${months[date.month - 1]} ${date.day}, ${date.year}';
  }
}
