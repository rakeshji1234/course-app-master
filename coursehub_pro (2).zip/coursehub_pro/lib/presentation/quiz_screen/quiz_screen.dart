import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/quiz_navigation_widget.dart';
import './widgets/quiz_overview_modal.dart';
import './widgets/quiz_progress_widget.dart';
import './widgets/quiz_question_widget.dart';

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> with TickerProviderStateMixin {
  int _currentQuestionIndex = 0;
  Map<int, dynamic> _answers = {};
  bool _isReviewMode = false;
  bool _isSubmitted = false;
  bool _hasUnsavedChanges = false;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  // Timer variables
  Duration? _timeRemaining;
  bool _showTimer = true;

  // Mock quiz data
  final List<Map<String, dynamic>> _quizQuestions = [
    {
      "id": 1,
      "type": "multiple_choice",
      "question":
          "What is the primary programming language used for Flutter development?",
      "options": ["Java", "Kotlin", "Dart", "Swift"],
      "correctAnswer": 2,
      "explanation":
          "Dart is the programming language developed by Google specifically for Flutter development. It provides features like hot reload and ahead-of-time compilation."
    },
    {
      "id": 2,
      "type": "true_false",
      "question":
          "Flutter can be used to develop applications for both iOS and Android platforms.",
      "options": ["True", "False"],
      "correctAnswer": 0,
      "explanation":
          "Flutter is a cross-platform framework that allows developers to create applications for iOS, Android, web, and desktop from a single codebase."
    },
    {
      "id": 3,
      "type": "multiple_choice",
      "question": "Which widget is used as the root of a Flutter application?",
      "options": ["Scaffold", "MaterialApp", "Container", "Column"],
      "correctAnswer": 1,
      "explanation":
          "MaterialApp is typically used as the root widget in Flutter applications as it provides material design styling and navigation capabilities."
    },
    {
      "id": 4,
      "type": "text_input",
      "question":
          "Explain the difference between StatelessWidget and StatefulWidget in Flutter.",
      "correctAnswer":
          "StatelessWidget is immutable and doesn't change over time, while StatefulWidget can change its state and rebuild when setState is called.",
      "explanation":
          "StatelessWidget represents widgets that don't change, while StatefulWidget can maintain mutable state and trigger rebuilds when the state changes."
    },
    {
      "id": 5,
      "type": "multiple_choice",
      "question":
          "What is the purpose of the pubspec.yaml file in a Flutter project?",
      "options": [
        "To define the app's user interface",
        "To manage dependencies and project configuration",
        "To store application data",
        "To handle navigation routes"
      ],
      "correctAnswer": 1,
      "explanation":
          "The pubspec.yaml file is used to manage project dependencies, assets, and configuration settings for a Flutter application."
    },
    {
      "id": 6,
      "type": "true_false",
      "question":
          "Hot reload in Flutter allows you to see changes instantly without restarting the app.",
      "options": ["True", "False"],
      "correctAnswer": 0,
      "explanation":
          "Hot reload is one of Flutter's key features that allows developers to see changes in the code reflected instantly in the running application without losing the current state."
    },
    {
      "id": 7,
      "type": "multiple_choice",
      "question": "Which of the following is NOT a layout widget in Flutter?",
      "options": ["Row", "Column", "Stack", "TextField"],
      "correctAnswer": 3,
      "explanation":
          "TextField is an input widget used for text input, while Row, Column, and Stack are layout widgets used to arrange other widgets."
    },
    {
      "id": 8,
      "type": "text_input",
      "question": "What is the purpose of the BuildContext in Flutter?",
      "correctAnswer":
          "BuildContext provides information about the location of a widget in the widget tree and is used to access theme data, media queries, and navigation.",
      "explanation":
          "BuildContext is a handle to the location of a widget in the widget tree and provides access to various inherited widgets and services."
    }
  ];

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeTimer();
    // Prevent screenshots during quiz
    _preventScreenshots();
  }

  void _initializeAnimations() {
    _fadeController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );
    _fadeController.forward();
  }

  void _initializeTimer() {
    // Set quiz duration to 30 minutes
    _timeRemaining = Duration(minutes: 30);

    // Start countdown timer
    if (_showTimer && _timeRemaining != null) {
      _startTimer();
    }
  }

  void _startTimer() {
    Future.delayed(Duration(seconds: 1), () {
      if (mounted && !_isSubmitted && _timeRemaining != null) {
        setState(() {
          _timeRemaining = _timeRemaining! - Duration(seconds: 1);
          if (_timeRemaining!.inSeconds <= 0) {
            _autoSubmitQuiz();
          } else {
            _startTimer();
          }
        });
      }
    });
  }

  void _preventScreenshots() {
    // Prevent screenshots on Android
    try {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    } catch (e) {
      // Handle silently
    }
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  double get _progressPercentage {
    return ((_currentQuestionIndex + 1) / _quizQuestions.length) * 100;
  }

  void _onAnswerSelected(dynamic answer) {
    setState(() {
      _answers[_currentQuestionIndex] = answer;
      _hasUnsavedChanges = false;
    });

    // Auto-save indication
    _showAutoSaveConfirmation();
  }

  void _showAutoSaveConfirmation() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              color: AppTheme.lightTheme.colorScheme.tertiary,
              size: 4.w,
            ),
            SizedBox(width: 2.w),
            Text('Answer saved automatically'),
          ],
        ),
        duration: Duration(seconds: 1),
        behavior: SnackBarBehavior.floating,
        margin: EdgeInsets.only(
          bottom: 20.h,
          left: 4.w,
          right: 4.w,
        ),
      ),
    );
  }

  void _goToPreviousQuestion() {
    if (_currentQuestionIndex > 0) {
      _fadeController.reset();
      setState(() {
        _currentQuestionIndex--;
      });
      _fadeController.forward();
    }
  }

  void _goToNextQuestion() {
    if (_currentQuestionIndex < _quizQuestions.length - 1) {
      _fadeController.reset();
      setState(() {
        _currentQuestionIndex++;
      });
      _fadeController.forward();
    }
  }

  void _goToQuestion(int index) {
    if (index >= 0 && index < _quizQuestions.length) {
      _fadeController.reset();
      setState(() {
        _currentQuestionIndex = index;
      });
      _fadeController.forward();
    }
  }

  void _showQuizOverview() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => QuizOverviewModal(
        questions: _quizQuestions,
        answers: _answers,
        currentQuestionIndex: _currentQuestionIndex,
        onQuestionTap: _goToQuestion,
      ),
    );
  }

  void _submitQuiz() {
    // Check if all questions are answered
    final unansweredQuestions = <int>[];
    for (int i = 0; i < _quizQuestions.length; i++) {
      if (!_answers.containsKey(i)) {
        unansweredQuestions.add(i + 1);
      }
    }

    if (unansweredQuestions.isNotEmpty) {
      _showUnansweredQuestionsDialog(unansweredQuestions);
      return;
    }

    _showSubmitConfirmationDialog();
  }

  void _showUnansweredQuestionsDialog(List<int> unansweredQuestions) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'warning',
              color: AppTheme.lightTheme.colorScheme.error,
              size: 6.w,
            ),
            SizedBox(width: 2.w),
            Text('Incomplete Quiz'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'You have ${unansweredQuestions.length} unanswered question(s):',
              style: AppTheme.lightTheme.textTheme.bodyLarge,
            ),
            SizedBox(height: 2.h),
            Text(
              'Questions: ${unansweredQuestions.join(', ')}',
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.error,
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              'Would you like to review these questions before submitting?',
              style: AppTheme.lightTheme.textTheme.bodyMedium,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _finalSubmitQuiz();
            },
            child: Text('Submit Anyway'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _goToQuestion(unansweredQuestions.first - 1);
            },
            child: Text('Review Questions'),
          ),
        ],
      ),
    );
  }

  void _showSubmitConfirmationDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'quiz',
              color: AppTheme.lightTheme.colorScheme.primary,
              size: 6.w,
            ),
            SizedBox(width: 2.w),
            Text('Submit Quiz'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Are you sure you want to submit your quiz?',
              style: AppTheme.lightTheme.textTheme.bodyLarge,
            ),
            SizedBox(height: 2.h),
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.primary
                    .withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Total Questions:',
                          style: AppTheme.lightTheme.textTheme.bodyMedium),
                      Text('${_quizQuestions.length}',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(fontWeight: FontWeight.w600)),
                    ],
                  ),
                  SizedBox(height: 1.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Answered:',
                          style: AppTheme.lightTheme.textTheme.bodyMedium),
                      Text('${_answers.length}',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(fontWeight: FontWeight.w600)),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              'Once submitted, you cannot make any changes.',
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.error,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _finalSubmitQuiz();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
            ),
            child: Text('Submit Quiz'),
          ),
        ],
      ),
    );
  }

  void _finalSubmitQuiz() {
    setState(() {
      _isSubmitted = true;
      _isReviewMode = true;
      _currentQuestionIndex = 0;
    });

    // Calculate score
    int correctAnswers = 0;
    for (int i = 0; i < _quizQuestions.length; i++) {
      final question = _quizQuestions[i];
      final userAnswer = _answers[i];

      if (question['type'] == 'text_input') {
        // For text input, we'll consider it correct if it's not empty
        if (userAnswer != null && (userAnswer as String).trim().isNotEmpty) {
          correctAnswers++;
        }
      } else {
        if (userAnswer == question['correctAnswer']) {
          correctAnswers++;
        }
      }
    }

    final score = (correctAnswers / _quizQuestions.length * 100).round();

    // Show results
    _showQuizResults(correctAnswers, score);
  }

  void _autoSubmitQuiz() {
    setState(() {
      _isSubmitted = true;
      _isReviewMode = true;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'timer_off',
              color: Colors.white,
              size: 4.w,
            ),
            SizedBox(width: 2.w),
            Text('Time\'s up! Quiz submitted automatically.'),
          ],
        ),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        duration: Duration(seconds: 3),
      ),
    );
  }

  void _showQuizResults(int correctAnswers, int score) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            CustomIconWidget(
              iconName: score >= 70 ? 'celebration' : 'sentiment_neutral',
              color: score >= 70
                  ? AppTheme.lightTheme.colorScheme.tertiary
                  : AppTheme.lightTheme.colorScheme.error,
              size: 6.w,
            ),
            SizedBox(width: 2.w),
            Text('Quiz Complete!'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: score >= 70
                    ? AppTheme.lightTheme.colorScheme.tertiary
                        .withValues(alpha: 0.1)
                    : AppTheme.lightTheme.colorScheme.error
                        .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  Text(
                    'Your Score',
                    style: AppTheme.lightTheme.textTheme.titleMedium,
                  ),
                  SizedBox(height: 1.h),
                  Text(
                    '$score%',
                    style:
                        AppTheme.lightTheme.textTheme.displayMedium?.copyWith(
                      color: score >= 70
                          ? AppTheme.lightTheme.colorScheme.tertiary
                          : AppTheme.lightTheme.colorScheme.error,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    '$correctAnswers out of ${_quizQuestions.length} correct',
                    style: AppTheme.lightTheme.textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              score >= 70
                  ? 'Congratulations! You passed the quiz.'
                  : 'Keep studying and try again to improve your score.',
              style: AppTheme.lightTheme.textTheme.bodyLarge,
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/progress-tracking');
            },
            child: Text('View Progress'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _currentQuestionIndex = 0;
              });
            },
            child: Text('Review Answers'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: Column(
        children: [
          // Progress Header
          QuizProgressWidget(
            currentQuestion: _currentQuestionIndex + 1,
            totalQuestions: _quizQuestions.length,
            progressPercentage: _progressPercentage,
            timeRemaining: _timeRemaining,
            showTimer: _showTimer && !_isSubmitted,
          ),

          // Main Content
          Expanded(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(vertical: 2.h),
                child: QuizQuestionWidget(
                  question: _quizQuestions[_currentQuestionIndex],
                  selectedAnswer: _answers[_currentQuestionIndex],
                  onAnswerSelected: _onAnswerSelected,
                  isReviewMode: _isReviewMode,
                  showCorrectAnswer: _isSubmitted,
                ),
              ),
            ),
          ),

          // Navigation Controls
          if (!_isSubmitted)
            QuizNavigationWidget(
              canGoPrevious: _currentQuestionIndex > 0,
              canGoNext: _currentQuestionIndex < _quizQuestions.length - 1,
              isLastQuestion:
                  _currentQuestionIndex == _quizQuestions.length - 1,
              onPrevious: _goToPreviousQuestion,
              onNext: _goToNextQuestion,
              onSubmit: _submitQuiz,
              hasUnsavedChanges: _hasUnsavedChanges,
            ),
        ],
      ),

      // Floating Action Button for Quiz Overview
      floatingActionButton: FloatingActionButton(
        onPressed: _showQuizOverview,
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
        child: CustomIconWidget(
          iconName: 'grid_view',
          color: Colors.white,
          size: 6.w,
        ),
      ),

      // App Bar for Review Mode
      appBar: _isReviewMode
          ? AppBar(
              title: Text('Quiz Review'),
              leading: IconButton(
                icon: CustomIconWidget(
                  iconName: 'arrow_back',
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                  size: 6.w,
                ),
                onPressed: () =>
                    Navigator.pushNamed(context, '/progress-tracking'),
              ),
              actions: [
                IconButton(
                  icon: CustomIconWidget(
                    iconName: 'home',
                    color: AppTheme.lightTheme.colorScheme.onSurface,
                    size: 6.w,
                  ),
                  onPressed: () =>
                      Navigator.pushNamed(context, '/splash-screen'),
                ),
              ],
            )
          : null,
    );
  }
}
