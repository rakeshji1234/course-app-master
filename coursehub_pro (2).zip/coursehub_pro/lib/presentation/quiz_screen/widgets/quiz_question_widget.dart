import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class QuizQuestionWidget extends StatelessWidget {
  final Map<String, dynamic> question;
  final dynamic selectedAnswer;
  final Function(dynamic) onAnswerSelected;
  final bool isReviewMode;
  final bool showCorrectAnswer;

  const QuizQuestionWidget({
    super.key,
    required this.question,
    required this.selectedAnswer,
    required this.onAnswerSelected,
    this.isReviewMode = false,
    this.showCorrectAnswer = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Question Text
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(vertical: 3.h, horizontal: 4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.2),
              ),
            ),
            child: Text(
              question['question'] as String,
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                height: 1.5,
              ),
            ),
          ),

          SizedBox(height: 3.h),

          // Answer Options
          _buildAnswerOptions(),

          // Show explanation in review mode
          if (isReviewMode && question['explanation'] != null) ...[
            SizedBox(height: 2.h),
            _buildExplanation(),
          ],
        ],
      ),
    );
  }

  Widget _buildAnswerOptions() {
    final questionType = question['type'] as String;

    switch (questionType) {
      case 'multiple_choice':
        return _buildMultipleChoiceOptions();
      case 'true_false':
        return _buildTrueFalseOptions();
      case 'text_input':
        return _buildTextInputOption();
      default:
        return _buildMultipleChoiceOptions();
    }
  }

  Widget _buildMultipleChoiceOptions() {
    final options = question['options'] as List<dynamic>;

    return Column(
      children: options.asMap().entries.map((entry) {
        final index = entry.key;
        final option = entry.value as String;
        final isSelected = selectedAnswer == index;
        final isCorrect =
            showCorrectAnswer && question['correctAnswer'] == index;
        final isWrong = showCorrectAnswer &&
            isSelected &&
            question['correctAnswer'] != index;

        Color backgroundColor = AppTheme.lightTheme.colorScheme.surface;
        Color borderColor =
            AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3);
        Color textColor = AppTheme.lightTheme.colorScheme.onSurface;

        if (showCorrectAnswer) {
          if (isCorrect) {
            backgroundColor =
                AppTheme.lightTheme.colorScheme.tertiary.withValues(alpha: 0.1);
            borderColor = AppTheme.lightTheme.colorScheme.tertiary;
          } else if (isWrong) {
            backgroundColor =
                AppTheme.lightTheme.colorScheme.error.withValues(alpha: 0.1);
            borderColor = AppTheme.lightTheme.colorScheme.error;
          }
        } else if (isSelected) {
          backgroundColor =
              AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1);
          borderColor = AppTheme.lightTheme.colorScheme.primary;
        }

        return Container(
          margin: EdgeInsets.only(bottom: 2.h),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: isReviewMode ? null : () => onAnswerSelected(index),
              borderRadius: BorderRadius.circular(12),
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(vertical: 2.h, horizontal: 4.w),
                decoration: BoxDecoration(
                  color: backgroundColor,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: borderColor, width: 1.5),
                ),
                child: Row(
                  children: [
                    // Radio Button
                    Container(
                      width: 6.w,
                      height: 6.w,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: isSelected || isCorrect
                              ? (isCorrect
                                  ? AppTheme.lightTheme.colorScheme.tertiary
                                  : isWrong
                                      ? AppTheme.lightTheme.colorScheme.error
                                      : AppTheme.lightTheme.colorScheme.primary)
                              : AppTheme.lightTheme.colorScheme.outline,
                          width: 2,
                        ),
                        color: isSelected || isCorrect
                            ? (isCorrect
                                ? AppTheme.lightTheme.colorScheme.tertiary
                                : isWrong
                                    ? AppTheme.lightTheme.colorScheme.error
                                    : AppTheme.lightTheme.colorScheme.primary)
                            : Colors.transparent,
                      ),
                      child: isSelected || isCorrect
                          ? Center(
                              child: Container(
                                width: 2.w,
                                height: 2.w,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                ),
                              ),
                            )
                          : null,
                    ),

                    SizedBox(width: 3.w),

                    // Option Text
                    Expanded(
                      child: Text(
                        option,
                        style:
                            AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                          color: textColor,
                          fontWeight:
                              isSelected ? FontWeight.w500 : FontWeight.w400,
                        ),
                      ),
                    ),

                    // Correct/Wrong Indicator
                    if (showCorrectAnswer && (isCorrect || isWrong))
                      CustomIconWidget(
                        iconName: isCorrect ? 'check_circle' : 'cancel',
                        color: isCorrect
                            ? AppTheme.lightTheme.colorScheme.tertiary
                            : AppTheme.lightTheme.colorScheme.error,
                        size: 5.w,
                      ),
                  ],
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildTrueFalseOptions() {
    final options = ['True', 'False'];

    return Row(
      children: options.asMap().entries.map((entry) {
        final index = entry.key;
        final option = entry.value;
        final isSelected = selectedAnswer == index;
        final isCorrect =
            showCorrectAnswer && question['correctAnswer'] == index;
        final isWrong = showCorrectAnswer &&
            isSelected &&
            question['correctAnswer'] != index;

        Color backgroundColor = AppTheme.lightTheme.colorScheme.surface;
        Color borderColor =
            AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3);

        if (showCorrectAnswer) {
          if (isCorrect) {
            backgroundColor =
                AppTheme.lightTheme.colorScheme.tertiary.withValues(alpha: 0.1);
            borderColor = AppTheme.lightTheme.colorScheme.tertiary;
          } else if (isWrong) {
            backgroundColor =
                AppTheme.lightTheme.colorScheme.error.withValues(alpha: 0.1);
            borderColor = AppTheme.lightTheme.colorScheme.error;
          }
        } else if (isSelected) {
          backgroundColor =
              AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1);
          borderColor = AppTheme.lightTheme.colorScheme.primary;
        }

        return Expanded(
          child: Container(
            margin: EdgeInsets.only(right: index == 0 ? 2.w : 0),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: isReviewMode ? null : () => onAnswerSelected(index),
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  padding: EdgeInsets.symmetric(vertical: 2.5.h),
                  decoration: BoxDecoration(
                    color: backgroundColor,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: borderColor, width: 1.5),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (showCorrectAnswer && (isCorrect || isWrong))
                        Padding(
                          padding: EdgeInsets.only(right: 2.w),
                          child: CustomIconWidget(
                            iconName: isCorrect ? 'check_circle' : 'cancel',
                            color: isCorrect
                                ? AppTheme.lightTheme.colorScheme.tertiary
                                : AppTheme.lightTheme.colorScheme.error,
                            size: 5.w,
                          ),
                        ),
                      Text(
                        option,
                        style:
                            AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                          fontWeight:
                              isSelected ? FontWeight.w600 : FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildTextInputOption() {
    return Container(
      width: double.infinity,
      child: TextFormField(
        initialValue: selectedAnswer as String? ?? '',
        onChanged: isReviewMode ? null : onAnswerSelected,
        maxLines: null,
        keyboardType: TextInputType.multiline,
        decoration: InputDecoration(
          hintText: 'Type your answer here...',
          counterText: selectedAnswer != null
              ? '${(selectedAnswer as String).length} characters'
              : '0 characters',
          enabled: !isReviewMode,
        ),
        style: AppTheme.lightTheme.textTheme.bodyLarge,
      ),
    );
  }

  Widget _buildExplanation() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.tertiary.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color:
              AppTheme.lightTheme.colorScheme.tertiary.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'lightbulb',
                color: AppTheme.lightTheme.colorScheme.tertiary,
                size: 5.w,
              ),
              SizedBox(width: 2.w),
              Text(
                'Explanation',
                style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.tertiary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            question['explanation'] as String,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}
