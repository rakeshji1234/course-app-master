import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class QuizNavigationWidget extends StatelessWidget {
  final bool canGoPrevious;
  final bool canGoNext;
  final bool isLastQuestion;
  final VoidCallback? onPrevious;
  final VoidCallback? onNext;
  final VoidCallback? onSubmit;
  final bool hasUnsavedChanges;

  const QuizNavigationWidget({
    super.key,
    required this.canGoPrevious,
    required this.canGoNext,
    required this.isLastQuestion,
    this.onPrevious,
    this.onNext,
    this.onSubmit,
    this.hasUnsavedChanges = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: AppTheme.lightTheme.colorScheme.shadow,
            blurRadius: 8,
            offset: Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            // Previous Button
            Expanded(
              child: OutlinedButton(
                onPressed: canGoPrevious ? _handlePrevious : null,
                style: OutlinedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 2.h),
                  side: BorderSide(
                    color: canGoPrevious
                        ? AppTheme.lightTheme.colorScheme.outline
                        : AppTheme.lightTheme.colorScheme.outline
                            .withValues(alpha: 0.3),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomIconWidget(
                      iconName: 'arrow_back',
                      color: canGoPrevious
                          ? AppTheme.lightTheme.colorScheme.primary
                          : AppTheme.lightTheme.colorScheme.onSurfaceVariant
                              .withValues(alpha: 0.5),
                      size: 4.w,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Previous',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        color: canGoPrevious
                            ? AppTheme.lightTheme.colorScheme.primary
                            : AppTheme.lightTheme.colorScheme.onSurfaceVariant
                                .withValues(alpha: 0.5),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(width: 4.w),

            // Next/Submit Button
            Expanded(
              child: ElevatedButton(
                onPressed: isLastQuestion ? _handleSubmit : _handleNext,
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 2.h),
                  backgroundColor: isLastQuestion
                      ? AppTheme.lightTheme.colorScheme.tertiary
                      : AppTheme.lightTheme.colorScheme.primary,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      isLastQuestion ? 'Submit Quiz' : 'Next',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(width: 2.w),
                    CustomIconWidget(
                      iconName: isLastQuestion ? 'check' : 'arrow_forward',
                      color: Colors.white,
                      size: 4.w,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _handlePrevious() {
    if (hasUnsavedChanges) {
      // Show warning dialog for unsaved changes
      // For now, just call the callback
      onPrevious?.call();
    } else {
      onPrevious?.call();
    }
  }

  void _handleNext() {
    onNext?.call();
  }

  void _handleSubmit() {
    onSubmit?.call();
  }
}
