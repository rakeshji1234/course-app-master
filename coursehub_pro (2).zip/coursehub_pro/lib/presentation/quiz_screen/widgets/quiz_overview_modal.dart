import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class QuizOverviewModal extends StatelessWidget {
  final List<Map<String, dynamic>> questions;
  final Map<int, dynamic> answers;
  final int currentQuestionIndex;
  final Function(int) onQuestionTap;

  const QuizOverviewModal({
    super.key,
    required this.questions,
    required this.answers,
    required this.currentQuestionIndex,
    required this.onQuestionTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 70.h,
      width: double.infinity,
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Handle Bar
          Container(
            margin: EdgeInsets.only(top: 2.h),
            width: 12.w,
            height: 0.5.h,
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.outline
                  .withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Quiz Overview',
                  style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: CustomIconWidget(
                    iconName: 'close',
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    size: 6.w,
                  ),
                ),
              ],
            ),
          ),

          // Progress Summary
          Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w),
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.primary
                  .withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.primary
                    .withValues(alpha: 0.2),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildProgressStat(
                  'Answered',
                  answers.length.toString(),
                  AppTheme.lightTheme.colorScheme.tertiary,
                  'check_circle',
                ),
                _buildProgressStat(
                  'Remaining',
                  (questions.length - answers.length).toString(),
                  AppTheme.lightTheme.colorScheme.error,
                  'radio_button_unchecked',
                ),
                _buildProgressStat(
                  'Total',
                  questions.length.toString(),
                  AppTheme.lightTheme.colorScheme.primary,
                  'quiz',
                ),
              ],
            ),
          ),

          SizedBox(height: 2.h),

          // Questions Grid
          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 5,
                  crossAxisSpacing: 2.w,
                  mainAxisSpacing: 2.w,
                  childAspectRatio: 1,
                ),
                itemCount: questions.length,
                itemBuilder: (context, index) {
                  final isAnswered = answers.containsKey(index);
                  final isCurrent = index == currentQuestionIndex;

                  Color backgroundColor =
                      AppTheme.lightTheme.colorScheme.surface;
                  Color borderColor = AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.3);
                  Color textColor =
                      AppTheme.lightTheme.colorScheme.onSurfaceVariant;

                  if (isCurrent) {
                    backgroundColor = AppTheme.lightTheme.colorScheme.primary;
                    borderColor = AppTheme.lightTheme.colorScheme.primary;
                    textColor = Colors.white;
                  } else if (isAnswered) {
                    backgroundColor = AppTheme.lightTheme.colorScheme.tertiary
                        .withValues(alpha: 0.1);
                    borderColor = AppTheme.lightTheme.colorScheme.tertiary;
                    textColor = AppTheme.lightTheme.colorScheme.tertiary;
                  }

                  return Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(context);
                        onQuestionTap(index);
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        decoration: BoxDecoration(
                          color: backgroundColor,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: borderColor, width: 1.5),
                        ),
                        child: Stack(
                          children: [
                            Center(
                              child: Text(
                                '${index + 1}',
                                style: AppTheme.lightTheme.textTheme.titleMedium
                                    ?.copyWith(
                                  color: textColor,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),

                            // Status Indicator
                            if (isAnswered && !isCurrent)
                              Positioned(
                                top: 1.w,
                                right: 1.w,
                                child: Container(
                                  width: 3.w,
                                  height: 3.w,
                                  decoration: BoxDecoration(
                                    color: AppTheme
                                        .lightTheme.colorScheme.tertiary,
                                    shape: BoxShape.circle,
                                  ),
                                  child: CustomIconWidget(
                                    iconName: 'check',
                                    color: Colors.white,
                                    size: 2.w,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          // Bottom Actions
          Container(
            padding: EdgeInsets.all(4.w),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    style: OutlinedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 2.h),
                    ),
                    child: Text('Close'),
                  ),
                ),
                SizedBox(width: 4.w),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      // Navigate to first unanswered question
                      final firstUnanswered = questions
                          .asMap()
                          .entries
                          .firstWhere(
                            (entry) => !answers.containsKey(entry.key),
                            orElse: () => MapEntry(currentQuestionIndex,
                                questions[currentQuestionIndex]),
                          )
                          .key;
                      onQuestionTap(firstUnanswered);
                    },
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 2.h),
                    ),
                    child: Text('Continue'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressStat(
      String label, String value, Color color, String iconName) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        CustomIconWidget(
          iconName: iconName,
          color: color,
          size: 6.w,
        ),
        SizedBox(height: 1.h),
        Text(
          value,
          style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
            color: color,
            fontWeight: FontWeight.w700,
          ),
        ),
        Text(
          label,
          style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}
