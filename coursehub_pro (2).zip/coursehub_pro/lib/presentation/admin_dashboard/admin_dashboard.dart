import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/activity_item_widget.dart';
import './widgets/analytics_card_widget.dart';
import './widgets/device_status_widget.dart';
import './widgets/metric_card_widget.dart';
import './widgets/quick_action_widget.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({Key? key}) : super(key: key);

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool _isRefreshing = false;

  // Mock data for dashboard metrics
  final List<Map<String, dynamic>> _metricsData = [
    {
      "title": "Active Users",
      "value": "2,847",
      "subtitle": "+12% from last week",
      "icon": "people",
      "color": const Color(0xFF10B981),
    },
    {
      "title": "Enrollments",
      "value": "1,234",
      "subtitle": "+8% from last week",
      "icon": "school",
      "color": const Color(0xFF3B82F6),
    },
    {
      "title": "Revenue Today",
      "value": "\$4,567",
      "subtitle": "+15% from yesterday",
      "icon": "attach_money",
      "color": const Color(0xFFF59E0B),
    },
    {
      "title": "System Health",
      "value": "99.8%",
      "subtitle": "All systems operational",
      "icon": "health_and_safety",
      "color": const Color(0xFF10B981),
    },
  ];

  // Mock data for user engagement chart
  final List<Map<String, dynamic>> _userEngagementData = [
    {"label": "Mon", "value": 1200},
    {"label": "Tue", "value": 1450},
    {"label": "Wed", "value": 1100},
    {"label": "Thu", "value": 1680},
    {"label": "Fri", "value": 1890},
    {"label": "Sat", "value": 1340},
    {"label": "Sun", "value": 980},
  ];

  // Mock data for course performance
  final List<Map<String, dynamic>> _coursePerformanceData = [
    {"label": "Flutter", "value": 450},
    {"label": "React", "value": 380},
    {"label": "Python", "value": 320},
    {"label": "Java", "value": 280},
    {"label": "Swift", "value": 220},
  ];

  // Mock data for revenue analytics
  final List<Map<String, dynamic>> _revenueData = [
    {"label": "Stripe", "value": 45, "color": const Color(0xFF6366F1)},
    {"label": "PayPal", "value": 30, "color": const Color(0xFF10B981)},
    {"label": "Razorpay", "value": 25, "color": const Color(0xFFF59E0B)},
  ];

  // Mock data for recent activities
  final List<Map<String, dynamic>> _recentActivities = [
    {
      "title": "New User Registration",
      "description": "Sarah Johnson joined the platform",
      "timestamp": "2 minutes ago",
      "icon": "person_add",
      "color": const Color(0xFF10B981),
      "actionText": "View",
    },
    {
      "title": "Course Purchase",
      "description": "Flutter Development course purchased by Mike Chen",
      "timestamp": "5 minutes ago",
      "icon": "shopping_cart",
      "color": const Color(0xFF3B82F6),
      "actionText": "Details",
    },
    {
      "title": "Payment Failed",
      "description": "Transaction failed for user Emma Wilson",
      "timestamp": "12 minutes ago",
      "icon": "error",
      "color": const Color(0xFFEF4444),
      "actionText": "Resolve",
    },
    {
      "title": "System Alert",
      "description": "Server response time increased to 450ms",
      "timestamp": "18 minutes ago",
      "icon": "warning",
      "color": const Color(0xFFF59E0B),
      "actionText": "Check",
    },
  ];

  // Mock data for device management
  final List<Map<String, dynamic>> _deviceViolations = [
    {
      "userName": "Alex Thompson",
      "userEmail": "alex.thompson@email.com",
      "deviceCount": 3,
      "hasViolation": true,
      "lastActive": "2 hours ago",
    },
    {
      "userName": "Maria Garcia",
      "userEmail": "maria.garcia@email.com",
      "deviceCount": 2,
      "hasViolation": false,
      "lastActive": "1 hour ago",
    },
    {
      "userName": "David Kim",
      "userEmail": "david.kim@email.com",
      "deviceCount": 4,
      "hasViolation": true,
      "lastActive": "30 minutes ago",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      drawer: _buildNavigationDrawer(),
      appBar: _buildAppBar(),
      body: RefreshIndicator(
        onRefresh: _handleRefresh,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildMetricsSection(),
              SizedBox(height: 2.h),
              _buildQuickActionsSection(),
              SizedBox(height: 3.h),
              _buildAnalyticsSection(),
              SizedBox(height: 3.h),
              _buildRecentActivitySection(),
              SizedBox(height: 3.h),
              _buildDeviceManagementSection(),
              SizedBox(height: 2.h),
            ],
          ),
        ),
      ),
      floatingActionButton: _buildFloatingActionButton(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      elevation: 0,
      leading: IconButton(
        onPressed: () => _scaffoldKey.currentState?.openDrawer(),
        icon: CustomIconWidget(
          iconName: 'menu',
          color: AppTheme.lightTheme.colorScheme.onSurface,
          size: 24,
        ),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Admin Dashboard",
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
              color: AppTheme.lightTheme.colorScheme.onSurface,
            ),
          ),
          Text(
            "CourseHub Pro Management",
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          onPressed: _showNotifications,
          icon: Stack(
            children: [
              CustomIconWidget(
                iconName: 'notifications',
                color: AppTheme.lightTheme.colorScheme.onSurface,
                size: 24,
              ),
              Positioned(
                right: 0,
                top: 0,
                child: Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.error,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(width: 2.w),
      ],
    );
  }

  Widget _buildNavigationDrawer() {
    return Drawer(
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      child: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.primary
                    .withValues(alpha: 0.1),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 8.w,
                    backgroundColor: AppTheme.lightTheme.colorScheme.primary,
                    child: CustomIconWidget(
                      iconName: 'admin_panel_settings',
                      color: Colors.white,
                      size: 32,
                    ),
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    "Admin Portal",
                    style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: AppTheme.lightTheme.colorScheme.onSurface,
                    ),
                  ),
                  Text(
                    "admin@coursehubpro.com",
                    style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.symmetric(vertical: 2.h),
                children: [
                  _buildDrawerItem(
                    icon: 'dashboard',
                    title: 'Dashboard',
                    isSelected: true,
                    onTap: () => Navigator.pop(context),
                  ),
                  _buildDrawerItem(
                    icon: 'school',
                    title: 'Course Management',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/course-management');
                    },
                  ),
                  _buildDrawerItem(
                    icon: 'quiz',
                    title: 'Quiz Management',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/quiz-screen');
                    },
                  ),
                  _buildDrawerItem(
                    icon: 'payment',
                    title: 'Payment Analytics',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/payment-checkout');
                    },
                  ),
                  _buildDrawerItem(
                    icon: 'trending_up',
                    title: 'Progress Tracking',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/progress-tracking');
                    },
                  ),
                  _buildDrawerItem(
                    icon: 'people',
                    title: 'User Management',
                    onTap: () => _showComingSoon(),
                  ),
                  _buildDrawerItem(
                    icon: 'settings',
                    title: 'Settings',
                    onTap: () => _showComingSoon(),
                  ),
                  Divider(
                    color: AppTheme.lightTheme.colorScheme.outline
                        .withValues(alpha: 0.2),
                    height: 4.h,
                  ),
                  _buildDrawerItem(
                    icon: 'logout',
                    title: 'Logout',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/splash-screen');
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerItem({
    required String icon,
    required String title,
    required VoidCallback onTap,
    bool isSelected = false,
  }) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
      decoration: BoxDecoration(
        color: isSelected
            ? AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1)
            : Colors.transparent,
        borderRadius: BorderRadius.circular(8),
      ),
      child: ListTile(
        leading: CustomIconWidget(
          iconName: icon,
          color: isSelected
              ? AppTheme.lightTheme.colorScheme.primary
              : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          size: 24,
        ),
        title: Text(
          title,
          style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
            color: isSelected
                ? AppTheme.lightTheme.colorScheme.primary
                : AppTheme.lightTheme.colorScheme.onSurface,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
          ),
        ),
        onTap: onTap,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }

  Widget _buildMetricsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          child: Text(
            "Key Metrics",
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
              color: AppTheme.lightTheme.colorScheme.onSurface,
            ),
          ),
        ),
        Container(
          height: 18.h,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: 2.w),
            itemCount: _metricsData.length,
            itemBuilder: (context, index) {
              final metric = _metricsData[index];
              return MetricCardWidget(
                title: metric["title"] as String,
                value: metric["value"] as String,
                subtitle: metric["subtitle"] as String,
                iconName: metric["icon"] as String,
                iconColor: metric["color"] as Color,
                onTap: () => _showMetricDetails(metric["title"] as String),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildQuickActionsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          child: Text(
            "Quick Actions",
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
              color: AppTheme.lightTheme.colorScheme.onSurface,
            ),
          ),
        ),
        Container(
          height: 14.h,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: 2.w),
            children: [
              QuickActionWidget(
                title: "Add Course",
                iconName: "add_circle",
                backgroundColor: AppTheme.lightTheme.colorScheme.primary,
                onTap: () => Navigator.pushNamed(context, '/course-management'),
              ),
              QuickActionWidget(
                title: "Send Notification",
                iconName: "notifications_active",
                backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
                onTap: () => _showSendNotification(),
              ),
              QuickActionWidget(
                title: "Export Report",
                iconName: "file_download",
                backgroundColor: const Color(0xFFF59E0B),
                onTap: () => _exportReport(),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAnalyticsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          child: Text(
            "Analytics Overview",
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
              color: AppTheme.lightTheme.colorScheme.onSurface,
            ),
          ),
        ),
        AnalyticsCardWidget(
          title: "User Engagement",
          subtitle: "Daily active users trend for the past week",
          chartData: _userEngagementData,
          chartType: "line",
          onTap: () => _showDetailedAnalytics("User Engagement"),
        ),
        SizedBox(height: 2.h),
        AnalyticsCardWidget(
          title: "Course Performance",
          subtitle: "Top performing courses by enrollment",
          chartData: _coursePerformanceData,
          chartType: "bar",
          onTap: () => _showDetailedAnalytics("Course Performance"),
        ),
        SizedBox(height: 2.h),
        AnalyticsCardWidget(
          title: "Revenue Analytics",
          subtitle: "Payment method distribution",
          chartData: _revenueData,
          chartType: "pie",
          onTap: () => _showDetailedAnalytics("Revenue Analytics"),
        ),
      ],
    );
  }

  Widget _buildRecentActivitySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Recent Activity",
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
              GestureDetector(
                onTap: () => _showAllActivities(),
                child: Text(
                  "View All",
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _recentActivities.length,
          itemBuilder: (context, index) {
            final activity = _recentActivities[index];
            return ActivityItemWidget(
              title: activity["title"] as String,
              description: activity["description"] as String,
              timestamp: activity["timestamp"] as String,
              iconName: activity["icon"] as String,
              iconColor: activity["color"] as Color,
              actionText: activity["actionText"] as String?,
              onActionTap: () =>
                  _handleActivityAction(activity["title"] as String),
            );
          },
        ),
      ],
    );
  }

  Widget _buildDeviceManagementSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Device Management",
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.error
                      .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  "${_deviceViolations.where((device) => device["hasViolation"] as bool).length} Violations",
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.error,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _deviceViolations.length,
          itemBuilder: (context, index) {
            final device = _deviceViolations[index];
            return DeviceStatusWidget(
              userName: device["userName"] as String,
              userEmail: device["userEmail"] as String,
              deviceCount: device["deviceCount"] as int,
              hasViolation: device["hasViolation"] as bool,
              lastActive: device["lastActive"] as String,
              onManageTap: () =>
                  _manageUserDevices(device["userName"] as String),
            );
          },
        ),
      ],
    );
  }

  Widget _buildFloatingActionButton() {
    return FloatingActionButton.extended(
      onPressed: () => _showQuickMenu(),
      backgroundColor: AppTheme.lightTheme.colorScheme.primary,
      foregroundColor: Colors.white,
      icon: CustomIconWidget(
        iconName: 'add',
        color: Colors.white,
        size: 24,
      ),
      label: Text(
        "Quick Menu",
        style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
          color: Colors.white,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Future<void> _handleRefresh() async {
    setState(() {
      _isRefreshing = true;
    });

    // Simulate API call
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      _isRefreshing = false;
    });

    Fluttertoast.showToast(
      msg: "Dashboard data refreshed successfully",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _showNotifications() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: EdgeInsets.all(4.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Notifications",
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 2.h),
              ListTile(
                leading: CustomIconWidget(
                  iconName: 'warning',
                  color: AppTheme.lightTheme.colorScheme.error,
                  size: 24,
                ),
                title: Text("Payment System Alert"),
                subtitle: Text("3 failed transactions in the last hour"),
                trailing: Text("5 min ago"),
              ),
              ListTile(
                leading: CustomIconWidget(
                  iconName: 'info',
                  color: AppTheme.lightTheme.colorScheme.primary,
                  size: 24,
                ),
                title: Text("System Maintenance"),
                subtitle: Text("Scheduled maintenance at 2:00 AM UTC"),
                trailing: Text("1 hour ago"),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showMetricDetails(String metricTitle) {
    Fluttertoast.showToast(
      msg: "Showing detailed view for $metricTitle",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _showDetailedAnalytics(String analyticsType) {
    Fluttertoast.showToast(
      msg: "Opening detailed $analyticsType analytics",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _showSendNotification() {
    Fluttertoast.showToast(
      msg: "Opening notification composer",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _exportReport() {
    Fluttertoast.showToast(
      msg: "Generating and downloading report...",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _showAllActivities() {
    Fluttertoast.showToast(
      msg: "Opening complete activity log",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _handleActivityAction(String activityTitle) {
    Fluttertoast.showToast(
      msg: "Handling action for: $activityTitle",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _manageUserDevices(String userName) {
    Fluttertoast.showToast(
      msg: "Managing devices for $userName",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _showQuickMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: EdgeInsets.all(4.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Quick Actions",
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 2.h),
              ListTile(
                leading: CustomIconWidget(
                  iconName: 'add_circle',
                  color: AppTheme.lightTheme.colorScheme.primary,
                  size: 24,
                ),
                title: Text("Add New Course"),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/course-management');
                },
              ),
              ListTile(
                leading: CustomIconWidget(
                  iconName: 'notifications_active',
                  color: AppTheme.lightTheme.colorScheme.tertiary,
                  size: 24,
                ),
                title: Text("Send Notification"),
                onTap: () {
                  Navigator.pop(context);
                  _showSendNotification();
                },
              ),
              ListTile(
                leading: CustomIconWidget(
                  iconName: 'file_download',
                  color: const Color(0xFFF59E0B),
                  size: 24,
                ),
                title: Text("Export Analytics Report"),
                onTap: () {
                  Navigator.pop(context);
                  _exportReport();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showComingSoon() {
    Fluttertoast.showToast(
      msg: "Feature coming soon!",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }
}
