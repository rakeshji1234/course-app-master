import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/course_card_widget.dart';
import './widgets/filter_panel_widget.dart';
import './widgets/search_bar_widget.dart';
import './widgets/sort_dropdown_widget.dart';

class CourseCatalog extends StatefulWidget {
  const CourseCatalog({Key? key}) : super(key: key);

  @override
  State<CourseCatalog> createState() => _CourseCatalogState();
}

class _CourseCatalogState extends State<CourseCatalog> {
  String _searchQuery = '';
  String _selectedSort = 'popularity';
  bool _isFilterVisible = false;
  bool _isLoading = false;

  Map<String, dynamic> _filters = {
    'category': 'All Categories',
    'skillLevel': 'All Levels',
    'duration': 'Any Duration',
    'minPrice': 0.0,
    'maxPrice': 10000.0,
    'minRating': 0.0,
    'freeOnly': false,
  };

  // Mock course data
  final List<Map<String, dynamic>> _allCourses = [
    {
      "id": 1,
      "title": "Complete Flutter Development Bootcamp with Dart",
      "instructor": "Dr. Angela Yu",
      "thumbnail":
          "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "rating": 4.8,
      "students": 15420,
      "price": 3499.0,
      "originalPrice": 4999.0,
      "category": "Programming",
      "skillLevel": "Beginner",
      "duration": "42 hours",
      "isPopular": true,
      "createdAt": DateTime.now().subtract(const Duration(days: 30)),
    },
    {
      "id": 2,
      "title": "UI/UX Design Masterclass: Adobe XD & Figma",
      "instructor": "Sarah Johnson",
      "thumbnail":
          "https://images.unsplash.com/photo-1561070791-2526d30994b5?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "rating": 4.7,
      "students": 8950,
      "price": 0.0,
      "originalPrice": 0.0,
      "category": "Design",
      "skillLevel": "Intermediate",
      "duration": "28 hours",
      "isPopular": false,
      "createdAt": DateTime.now().subtract(const Duration(days: 15)),
    },
    {
      "id": 3,
      "title": "Digital Marketing Strategy & Social Media",
      "instructor": "Mark Thompson",
      "thumbnail":
          "https://images.unsplash.com/photo-1460925895917-afdab827c52f?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "rating": 4.6,
      "students": 12300,
      "price": 2799.0,
      "originalPrice": 3999.0,
      "category": "Marketing",
      "skillLevel": "Beginner",
      "duration": "35 hours",
      "isPopular": true,
      "createdAt": DateTime.now().subtract(const Duration(days: 45)),
    },
    {
      "id": 4,
      "title": "Data Science with Python and Machine Learning",
      "instructor": "Prof. David Chen",
      "thumbnail":
          "https://images.unsplash.com/photo-1551288049-bebda4e38f71?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "rating": 4.9,
      "students": 6780,
      "price": 4999.0,
      "originalPrice": 6999.0,
      "category": "Data Science",
      "skillLevel": "Advanced",
      "duration": "65 hours",
      "isPopular": true,
      "createdAt": DateTime.now().subtract(const Duration(days: 60)),
    },
    {
      "id": 5,
      "title": "Photography Fundamentals: From Beginner to Pro",
      "instructor": "Emma Wilson",
      "thumbnail":
          "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "rating": 4.5,
      "students": 4560,
      "price": 1999.0,
      "originalPrice": 2999.0,
      "category": "Photography",
      "skillLevel": "Beginner",
      "duration": "18 hours",
      "isPopular": false,
      "createdAt": DateTime.now().subtract(const Duration(days: 20)),
    },
    {
      "id": 6,
      "title": "Business Strategy and Entrepreneurship",
      "instructor": "Michael Roberts",
      "thumbnail":
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "rating": 4.4,
      "students": 9870,
      "price": 0.0,
      "originalPrice": 0.0,
      "category": "Business",
      "skillLevel": "Intermediate",
      "duration": "24 hours",
      "isPopular": false,
      "createdAt": DateTime.now().subtract(const Duration(days: 10)),
    },
    {
      "id": 7,
      "title": "Music Production with Logic Pro X",
      "instructor": "Alex Martinez",
      "thumbnail":
          "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "rating": 4.7,
      "students": 3420,
      "price": 3299.0,
      "originalPrice": 4499.0,
      "category": "Music",
      "skillLevel": "Intermediate",
      "duration": "32 hours",
      "isPopular": false,
      "createdAt": DateTime.now().subtract(const Duration(days: 25)),
    },
    {
      "id": 8,
      "title": "Yoga & Meditation for Beginners",
      "instructor": "Lisa Anderson",
      "thumbnail":
          "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "rating": 4.8,
      "students": 7650,
      "price": 1499.0,
      "originalPrice": 2199.0,
      "category": "Health & Fitness",
      "skillLevel": "Beginner",
      "duration": "15 hours",
      "isPopular": true,
      "createdAt": DateTime.now().subtract(const Duration(days: 5)),
    },
  ];

  List<Map<String, dynamic>> get _filteredCourses {
    List<Map<String, dynamic>> filtered = List.from(_allCourses);

    // Apply search filter
    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((course) {
        final title = (course["title"] as String).toLowerCase();
        final instructor = (course["instructor"] as String).toLowerCase();
        final category = (course["category"] as String).toLowerCase();
        final query = _searchQuery.toLowerCase();

        return title.contains(query) ||
            instructor.contains(query) ||
            category.contains(query);
      }).toList();
    }

    // Apply category filter
    if (_filters['category'] != 'All Categories') {
      filtered = filtered
          .where((course) => course["category"] == _filters['category'])
          .toList();
    }

    // Apply skill level filter
    if (_filters['skillLevel'] != 'All Levels') {
      filtered = filtered
          .where((course) => course["skillLevel"] == _filters['skillLevel'])
          .toList();
    }

    // Apply price range filter
    filtered = filtered.where((course) {
      final price = course["price"] as double;
      return price >= (_filters['minPrice'] as double) &&
          price <= (_filters['maxPrice'] as double);
    }).toList();

    // Apply rating filter
    filtered = filtered.where((course) {
      final rating = course["rating"] as double;
      return rating >= (_filters['minRating'] as double);
    }).toList();

    // Apply free only filter
    if (_filters['freeOnly'] as bool) {
      filtered = filtered
          .where((course) => (course["price"] as double) == 0.0)
          .toList();
    }

    // Apply sorting
    switch (_selectedSort) {
      case 'popularity':
        filtered.sort((a, b) {
          final aPopular = a["isPopular"] as bool ? 1 : 0;
          final bPopular = b["isPopular"] as bool ? 1 : 0;
          if (aPopular != bPopular) return bPopular.compareTo(aPopular);
          return (b["students"] as int).compareTo(a["students"] as int);
        });
        break;
      case 'rating':
        filtered.sort(
            (a, b) => (b["rating"] as double).compareTo(a["rating"] as double));
        break;
      case 'price_low':
        filtered.sort(
            (a, b) => (a["price"] as double).compareTo(b["price"] as double));
        break;
      case 'price_high':
        filtered.sort(
            (a, b) => (b["price"] as double).compareTo(a["price"] as double));
        break;
      case 'newest':
        filtered.sort((a, b) =>
            (b["createdAt"] as DateTime).compareTo(a["createdAt"] as DateTime));
        break;
      case 'title':
        filtered.sort(
            (a, b) => (a["title"] as String).compareTo(b["title"] as String));
        break;
    }

    return filtered;
  }

  void _onSearchChanged(String query) {
    setState(() {
      _searchQuery = query;
    });
  }

  void _onSortChanged(String sort) {
    setState(() {
      _selectedSort = sort;
    });
  }

  void _onFiltersChanged(Map<String, dynamic> filters) {
    setState(() {
      _filters = filters;
    });
  }

  void _toggleFilterPanel() {
    setState(() {
      _isFilterVisible = !_isFilterVisible;
    });
  }

  void _closeFilterPanel() {
    setState(() {
      _isFilterVisible = false;
    });
  }

  void _onCourseCardTap(Map<String, dynamic> course) {
    // Navigate to course details
    Navigator.pushNamed(context, '/course-details', arguments: course);
  }

  @override
  Widget build(BuildContext context) {
    final filteredCourses = _filteredCourses;

    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          "Course Catalog",
          style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        backgroundColor: AppTheme.lightTheme.colorScheme.surface,
        elevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 24,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () => Navigator.pushNamed(context, '/student-dashboard'),
            icon: CustomIconWidget(
              iconName: 'dashboard',
              color: AppTheme.lightTheme.colorScheme.onSurface,
              size: 24,
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          Column(
            children: [
              // Search bar
              SearchBarWidget(
                searchQuery: _searchQuery,
                onSearchChanged: _onSearchChanged,
                onFilterTap: _toggleFilterPanel,
              ),

              // Sort dropdown
              SortDropdownWidget(
                selectedSort: _selectedSort,
                onSortChanged: _onSortChanged,
                totalCourses: filteredCourses.length,
              ),

              // Course grid
              Expanded(
                child: _isLoading
                    ? _buildLoadingState()
                    : filteredCourses.isEmpty
                        ? _buildEmptyState()
                        : _buildCourseGrid(filteredCourses),
              ),
            ],
          ),

          // Filter panel overlay
          FilterPanelWidget(
            filters: _filters,
            onFiltersChanged: _onFiltersChanged,
            isVisible: _isFilterVisible,
            onClose: _closeFilterPanel,
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            color: AppTheme.lightTheme.colorScheme.primary,
          ),
          SizedBox(height: 2.h),
          Text(
            "Loading courses...",
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(8.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'search_off',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 64,
            ),
            SizedBox(height: 3.h),
            Text(
              "No courses found",
              style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              "Try adjusting your search or filters to find what you're looking for.",
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 3.h),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _searchQuery = '';
                  _filters = {
                    'category': 'All Categories',
                    'skillLevel': 'All Levels',
                    'duration': 'Any Duration',
                    'minPrice': 0.0,
                    'maxPrice': 10000.0,
                    'minRating': 0.0,
                    'freeOnly': false,
                  };
                });
              },
              child: Text("Clear All Filters"),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCourseGrid(List<Map<String, dynamic>> courses) {
    return LayoutBuilder(
      builder: (context, constraints) {
        // Determine grid layout based on screen width
        int crossAxisCount;
        double childAspectRatio;

        if (constraints.maxWidth > 1200) {
          // Large desktop
          crossAxisCount = 4;
          childAspectRatio = 0.75;
        } else if (constraints.maxWidth > 800) {
          // Tablet/small desktop
          crossAxisCount = 3;
          childAspectRatio = 0.75;
        } else if (constraints.maxWidth > 600) {
          // Large mobile/small tablet
          crossAxisCount = 2;
          childAspectRatio = 0.7;
        } else {
          // Mobile
          crossAxisCount = 1;
          childAspectRatio = 1.2;
        }

        return GridView.builder(
          padding: EdgeInsets.all(4.w),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            childAspectRatio: childAspectRatio,
            crossAxisSpacing: 4.w,
            mainAxisSpacing: 3.h,
          ),
          itemCount: courses.length,
          itemBuilder: (context, index) {
            final course = courses[index];
            return CourseCardWidget(
              course: course,
              onTap: () => _onCourseCardTap(course),
            );
          },
        );
      },
    );
  }
}
