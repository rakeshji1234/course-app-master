import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class FilterPanelWidget extends StatefulWidget {
  final Map<String, dynamic> filters;
  final Function(Map<String, dynamic>) onFiltersChanged;
  final bool isVisible;
  final VoidCallback onClose;

  const FilterPanelWidget({
    Key? key,
    required this.filters,
    required this.onFiltersChanged,
    required this.isVisible,
    required this.onClose,
  }) : super(key: key);

  @override
  State<FilterPanelWidget> createState() => _FilterPanelWidgetState();
}

class _FilterPanelWidgetState extends State<FilterPanelWidget> {
  late Map<String, dynamic> _localFilters;

  final List<String> categories = [
    'All Categories',
    'Programming',
    'Design',
    'Business',
    'Marketing',
    'Data Science',
    'Photography',
    'Music',
    'Health & Fitness',
  ];

  final List<String> skillLevels = [
    'All Levels',
    'Beginner',
    'Intermediate',
    'Advanced',
  ];

  final List<String> durations = [
    'Any Duration',
    '0-2 hours',
    '3-6 hours',
    '7-17 hours',
    '17+ hours',
  ];

  @override
  void initState() {
    super.initState();
    _localFilters = Map<String, dynamic>.from(widget.filters);
  }

  @override
  void didUpdateWidget(FilterPanelWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.filters != widget.filters) {
      _localFilters = Map<String, dynamic>.from(widget.filters);
    }
  }

  void _updateFilter(String key, dynamic value) {
    setState(() {
      _localFilters[key] = value;
    });
    widget.onFiltersChanged(_localFilters);
  }

  void _clearAllFilters() {
    setState(() {
      _localFilters = {
        'category': 'All Categories',
        'skillLevel': 'All Levels',
        'duration': 'Any Duration',
        'minPrice': 0.0,
        'maxPrice': 10000.0,
        'minRating': 0.0,
        'freeOnly': false,
      };
    });
    widget.onFiltersChanged(_localFilters);
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isVisible) return const SizedBox.shrink();

    return Container(
      width: double.infinity,
      height: 100.h,
      color: AppTheme.lightTheme.colorScheme.surface.withValues(alpha: 0.95),
      child: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface,
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.lightTheme.colorScheme.shadow
                        .withValues(alpha: 0.1),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Filter Courses",
                    style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Row(
                    children: [
                      TextButton(
                        onPressed: _clearAllFilters,
                        child: Text(
                          "Clear All",
                          style: AppTheme.lightTheme.textTheme.labelMedium
                              ?.copyWith(
                            color: AppTheme.lightTheme.colorScheme.primary,
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: widget.onClose,
                        icon: CustomIconWidget(
                          iconName: 'close',
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                          size: 24,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Filter content
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.all(4.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Category filter
                    _buildFilterSection(
                      title: "Category",
                      child: _buildDropdown(
                        value: _localFilters['category'] as String? ??
                            'All Categories',
                        items: categories,
                        onChanged: (value) => _updateFilter('category', value),
                      ),
                    ),

                    SizedBox(height: 3.h),

                    // Skill level filter
                    _buildFilterSection(
                      title: "Skill Level",
                      child: _buildDropdown(
                        value: _localFilters['skillLevel'] as String? ??
                            'All Levels',
                        items: skillLevels,
                        onChanged: (value) =>
                            _updateFilter('skillLevel', value),
                      ),
                    ),

                    SizedBox(height: 3.h),

                    // Duration filter
                    _buildFilterSection(
                      title: "Duration",
                      child: _buildDropdown(
                        value: _localFilters['duration'] as String? ??
                            'Any Duration',
                        items: durations,
                        onChanged: (value) => _updateFilter('duration', value),
                      ),
                    ),

                    SizedBox(height: 3.h),

                    // Price range filter
                    _buildFilterSection(
                      title: "Price Range",
                      child: Column(
                        children: [
                          RangeSlider(
                            values: RangeValues(
                              (_localFilters['minPrice'] as double?) ?? 0.0,
                              (_localFilters['maxPrice'] as double?) ?? 10000.0,
                            ),
                            min: 0,
                            max: 10000,
                            divisions: 100,
                            labels: RangeLabels(
                              "₹${(_localFilters['minPrice'] as double? ?? 0.0).toStringAsFixed(0)}",
                              "₹${(_localFilters['maxPrice'] as double? ?? 10000.0).toStringAsFixed(0)}",
                            ),
                            onChanged: (values) {
                              _updateFilter('minPrice', values.start);
                              _updateFilter('maxPrice', values.end);
                            },
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "₹${(_localFilters['minPrice'] as double? ?? 0.0).toStringAsFixed(0)}",
                                style: AppTheme.lightTheme.textTheme.bodySmall,
                              ),
                              Text(
                                "₹${(_localFilters['maxPrice'] as double? ?? 10000.0).toStringAsFixed(0)}",
                                style: AppTheme.lightTheme.textTheme.bodySmall,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    SizedBox(height: 3.h),

                    // Rating filter
                    _buildFilterSection(
                      title: "Minimum Rating",
                      child: Column(
                        children: [
                          Slider(
                            value:
                                (_localFilters['minRating'] as double?) ?? 0.0,
                            min: 0,
                            max: 5,
                            divisions: 10,
                            label:
                                "${(_localFilters['minRating'] as double? ?? 0.0).toStringAsFixed(1)} stars",
                            onChanged: (value) =>
                                _updateFilter('minRating', value),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("0 stars",
                                  style:
                                      AppTheme.lightTheme.textTheme.bodySmall),
                              Text("5 stars",
                                  style:
                                      AppTheme.lightTheme.textTheme.bodySmall),
                            ],
                          ),
                        ],
                      ),
                    ),

                    SizedBox(height: 3.h),

                    // Free courses only
                    _buildFilterSection(
                      title: "Price",
                      child: CheckboxListTile(
                        title: Text(
                          "Free courses only",
                          style: AppTheme.lightTheme.textTheme.bodyMedium,
                        ),
                        value: (_localFilters['freeOnly'] as bool?) ?? false,
                        onChanged: (value) =>
                            _updateFilter('freeOnly', value ?? false),
                        contentPadding: EdgeInsets.zero,
                        controlAffinity: ListTileControlAffinity.leading,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterSection({required String title, required Widget child}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        child,
      ],
    );
  }

  Widget _buildDropdown({
    required String value,
    required List<String> items,
    required Function(String?) onChanged,
  }) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 3.w),
      decoration: BoxDecoration(
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline,
        ),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          items: items.map((String item) {
            return DropdownMenuItem<String>(
              value: item,
              child: Text(
                item,
                style: AppTheme.lightTheme.textTheme.bodyMedium,
              ),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }
}
