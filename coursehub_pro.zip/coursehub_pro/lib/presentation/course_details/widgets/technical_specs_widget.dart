import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class TechnicalSpecsWidget extends StatelessWidget {
  final Map<String, dynamic> courseData;

  const TechnicalSpecsWidget({
    Key? key,
    required this.courseData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Technical Specifications',
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 2.h),

          // Device Compatibility
          _buildSpecSection(
            'Device Compatibility',
            [
              {'icon': 'smartphone', 'text': 'Mobile (iOS 12+, Android 8+)'},
              {'icon': 'tablet', 'text': 'Tablet (iPad, Android tablets)'},
              {'icon': 'computer', 'text': 'Desktop (Windows, macOS, Linux)'},
              {'icon': 'tv', 'text': 'Smart TV (Chromecast, AirPlay)'},
            ],
          ),

          SizedBox(height: 3.h),

          // DRM Protection
          _buildSpecSection(
            'DRM Protection & Security',
            [
              {'icon': 'security', 'text': 'HLS/DASH encrypted streaming'},
              {'icon': 'watermark', 'text': 'Dynamic watermarking (user info)'},
              {'icon': 'devices', 'text': 'Maximum 2 device limit'},
              {'icon': 'block', 'text': 'Single concurrent playback'},
            ],
          ),

          SizedBox(height: 3.h),

          // Video Quality
          _buildSpecSection(
            'Video Quality & Features',
            [
              {'icon': 'hd', 'text': 'HD quality (up to 1080p)'},
              {'icon': 'speed', 'text': 'Variable playback speed'},
              {'icon': 'closed_caption', 'text': 'Subtitles available'},
              {'icon': 'download', 'text': 'Offline download (mobile app)'},
            ],
          ),

          SizedBox(height: 3.h),

          // System Requirements
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.primary
                  .withValues(alpha: 0.05),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.primary
                    .withValues(alpha: 0.1),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'info',
                      color: AppTheme.lightTheme.colorScheme.primary,
                      size: 20,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'System Requirements',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: AppTheme.lightTheme.colorScheme.primary,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 1.h),
                Text(
                  'Minimum 5 Mbps internet connection for HD streaming. For the best experience, we recommend 10+ Mbps. Offline content requires initial download over WiFi.',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    height: 1.4,
                    color: AppTheme.lightTheme.colorScheme.onSurface
                        .withValues(alpha: 0.8),
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 2.h),

          // Device Management Link
          Center(
            child: TextButton(
              onPressed: () {
                Navigator.pushNamed(context, '/device-management');
              },
              style: TextButton.styleFrom(
                foregroundColor: AppTheme.lightTheme.colorScheme.primary,
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomIconWidget(
                    iconName: 'settings',
                    color: AppTheme.lightTheme.colorScheme.primary,
                    size: 18,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Manage Your Devices',
                    style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.primary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(width: 1.w),
                  CustomIconWidget(
                    iconName: 'arrow_forward',
                    color: AppTheme.lightTheme.colorScheme.primary,
                    size: 16,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSpecSection(String title, List<Map<String, String>> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        ...items.map<Widget>((item) {
          return Padding(
            padding: EdgeInsets.only(bottom: 1.h),
            child: Row(
              children: [
                Container(
                  width: 8.w,
                  height: 8.w,
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.primary
                        .withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: CustomIconWidget(
                    iconName: item['icon']!,
                    color: AppTheme.lightTheme.colorScheme.primary,
                    size: 18,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Text(
                    item['text']!,
                    style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                      height: 1.3,
                    ),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ],
    );
  }
}
