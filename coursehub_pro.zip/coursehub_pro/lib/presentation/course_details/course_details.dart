import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/community_features_widget.dart';
import './widgets/course_header_widget.dart';
import './widgets/course_tabs_widget.dart';
import './widgets/enrollment_panel_widget.dart';
import './widgets/technical_specs_widget.dart';
import './widgets/video_preview_widget.dart';

class CourseDetails extends StatefulWidget {
  const CourseDetails({Key? key}) : super(key: key);

  @override
  State<CourseDetails> createState() => _CourseDetailsState();
}

class _CourseDetailsState extends State<CourseDetails> {
  final ScrollController _scrollController = ScrollController();
  bool _showStickyEnrollment = false;

  // Mock course data
  final Map<String, dynamic> courseData = {
    "id": 1,
    "title": "Complete Flutter Development Bootcamp with Dart",
    "description":
        "Master Flutter and Dart to build beautiful, fast, and native mobile applications for iOS and Android. This comprehensive course covers everything from basics to advanced concepts.",
    "price": 199.99,
    "rating": 4.8,
    "totalReviews": 12847,
    "level": "Beginner to Advanced",
    "duration": 42.5,
    "enrolledStudents": 45623,
    "totalLessons": 156,
    "previewImage":
        "https://images.unsplash.com/photo-1551650975-87deedd944c3?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
    "instructor": {
      "id": 1,
      "name": "Dr. Sarah Johnson",
      "title": "Senior Flutter Developer & Tech Lead",
      "avatar":
          "https://images.unsplash.com/photo-1494790108755-2616b612b786?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "rating": 4.9,
      "bio":
          "Dr. Sarah Johnson is a seasoned software engineer with over 10 years of experience in mobile app development. She has worked with top tech companies including Google and Microsoft, specializing in Flutter and cross-platform development. Sarah holds a PhD in Computer Science and has published numerous research papers on mobile application architecture.",
      "credentials": [
        "PhD in Computer Science from Stanford University",
        "Former Senior Engineer at Google (Flutter Team)",
        "Published author of 'Advanced Flutter Patterns'",
        "Speaker at Flutter Forward 2023",
        "Certified Google Developer Expert (GDE) for Flutter"
      ]
    },
    "modules": [
      {
        "id": 1,
        "title": "Flutter Fundamentals",
        "duration": 180,
        "lessons": [
          {
            "id": 1,
            "title": "Introduction to Flutter and Dart",
            "duration": 25,
            "isPreview": true
          },
          {
            "id": 2,
            "title": "Setting up Development Environment",
            "duration": 30,
            "isPreview": true
          },
          {
            "id": 3,
            "title": "Understanding Widgets",
            "duration": 35,
            "isPreview": false
          },
          {
            "id": 4,
            "title": "Stateful vs Stateless Widgets",
            "duration": 40,
            "isPreview": false
          },
          {
            "id": 5,
            "title": "Building Your First App",
            "duration": 50,
            "isPreview": false
          }
        ]
      },
      {
        "id": 2,
        "title": "Advanced UI Development",
        "duration": 240,
        "lessons": [
          {
            "id": 6,
            "title": "Custom Widgets and Composition",
            "duration": 45,
            "isPreview": false
          },
          {
            "id": 7,
            "title": "Animations and Transitions",
            "duration": 55,
            "isPreview": false
          },
          {
            "id": 8,
            "title": "Responsive Design Principles",
            "duration": 40,
            "isPreview": false
          },
          {
            "id": 9,
            "title": "Theme and Styling",
            "duration": 35,
            "isPreview": false
          },
          {
            "id": 10,
            "title": "Advanced Layout Techniques",
            "duration": 65,
            "isPreview": false
          }
        ]
      },
      {
        "id": 3,
        "title": "State Management & Architecture",
        "duration": 300,
        "lessons": [
          {
            "id": 11,
            "title": "Provider Pattern",
            "duration": 50,
            "isPreview": false
          },
          {
            "id": 12,
            "title": "BLoC Architecture",
            "duration": 60,
            "isPreview": false
          },
          {
            "id": 13,
            "title": "Riverpod State Management",
            "duration": 55,
            "isPreview": false
          },
          {
            "id": 14,
            "title": "Clean Architecture Principles",
            "duration": 70,
            "isPreview": false
          },
          {
            "id": 15,
            "title": "Testing Strategies",
            "duration": 65,
            "isPreview": false
          }
        ]
      }
    ],
    "reviews": [
      {
        "id": 1,
        "name": "Michael Chen",
        "avatar":
            "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
        "rating": 5,
        "date": "2 weeks ago",
        "comment":
            "Absolutely fantastic course! Sarah's teaching style is clear and engaging. The projects are practical and really help solidify the concepts. I went from zero Flutter knowledge to building my own apps."
      },
      {
        "id": 2,
        "name": "Emily Rodriguez",
        "avatar":
            "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
        "rating": 5,
        "date": "1 month ago",
        "comment":
            "This course exceeded my expectations. The content is up-to-date with the latest Flutter features, and the instructor provides excellent support in the Q&A section."
      },
      {
        "id": 3,
        "name": "David Kim",
        "avatar":
            "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
        "rating": 4,
        "date": "3 weeks ago",
        "comment":
            "Great course with comprehensive coverage. The only minor issue is that some advanced topics could use more examples, but overall it's excellent value for money."
      }
    ],
    "faqs": [
      {
        "id": 1,
        "question": "Do I need prior programming experience?",
        "answer":
            "While prior programming experience is helpful, this course is designed for beginners. We start with Dart fundamentals and gradually build up to advanced Flutter concepts. If you're completely new to programming, I recommend spending some time with basic programming concepts first."
      },
      {
        "id": 2,
        "question": "What devices do I need for this course?",
        "answer":
            "You'll need a computer (Windows, macOS, or Linux) with at least 8GB RAM and 10GB free storage. A physical Android or iOS device is recommended for testing, though emulators work fine for learning."
      },
      {
        "id": 3,
        "question": "How long do I have access to the course?",
        "answer":
            "You have lifetime access to the course content, including all future updates. Once enrolled, you can learn at your own pace and revisit any section whenever you need."
      },
      {
        "id": 4,
        "question": "Is there a certificate upon completion?",
        "answer":
            "Yes! Upon completing all modules and passing the final project assessment, you'll receive a certificate of completion that you can add to your LinkedIn profile or resume."
      },
      {
        "id": 5,
        "question": "What if I'm not satisfied with the course?",
        "answer":
            "We offer a 30-day money-back guarantee. If you're not completely satisfied with the course content, you can request a full refund within 30 days of purchase, no questions asked."
      }
    ],
    "recentDiscussions": [
      {
        "id": 1,
        "author": "Alex Thompson",
        "avatar":
            "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
        "question": "How do I handle state management in large applications?",
        "timestamp": "2 hours ago",
        "replies": 8
      },
      {
        "id": 2,
        "author": "Lisa Wang",
        "avatar":
            "https://images.unsplash.com/photo-1494790108755-2616b612b786?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
        "question": "Best practices for Flutter app performance optimization?",
        "timestamp": "5 hours ago",
        "replies": 12
      },
      {
        "id": 3,
        "author": "James Miller",
        "avatar":
            "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
        "question": "Integration testing vs unit testing in Flutter?",
        "timestamp": "1 day ago",
        "replies": 6
      }
    ],
    "testimonials": [
      {
        "id": 1,
        "name": "Jennifer Adams",
        "avatar":
            "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
        "rating": 5,
        "date": "1 week ago",
        "comment":
            "This course transformed my career! I landed a Flutter developer position just 3 months after completing it. The practical projects really made the difference."
      },
      {
        "id": 2,
        "name": "Robert Garcia",
        "avatar":
            "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
        "rating": 5,
        "date": "2 weeks ago",
        "comment":
            "Excellent instructor and well-structured content. The community support is amazing - questions get answered quickly and thoroughly."
      },
      {
        "id": 3,
        "name": "Maria Santos",
        "avatar":
            "https://images.unsplash.com/photo-1494790108755-2616b612b786?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
        "rating": 5,
        "date": "3 weeks ago",
        "comment":
            "As someone who switched from web development, this course made the transition smooth. The explanations are clear and the pace is perfect."
      }
    ]
  };

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_scrollListener);
  }

  void _scrollListener() {
    if (_scrollController.offset > 300 && !_showStickyEnrollment) {
      setState(() {
        _showStickyEnrollment = true;
      });
    } else if (_scrollController.offset <= 300 && _showStickyEnrollment) {
      setState(() {
        _showStickyEnrollment = false;
      });
    }
  }

  @override
  void dispose() {
    _scrollController.removeListener(_scrollListener);
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppTheme.lightTheme.appBarTheme.backgroundColor,
        elevation: 0,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 24,
          ),
        ),
        title: Text(
          'Course Details',
          style: AppTheme.lightTheme.appBarTheme.titleTextStyle,
        ),
        actions: [
          IconButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Course added to wishlist!'),
                  backgroundColor: AppTheme.lightTheme.colorScheme.primary,
                ),
              );
            },
            icon: CustomIconWidget(
              iconName: 'favorite_border',
              color: AppTheme.lightTheme.colorScheme.onSurface,
              size: 24,
            ),
          ),
          IconButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Course link copied to clipboard!'),
                  backgroundColor: AppTheme.lightTheme.colorScheme.primary,
                ),
              );
            },
            icon: CustomIconWidget(
              iconName: 'share',
              color: AppTheme.lightTheme.colorScheme.onSurface,
              size: 24,
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            controller: _scrollController,
            padding: EdgeInsets.all(4.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Course Header
                CourseHeaderWidget(courseData: courseData),

                SizedBox(height: 3.h),

                // Video Preview
                VideoPreviewWidget(courseData: courseData),

                SizedBox(height: 3.h),

                // Course Description
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(4.w),
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.surface,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.05),
                        blurRadius: 8,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'About This Course',
                        style:
                            AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 1.h),
                      Text(
                        courseData['description'] as String,
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          height: 1.5,
                          color: AppTheme.lightTheme.colorScheme.onSurface
                              .withValues(alpha: 0.8),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 3.h),

                // Enrollment Panel (Desktop/Tablet)
                if (100.w > 768) ...[
                  EnrollmentPanelWidget(courseData: courseData),
                  SizedBox(height: 3.h),
                ],

                // Course Tabs
                CourseTabsWidget(courseData: courseData),

                SizedBox(height: 3.h),

                // Community Features
                CommunityFeaturesWidget(courseData: courseData),

                SizedBox(height: 3.h),

                // Technical Specifications
                TechnicalSpecsWidget(courseData: courseData),

                SizedBox(height: 10.h), // Extra space for sticky enrollment
              ],
            ),
          ),

          // Sticky Enrollment Panel (Mobile)
          if (100.w <= 768 && _showStickyEnrollment)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surface,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      blurRadius: 8,
                      offset: Offset(0, -2),
                    ),
                  ],
                ),
                child: SafeArea(
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '\$${courseData['price'].toStringAsFixed(2)}',
                              style: AppTheme.lightTheme.textTheme.titleLarge
                                  ?.copyWith(
                                fontWeight: FontWeight.bold,
                                color: AppTheme.lightTheme.colorScheme.primary,
                              ),
                            ),
                            Text(
                              'Lifetime access',
                              style: AppTheme.lightTheme.textTheme.bodySmall
                                  ?.copyWith(
                                color: AppTheme.lightTheme.colorScheme.onSurface
                                    .withValues(alpha: 0.6),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 4.w),
                      Expanded(
                        flex: 2,
                        child: ElevatedButton(
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content:
                                    Text('Redirecting to secure checkout...'),
                                backgroundColor:
                                    AppTheme.lightTheme.colorScheme.primary,
                              ),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                AppTheme.lightTheme.colorScheme.primary,
                            foregroundColor: Colors.white,
                            padding: EdgeInsets.symmetric(vertical: 2.h),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          child: Text(
                            'Enroll Now',
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
      // Floating Action Button for Quick Actions
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showQuickActionsBottomSheet(context);
        },
        backgroundColor: AppTheme.lightTheme.colorScheme.secondary,
        child: CustomIconWidget(
          iconName: 'more_vert',
          color: Colors.white,
          size: 24,
        ),
      ),
    );
  }

  void _showQuickActionsBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return Container(
          padding: EdgeInsets.all(4.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 12.w,
                height: 0.5.h,
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.onSurface
                      .withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              SizedBox(height: 2.h),
              Text(
                'Quick Actions',
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 2.h),
              _buildQuickActionTile(
                icon: 'bookmark_border',
                title: 'Add to Wishlist',
                onTap: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Added to wishlist!')),
                  );
                },
              ),
              _buildQuickActionTile(
                icon: 'share',
                title: 'Share Course',
                onTap: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Course link copied!')),
                  );
                },
              ),
              _buildQuickActionTile(
                icon: 'report',
                title: 'Report Issue',
                onTap: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Report submitted!')),
                  );
                },
              ),
              _buildQuickActionTile(
                icon: 'school',
                title: 'View All Courses',
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/course-catalog');
                },
              ),
              SizedBox(height: 2.h),
            ],
          ),
        );
      },
    );
  }

  Widget _buildQuickActionTile({
    required String icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: icon,
        color: AppTheme.lightTheme.colorScheme.primary,
        size: 24,
      ),
      title: Text(
        title,
        style: AppTheme.lightTheme.textTheme.bodyLarge,
      ),
      onTap: onTap,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
    );
  }
}
