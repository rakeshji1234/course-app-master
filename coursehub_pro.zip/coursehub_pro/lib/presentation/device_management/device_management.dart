import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/active_session_widget.dart';
import './widgets/device_card_widget.dart';
import './widgets/security_summary_widget.dart';

class DeviceManagement extends StatefulWidget {
  const DeviceManagement({Key? key}) : super(key: key);

  @override
  State<DeviceManagement> createState() => _DeviceManagementState();
}

class _DeviceManagementState extends State<DeviceManagement> {
  bool _isLoading = false;

  // Mock data for devices
  final List<Map<String, dynamic>> _devices = [
    {
      "id": "device_001",
      "deviceName": "MacBook Pro",
      "deviceType": "Desktop",
      "operatingSystem": "macOS 14.2",
      "browser": "Chrome 120.0",
      "location": "New York, United States",
      "ipAddress": "192.168.1.105",
      "lastAccess": DateTime.now().subtract(Duration(minutes: 5)),
      "trustLevel": "High",
      "isCurrent": true,
      "fingerprint": "fp_mac_chrome_001",
      "securityScore": 95,
    },
    {
      "id": "device_002",
      "deviceName": "iPhone 15 Pro",
      "deviceType": "Mobile",
      "operatingSystem": "iOS 17.2",
      "browser": "Safari Mobile",
      "location": "Mumbai, India",
      "ipAddress": "203.192.12.45",
      "lastAccess": DateTime.now().subtract(Duration(hours: 2)),
      "trustLevel": "High",
      "isCurrent": false,
      "fingerprint": "fp_ios_safari_002",
      "securityScore": 92,
    },
  ];

  // Mock security data
  final Map<String, dynamic> _securityData = {
    "activeDevices": 2,
    "maxDevices": 2,
    "hasActiveSessions": true,
    "recentAlerts": [
      {
        "id": "alert_001",
        "title": "New device login detected",
        "description": "iPhone 15 Pro logged in from Mumbai, India",
        "timestamp": DateTime.now().subtract(Duration(hours: 3)),
        "severity": "medium",
      },
      {
        "id": "alert_002",
        "title": "Unusual access pattern",
        "description": "Multiple login attempts from different locations",
        "timestamp": DateTime.now().subtract(Duration(days: 1)),
        "severity": "low",
      },
    ],
  };

  // Mock active session data
  final Map<String, dynamic>? _activeSession = {
    "sessionId": "session_001",
    "courseName": "Advanced Flutter Development",
    "lessonName": "State Management with Provider",
    "deviceName": "MacBook Pro",
    "startTime": DateTime.now().subtract(Duration(minutes: 25)),
    "progress": 0.65,
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text('Device Management'),
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 6.w,
          ),
        ),
        actions: [
          IconButton(
            onPressed: _refreshData,
            icon: _isLoading
                ? SizedBox(
                    width: 5.w,
                    height: 5.w,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        AppTheme.lightTheme.primaryColor,
                      ),
                    ),
                  )
                : CustomIconWidget(
                    iconName: 'refresh',
                    color: AppTheme.lightTheme.colorScheme.onSurface,
                    size: 6.w,
                  ),
          ),
          PopupMenuButton<String>(
            onSelected: _handleMenuAction,
            itemBuilder: (BuildContext context) => [
              PopupMenuItem<String>(
                value: 'security_settings',
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'security',
                      color: AppTheme.textSecondaryLight,
                      size: 5.w,
                    ),
                    SizedBox(width: 2.w),
                    Text('Security Settings'),
                  ],
                ),
              ),
              PopupMenuItem<String>(
                value: 'device_history',
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'history',
                      color: AppTheme.textSecondaryLight,
                      size: 5.w,
                    ),
                    SizedBox(width: 2.w),
                    Text('Device History'),
                  ],
                ),
              ),
              PopupMenuItem<String>(
                value: 'help',
                child: Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'help',
                      color: AppTheme.textSecondaryLight,
                      size: 5.w,
                    ),
                    SizedBox(width: 2.w),
                    Text('Help & Support'),
                  ],
                ),
              ),
            ],
            icon: CustomIconWidget(
              iconName: 'more_vert',
              color: AppTheme.lightTheme.colorScheme.onSurface,
              size: 6.w,
            ),
          ),
        ],
      ),
      body: _isLoading
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(
                      AppTheme.lightTheme.primaryColor,
                    ),
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    'Loading device information...',
                    style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                      color: AppTheme.textSecondaryLight,
                    ),
                  ),
                ],
              ),
            )
          : LayoutBuilder(
              builder: (context, constraints) {
                // Web/Desktop layout
                if (constraints.maxWidth > 768) {
                  return _buildDesktopLayout();
                }
                // Mobile layout
                return _buildMobileLayout();
              },
            ),
    );
  }

  Widget _buildDesktopLayout() {
    return Padding(
      padding: EdgeInsets.all(4.w),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Main content area
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                SizedBox(height: 3.h),
                _buildDevicesList(),
              ],
            ),
          ),
          SizedBox(width: 4.w),
          // Sidebar
          Expanded(
            flex: 1,
            child: Column(
              children: [
                ActiveSessionWidget(activeSession: _activeSession),
                SizedBox(height: 3.h),
                SecuritySummaryWidget(securityData: _securityData),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMobileLayout() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(),
          SizedBox(height: 3.h),
          ActiveSessionWidget(activeSession: _activeSession),
          SizedBox(height: 3.h),
          SecuritySummaryWidget(securityData: _securityData),
          SizedBox(height: 3.h),
          _buildDevicesList(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Manage Your Devices',
          style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.w700,
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          'Monitor and control access to your CourseHub Pro account across all devices. You can have up to 2 devices registered at any time.',
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.textSecondaryLight,
          ),
        ),
        SizedBox(height: 2.h),
        Container(
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
                color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.2)),
          ),
          child: Row(
            children: [
              CustomIconWidget(
                iconName: 'info',
                color: AppTheme.lightTheme.primaryColor,
                size: 5.w,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: Text(
                  'Device limit: ${_securityData['activeDevices']}/${_securityData['maxDevices']} devices used',
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.primaryColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDevicesList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              'Registered Devices',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            Spacer(),
            Text(
              '${_devices.length} of ${_securityData['maxDevices']}',
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.textSecondaryLight,
              ),
            ),
          ],
        ),
        SizedBox(height: 2.h),
        ListView.builder(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          itemCount: _devices.length,
          itemBuilder: (context, index) {
            final device = _devices[index];
            return DeviceCardWidget(
              device: device,
              onRemove: () => _removeDevice(device['id'] as String),
            );
          },
        ),
        if (_devices.length < _securityData['maxDevices']) ...[
          SizedBox(height: 2.h),
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.2),
                style: BorderStyle.solid,
              ),
            ),
            child: Column(
              children: [
                CustomIconWidget(
                  iconName: 'add_circle_outline',
                  color: AppTheme.lightTheme.primaryColor,
                  size: 12.w,
                ),
                SizedBox(height: 2.h),
                Text(
                  'Add New Device',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 1.h),
                Text(
                  'You can register ${_securityData['maxDevices'] - _devices.length} more device${_securityData['maxDevices'] - _devices.length == 1 ? '' : 's'}',
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.textSecondaryLight,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 2.h),
                ElevatedButton.icon(
                  onPressed: _addNewDevice,
                  icon: CustomIconWidget(
                    iconName: 'add',
                    color: AppTheme.lightTheme.colorScheme.onPrimary,
                    size: 4.w,
                  ),
                  label: Text('Register This Device'),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  void _removeDevice(String deviceId) {
    final device = _devices.firstWhere((d) => d['id'] == deviceId);

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: 'warning',
                color: AppTheme.warningLight,
                size: 6.w,
              ),
              SizedBox(width: 2.w),
              Text('Remove Device'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Are you sure you want to remove this device?'),
              SizedBox(height: 2.h),
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.2)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      device['deviceName'] as String,
                      style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      '${device['operatingSystem']} • ${device['browser']}',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.textSecondaryLight,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 2.h),
              Text(
                'This will immediately terminate any active sessions on this device and prevent future access.',
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.textSecondaryLight,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _performDeviceRemoval(deviceId);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.errorLight,
              ),
              child: Text('Remove Device'),
            ),
          ],
        );
      },
    );
  }

  void _performDeviceRemoval(String deviceId) {
    setState(() {
      _devices.removeWhere((device) => device['id'] == deviceId);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Device removed successfully'),
        backgroundColor: AppTheme.successLight,
        action: SnackBarAction(
          label: 'Undo',
          textColor: Colors.white,
          onPressed: () {
            // Implement undo functionality if needed
          },
        ),
      ),
    );
  }

  void _addNewDevice() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: 'add_circle',
                color: AppTheme.lightTheme.primaryColor,
                size: 6.w,
              ),
              SizedBox(width: 2.w),
              Text('Register Device'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                  'This device will be registered to your account with the following information:'),
              SizedBox(height: 2.h),
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.2)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Current Device',
                      style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Text(
                      'Web Browser • Chrome',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.textSecondaryLight,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 2.h),
              Text(
                'Device fingerprinting will be used to ensure secure access.',
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.textSecondaryLight,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _performDeviceRegistration();
              },
              child: Text('Register Device'),
            ),
          ],
        );
      },
    );
  }

  void _performDeviceRegistration() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Device registration initiated. Please check your email for verification.'),
        backgroundColor: AppTheme.lightTheme.primaryColor,
      ),
    );
  }

  Future<void> _refreshData() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(Duration(seconds: 2));

    setState(() {
      _isLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Device information updated'),
        backgroundColor: AppTheme.successLight,
      ),
    );
  }

  void _handleMenuAction(String action) {
    switch (action) {
      case 'security_settings':
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Security settings feature coming soon'),
            backgroundColor: AppTheme.lightTheme.primaryColor,
          ),
        );
        break;
      case 'device_history':
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Device history feature coming soon'),
            backgroundColor: AppTheme.lightTheme.primaryColor,
          ),
        );
        break;
      case 'help':
        _showHelpDialog();
        break;
    }
  }

  void _showHelpDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: 'help',
                color: AppTheme.lightTheme.primaryColor,
                size: 6.w,
              ),
              SizedBox(width: 2.w),
              Text('Device Management Help'),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Frequently Asked Questions',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 2.h),
                _buildHelpItem(
                  'Why is there a device limit?',
                  'To protect your account and ensure content security, we limit access to 2 devices per account.',
                ),
                _buildHelpItem(
                  'What happens when I remove a device?',
                  'The device will be immediately logged out and cannot access your account until re-registered.',
                ),
                _buildHelpItem(
                  'Can I play content on multiple devices?',
                  'No, only one device can play content at a time. Playback will pause on other devices.',
                ),
                _buildHelpItem(
                  'How does device fingerprinting work?',
                  'We create a unique identifier for each device based on hardware and software characteristics for enhanced security.',
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Close'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                // Navigate to support or contact
              },
              child: Text('Contact Support'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildHelpItem(String question, String answer) {
    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            question,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 0.5.h),
          Text(
            answer,
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.textSecondaryLight,
            ),
          ),
        ],
      ),
    );
  }
}
