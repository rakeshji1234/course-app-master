import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SecuritySummaryWidget extends StatelessWidget {
  final Map<String, dynamic> securityData;

  const SecuritySummaryWidget({
    Key? key,
    required this.securityData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final int activeDevices = securityData['activeDevices'] as int? ?? 0;
    final int maxDevices = securityData['maxDevices'] as int? ?? 2;
    final bool hasActiveSessions =
        securityData['hasActiveSessions'] as bool? ?? false;
    final List<dynamic> recentAlerts =
        securityData['recentAlerts'] as List<dynamic>? ?? [];

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2)),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'security',
                color: AppTheme.lightTheme.primaryColor,
                size: 6.w,
              ),
              SizedBox(width: 3.w),
              Text(
                'Account Security',
                style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          _buildSecurityItem(
            icon: 'devices',
            title: 'Device Limit',
            value: '$activeDevices / $maxDevices devices',
            status: activeDevices >= maxDevices ? 'warning' : 'success',
            context: context,
          ),
          SizedBox(height: 2.h),
          _buildSecurityItem(
            icon: 'play_circle',
            title: 'Active Sessions',
            value: hasActiveSessions
                ? 'Active playback detected'
                : 'No active sessions',
            status: hasActiveSessions ? 'info' : 'success',
            context: context,
          ),
          SizedBox(height: 2.h),
          _buildSecurityItem(
            icon: 'fingerprint',
            title: 'Device Fingerprinting',
            value: 'Enhanced security enabled',
            status: 'success',
            context: context,
          ),
          if (recentAlerts.isNotEmpty) ...[
            SizedBox(height: 3.h),
            Row(
              children: [
                CustomIconWidget(
                  iconName: 'warning',
                  color: AppTheme.warningLight,
                  size: 5.w,
                ),
                SizedBox(width: 2.w),
                Text(
                  'Recent Security Alerts',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: AppTheme.warningLight,
                  ),
                ),
              ],
            ),
            SizedBox(height: 1.5.h),
            ...recentAlerts.take(3).map((alert) =>
                _buildAlertItem(alert as Map<String, dynamic>, context)),
          ],
          SizedBox(height: 3.h),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                _showSecurityDetailsDialog(context);
              },
              icon: CustomIconWidget(
                iconName: 'info',
                color: AppTheme.lightTheme.colorScheme.onPrimary,
                size: 4.w,
              ),
              label: Text('View Security Details'),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 1.5.h),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSecurityItem({
    required String icon,
    required String title,
    required String value,
    required String status,
    required BuildContext context,
  }) {
    Color statusColor;
    switch (status) {
      case 'success':
        statusColor = AppTheme.successLight;
        break;
      case 'warning':
        statusColor = AppTheme.warningLight;
        break;
      case 'error':
        statusColor = AppTheme.errorLight;
        break;
      case 'info':
        statusColor = AppTheme.lightTheme.primaryColor;
        break;
      default:
        statusColor = AppTheme.textSecondaryLight;
    }

    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(2.w),
          decoration: BoxDecoration(
            color: statusColor.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: CustomIconWidget(
            iconName: icon,
            color: statusColor,
            size: 4.w,
          ),
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 0.5.h),
              Text(
                value,
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.textSecondaryLight,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAlertItem(Map<String, dynamic> alert, BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 1.h),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.warningLight.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppTheme.warningLight.withValues(alpha: 0.2)),
      ),
      child: Row(
        children: [
          CustomIconWidget(
            iconName: 'error_outline',
            color: AppTheme.warningLight,
            size: 4.w,
          ),
          SizedBox(width: 2.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  alert['title'] as String? ?? 'Security Alert',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
                ),
                if (alert['description'] != null) ...[
                  SizedBox(height: 0.5.h),
                  Text(
                    alert['description'] as String,
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.textSecondaryLight,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showSecurityDetailsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: 'security',
                color: AppTheme.lightTheme.primaryColor,
                size: 6.w,
              ),
              SizedBox(width: 2.w),
              Text('Security Details'),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Device Management',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 1.h),
                Text(
                  '• Maximum 2 devices allowed per account\n• Device fingerprinting prevents unauthorized access\n• Automatic session termination on device removal',
                  style: AppTheme.lightTheme.textTheme.bodySmall,
                ),
                SizedBox(height: 2.h),
                Text(
                  'Concurrent Playback Protection',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 1.h),
                Text(
                  '• Only one device can play content simultaneously\n• Automatic pause when playback starts elsewhere\n• Real-time session monitoring',
                  style: AppTheme.lightTheme.textTheme.bodySmall,
                ),
                SizedBox(height: 2.h),
                Text(
                  'Security Monitoring',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 1.h),
                Text(
                  '• Suspicious login detection\n• Location-based access alerts\n• Device trust scoring system',
                  style: AppTheme.lightTheme.textTheme.bodySmall,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Close'),
            ),
          ],
        );
      },
    );
  }
}
