import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class DeviceCardWidget extends StatelessWidget {
  final Map<String, dynamic> device;
  final VoidCallback onRemove;

  const DeviceCardWidget({
    Key? key,
    required this.device,
    required this.onRemove,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool isCurrentDevice = device['isCurrent'] as bool? ?? false;
    final bool isTrusted = (device['trustLevel'] as String?) == 'High';
    final DateTime lastAccess = device['lastAccess'] as DateTime;
    final String timeAgo = _getTimeAgo(lastAccess);

    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: isCurrentDevice 
          ? Border.all(color: AppTheme.lightTheme.primaryColor, width: 2)
          : Border.all(color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2)),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color: _getDeviceTypeColor().withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: CustomIconWidget(
                  iconName: _getDeviceIcon(),
                  color: _getDeviceTypeColor(),
                  size: 6.w,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            device['deviceName'] as String? ?? 'Unknown Device',
                            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (isCurrentDevice)
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                            decoration: BoxDecoration(
                              color: AppTheme.lightTheme.primaryColor,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              'Current',
                              style: AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                                color: AppTheme.lightTheme.colorScheme.onPrimary,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                      ],
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      '${device['operatingSystem']} • ${device['browser']}',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.textSecondaryLight,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              CustomIconWidget(
                iconName: 'location_on',
                color: AppTheme.textSecondaryLight,
                size: 4.w,
              ),
              SizedBox(width: 1.w),
              Expanded(
                child: Text(
                  device['location'] as String? ?? 'Unknown Location',
                  style: AppTheme.lightTheme.textTheme.bodySmall,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  color: isTrusted ? AppTheme.successLight.withValues(alpha: 0.1) : AppTheme.warningLight.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CustomIconWidget(
                      iconName: isTrusted ? 'verified' : 'warning',
                      color: isTrusted ? AppTheme.successLight : AppTheme.warningLight,
                      size: 3.w,
                    ),
                    SizedBox(width: 1.w),
                    Text(
                      device['trustLevel'] as String? ?? 'Medium',
                      style: AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                        color: isTrusted ? AppTheme.successLight : AppTheme.warningLight,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 1.5.h),
          Row(
            children: [
              CustomIconWidget(
                iconName: 'access_time',
                color: AppTheme.textSecondaryLight,
                size: 4.w,
              ),
              SizedBox(width: 1.w),
              Text(
                'Last active: $timeAgo',
                style: AppTheme.lightTheme.textTheme.bodySmall,
              ),
              Spacer(),
              Text(
                device['ipAddress'] as String? ?? '0.0.0.0',
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  fontFamily: 'monospace',
                ),
              ),
            ],
          ),
          if (!isCurrentDevice) ...[
            SizedBox(height: 2.h),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: onRemove,
                icon: CustomIconWidget(
                  iconName: 'remove_circle_outline',
                  color: AppTheme.errorLight,
                  size: 4.w,
                ),
                label: Text(
                  'Remove Device',
                  style: TextStyle(color: AppTheme.errorLight),
                ),
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: AppTheme.errorLight),
                  padding: EdgeInsets.symmetric(vertical: 1.5.h),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _getDeviceIcon() {
    final deviceType = device['deviceType'] as String? ?? 'desktop';
    switch (deviceType.toLowerCase()) {
      case 'mobile':
        return 'smartphone';
      case 'tablet':
        return 'tablet';
      case 'desktop':
        return 'computer';
      default:
        return 'devices';
    }
  }

  Color _getDeviceTypeColor() {
    final deviceType = device['deviceType'] as String? ?? 'desktop';
    switch (deviceType.toLowerCase()) {
      case 'mobile':
        return AppTheme.lightTheme.primaryColor;
      case 'tablet':
        return AppTheme.lightTheme.colorScheme.secondary;
      case 'desktop':
        return AppTheme.lightTheme.colorScheme.tertiary;
      default:
        return AppTheme.textSecondaryLight;
    }
  }

  String _getTimeAgo(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}d ago';
    } else {
      return '${(difference.inDays / 7).floor()}w ago';
    }
  }
}