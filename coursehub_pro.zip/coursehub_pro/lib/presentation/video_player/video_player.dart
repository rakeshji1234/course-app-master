import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/community_qa.dart';
import './widgets/lesson_navigation.dart';
import './widgets/lesson_resources.dart';
import './widgets/lesson_transcript.dart';
import './widgets/quiz_overlay.dart';
import './widgets/video_player_controls.dart';

class VideoPlayer extends StatefulWidget {
  const VideoPlayer({Key? key}) : super(key: key);

  @override
  State<VideoPlayer> createState() => _VideoPlayerState();
}

class _VideoPlayerState extends State<VideoPlayer>
    with TickerProviderStateMixin {
  late TabController _tabController;

  // Video player state
  bool _isPlaying = false;
  bool _isFullscreen = false;
  bool _showControls = true;
  Duration _currentPosition = const Duration(seconds: 0);
  Duration _totalDuration = const Duration(minutes: 15, seconds: 30);
  double _playbackSpeed = 1.0;
  String _quality = 'Auto';
  bool _autoPlay = true;
  bool _showQuiz = false;

  // Mock data
  final Map<String, dynamic> _currentLesson = {
    'id': 1,
    'title': 'Introduction to Flutter Development',
    'duration': '15:30',
    'completed': false,
    'videoUrl':
        'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4',
  };

  final List<Map<String, dynamic>> _lessons = [
    {
      'id': 1,
      'title': 'Introduction to Flutter Development',
      'duration': '15:30',
      'completed': false,
    },
    {
      'id': 2,
      'title': 'Setting up Development Environment',
      'duration': '12:45',
      'completed': false,
    },
    {
      'id': 3,
      'title': 'Understanding Widgets',
      'duration': '18:20',
      'completed': true,
    },
    {
      'id': 4,
      'title': 'State Management Basics',
      'duration': '22:15',
      'completed': false,
    },
    {
      'id': 5,
      'title': 'Building Your First App',
      'duration': '25:40',
      'completed': false,
    },
  ];

  final List<Map<String, dynamic>> _transcriptData = [
    {
      'startTime': 0,
      'endTime': 15,
      'text':
          'Welcome to this comprehensive Flutter development course. In this lesson, we\'ll cover the fundamentals of Flutter and why it\'s become such a popular choice for mobile app development.',
      'speaker': 'Instructor',
    },
    {
      'startTime': 15,
      'endTime': 35,
      'text':
          'Flutter is Google\'s UI toolkit for building natively compiled applications for mobile, web, and desktop from a single codebase. This means you can write your code once and deploy it across multiple platforms.',
      'speaker': 'Instructor',
    },
    {
      'startTime': 35,
      'endTime': 55,
      'text':
          'One of the key advantages of Flutter is its hot reload feature, which allows developers to see changes in real-time without losing the current application state. This significantly speeds up the development process.',
      'speaker': 'Instructor',
    },
    {
      'startTime': 55,
      'endTime': 75,
      'text':
          'Flutter uses the Dart programming language, which is also developed by Google. Dart is easy to learn, especially if you have experience with languages like Java, JavaScript, or C#.',
      'speaker': 'Instructor',
    },
  ];

  final List<Map<String, dynamic>> _resources = [
    {
      'name': 'Flutter Installation Guide.pdf',
      'type': 'pdf',
      'size': '2.5 MB',
      'downloaded': false,
      'url': 'https://example.com/flutter-guide.pdf',
    },
    {
      'name': 'Sample Code Files.zip',
      'type': 'zip',
      'size': '1.2 MB',
      'downloaded': true,
      'url': 'https://example.com/sample-code.zip',
    },
    {
      'name': 'Widget Reference Sheet.pdf',
      'type': 'pdf',
      'size': '800 KB',
      'downloaded': false,
      'url': 'https://example.com/widget-reference.pdf',
    },
  ];

  final List<Map<String, dynamic>> _assignments = [
    {
      'title': 'Create Your First Flutter App',
      'description':
          'Build a simple "Hello World" app using Flutter. Follow the step-by-step instructions provided in the resources section.',
      'dueDate': '2025-01-15',
      'status': 'pending',
    },
    {
      'title': 'Widget Exploration Exercise',
      'description':
          'Experiment with different Flutter widgets and create a small UI mockup. Document your findings and submit screenshots.',
      'dueDate': '2025-01-20',
      'status': 'submitted',
    },
  ];

  final List<Map<String, dynamic>> _questions = [
    {
      'id': 1,
      'userName': 'Sarah Johnson',
      'isInstructor': false,
      'question':
          'What\'s the difference between StatelessWidget and StatefulWidget?',
      'timestamp': '2025-01-04T10:30:00Z',
      'videoTimestamp': 120,
      'likes': 5,
      'answers': [
        {
          'userName': 'Dr. Michael Chen',
          'isInstructor': true,
          'answer':
              'Great question! StatelessWidget is immutable and doesn\'t change over time, while StatefulWidget can change its appearance in response to events triggered by user interactions or when it receives data.',
          'timestamp': '2025-01-04T11:15:00Z',
        },
      ],
    },
    {
      'id': 2,
      'userName': 'Alex Rodriguez',
      'isInstructor': false,
      'question': 'How do I handle navigation between screens in Flutter?',
      'timestamp': '2025-01-04T14:20:00Z',
      'videoTimestamp': null,
      'likes': 3,
      'answers': [],
    },
    {
      'id': 3,
      'userName': 'Emily Davis',
      'isInstructor': false,
      'question': 'Can you explain the widget tree concept mentioned at 2:15?',
      'timestamp': '2025-01-04T16:45:00Z',
      'videoTimestamp': 135,
      'likes': 8,
      'answers': [
        {
          'userName': 'Dr. Michael Chen',
          'isInstructor': true,
          'answer':
              'The widget tree is Flutter\'s way of organizing UI components hierarchically. Each widget can contain child widgets, forming a tree structure that defines your app\'s layout and behavior.',
          'timestamp': '2025-01-04T17:30:00Z',
        },
        {
          'userName': 'Sarah Johnson',
          'isInstructor': false,
          'answer':
              'Thanks for the explanation! This really helped me understand the concept better.',
          'timestamp': '2025-01-04T18:00:00Z',
        },
      ],
    },
  ];

  final Map<String, dynamic> _quizData = {
    'title': 'Flutter Basics Quiz',
    'passingScore': 70,
    'questions': [
      {
        'type': 'multiple_choice',
        'question': 'What programming language does Flutter use?',
        'options': ['Java', 'Dart', 'JavaScript', 'Python'],
        'correctAnswer': 1,
      },
      {
        'type': 'true_false',
        'question': 'Flutter can only be used for mobile app development.',
        'correctAnswer': false,
      },
      {
        'type': 'multiple_choice',
        'question': 'Which company developed Flutter?',
        'options': ['Facebook', 'Apple', 'Google', 'Microsoft'],
        'correctAnswer': 2,
      },
    ],
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);

    // Simulate video progress
    _startVideoProgressSimulation();

    // Show quiz at specific timestamp
    _checkForQuizTrigger();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _startVideoProgressSimulation() {
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted && _isPlaying) {
        setState(() {
          _currentPosition = Duration(seconds: _currentPosition.inSeconds + 1);
          if (_currentPosition >= _totalDuration) {
            _currentPosition = _totalDuration;
            _isPlaying = false;
            _onVideoComplete();
          }
        });
        _startVideoProgressSimulation();
      }
    });
  }

  void _checkForQuizTrigger() {
    // Show quiz at 5 minutes mark
    if (_currentPosition.inSeconds == 300 && !_showQuiz) {
      setState(() {
        _showQuiz = true;
        _isPlaying = false;
      });
    }
  }

  void _onVideoComplete() {
    if (_autoPlay) {
      _playNextLesson();
    }
  }

  void _playNextLesson() {
    final currentIndex =
        _lessons.indexWhere((lesson) => lesson['id'] == _currentLesson['id']);
    if (currentIndex >= 0 && currentIndex < _lessons.length - 1) {
      final nextLesson = _lessons[currentIndex + 1];
      _selectLesson(nextLesson);
    }
  }

  void _selectLesson(Map<String, dynamic> lesson) {
    setState(() {
      // Update current lesson
      _currentLesson.clear();
      _currentLesson.addAll(lesson);

      // Reset video state
      _currentPosition = const Duration(seconds: 0);
      _isPlaying = false;
      _showQuiz = false;
    });
  }

  void _togglePlayPause() {
    setState(() {
      _isPlaying = !_isPlaying;
    });
  }

  void _toggleFullscreen() {
    setState(() {
      _isFullscreen = !_isFullscreen;
    });

    if (_isFullscreen) {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
    } else {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
      ]);
    }
  }

  void _onSeek(double value) {
    setState(() {
      _currentPosition = Duration(
        milliseconds: (value * _totalDuration.inMilliseconds).round(),
      );
    });
  }

  void _onSpeedChange(double speed) {
    setState(() {
      _playbackSpeed = speed;
    });
  }

  void _onQualityChange(String quality) {
    setState(() {
      _quality = quality;
    });
  }

  void _rewind() {
    setState(() {
      _currentPosition = Duration(
        seconds: (_currentPosition.inSeconds - 10)
            .clamp(0, _totalDuration.inSeconds),
      );
    });
  }

  void _forward() {
    setState(() {
      _currentPosition = Duration(
        seconds: (_currentPosition.inSeconds + 10)
            .clamp(0, _totalDuration.inSeconds),
      );
    });
  }

  void _onAskQuestion(String question, Duration? timestamp) {
    // Add new question to the list
    final newQuestion = {
      'id': _questions.length + 1,
      'userName': 'Current User',
      'isInstructor': false,
      'question': question,
      'timestamp': DateTime.now().toIso8601String(),
      'videoTimestamp': timestamp?.inSeconds,
      'likes': 0,
      'answers': <Map<String, dynamic>>[],
    };

    setState(() {
      _questions.insert(0, newQuestion);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Question posted successfully!'),
        backgroundColor: AppTheme.successLight,
      ),
    );
  }

  void _onQuizComplete(Map<String, dynamic> results) {
    setState(() {
      _showQuiz = false;
    });

    if (results['passed'] == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Quiz passed! You can continue to the next lesson.'),
          backgroundColor: AppTheme.successLight,
        ),
      );
    }
  }

  void _onSkipQuiz() {
    setState(() {
      _showQuiz = false;
      _isPlaying = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: _isFullscreen ? _buildFullscreenView() : _buildNormalView(),
      ),
    );
  }

  Widget _buildFullscreenView() {
    return Stack(
      children: [
        // Video player
        Container(
          width: double.infinity,
          height: double.infinity,
          color: Colors.black,
          child: Stack(
            children: [
              // Video content placeholder
              Center(
                child: Container(
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Colors.grey[800]!,
                        Colors.grey[900]!,
                      ],
                    ),
                  ),
                  child: Stack(
                    children: [
                      // Watermark overlay
                      Positioned(
                        top: 4.h,
                        right: 4.w,
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 2.w, vertical: 1.h),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.7),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                'john.doe@email.com',
                                style: AppTheme.lightTheme.textTheme.bodySmall
                                    ?.copyWith(
                                  color: Colors.white.withValues(alpha: 0.8),
                                  fontSize: 8.sp,
                                ),
                              ),
                              Text(
                                DateTime.now().toString().split('.')[0],
                                style: AppTheme.lightTheme.textTheme.bodySmall
                                    ?.copyWith(
                                  color: Colors.white.withValues(alpha: 0.6),
                                  fontSize: 7.sp,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // Video placeholder content
                      Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CustomIconWidget(
                              iconName: 'play_circle_filled',
                              color: Colors.white.withValues(alpha: 0.8),
                              size: 64,
                            ),
                            SizedBox(height: 2.h),
                            Text(
                              'Flutter Development Course',
                              style: AppTheme.lightTheme.textTheme.titleLarge
                                  ?.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            SizedBox(height: 1.h),
                            Text(
                              'Secure HLS/DASH Video Stream',
                              style: AppTheme.lightTheme.textTheme.bodyMedium
                                  ?.copyWith(
                                color: Colors.white.withValues(alpha: 0.7),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Video controls overlay
              VideoPlayerControls(
                isPlaying: _isPlaying,
                isFullscreen: _isFullscreen,
                currentPosition: _currentPosition,
                totalDuration: _totalDuration,
                playbackSpeed: _playbackSpeed,
                quality: _quality,
                onPlayPause: _togglePlayPause,
                onFullscreen: _toggleFullscreen,
                onSeek: _onSeek,
                onSpeedChange: _onSpeedChange,
                onQualityChange: _onQualityChange,
                onRewind: _rewind,
                onForward: _forward,
              ),
            ],
          ),
        ),

        // Quiz overlay
        if (_showQuiz)
          QuizOverlay(
            quizData: _quizData,
            onQuizComplete: _onQuizComplete,
            onSkip: _onSkipQuiz,
          ),
      ],
    );
  }

  Widget _buildNormalView() {
    return Column(
      children: [
        // Video player section
        Container(
          width: double.infinity,
          height: 30.h,
          color: Colors.black,
          child: Stack(
            children: [
              // Video content placeholder
              Container(
                width: double.infinity,
                height: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Colors.grey[800]!,
                      Colors.grey[900]!,
                    ],
                  ),
                ),
                child: Stack(
                  children: [
                    // Watermark overlay
                    Positioned(
                      top: 2.h,
                      right: 4.w,
                      child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.w, vertical: 0.5.h),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.7),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              'john.doe@email.com',
                              style: AppTheme.lightTheme.textTheme.bodySmall
                                  ?.copyWith(
                                color: Colors.white.withValues(alpha: 0.8),
                                fontSize: 8.sp,
                              ),
                            ),
                            Text(
                              DateTime.now().toString().split('.')[0],
                              style: AppTheme.lightTheme.textTheme.bodySmall
                                  ?.copyWith(
                                color: Colors.white.withValues(alpha: 0.6),
                                fontSize: 7.sp,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Video placeholder content
                    Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomIconWidget(
                            iconName: 'play_circle_filled',
                            color: Colors.white.withValues(alpha: 0.8),
                            size: 48,
                          ),
                          SizedBox(height: 1.h),
                          Text(
                            'Flutter Development Course',
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 0.5.h),
                          Text(
                            'Secure HLS/DASH Video Stream',
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: Colors.white.withValues(alpha: 0.7),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // Video controls overlay
              VideoPlayerControls(
                isPlaying: _isPlaying,
                isFullscreen: _isFullscreen,
                currentPosition: _currentPosition,
                totalDuration: _totalDuration,
                playbackSpeed: _playbackSpeed,
                quality: _quality,
                onPlayPause: _togglePlayPause,
                onFullscreen: _toggleFullscreen,
                onSeek: _onSeek,
                onSpeedChange: _onSpeedChange,
                onQualityChange: _onQualityChange,
                onRewind: _rewind,
                onForward: _forward,
              ),
            ],
          ),
        ),

        // Lesson navigation
        Padding(
          padding: EdgeInsets.all(4.w),
          child: LessonNavigation(
            currentLesson: _currentLesson,
            lessons: _lessons,
            onLessonSelect: _selectLesson,
            onPrevious: _lessons.indexWhere(
                        (lesson) => lesson['id'] == _currentLesson['id']) >
                    0
                ? () {
                    final currentIndex = _lessons.indexWhere(
                        (lesson) => lesson['id'] == _currentLesson['id']);
                    _selectLesson(_lessons[currentIndex - 1]);
                  }
                : null,
            onNext: _lessons.indexWhere(
                        (lesson) => lesson['id'] == _currentLesson['id']) <
                    _lessons.length - 1
                ? () {
                    final currentIndex = _lessons.indexWhere(
                        (lesson) => lesson['id'] == _currentLesson['id']);
                    _selectLesson(_lessons[currentIndex + 1]);
                  }
                : null,
            autoPlay: _autoPlay,
            onAutoPlayToggle: (value) {
              setState(() {
                _autoPlay = value;
              });
            },
          ),
        ),

        // Tab bar
        Container(
          margin: EdgeInsets.symmetric(horizontal: 4.w),
          decoration: BoxDecoration(
            color: AppTheme.lightTheme.colorScheme.surface,
            borderRadius: BorderRadius.circular(8),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: TabBar(
            controller: _tabController,
            tabs: const [
              Tab(text: 'Transcript'),
              Tab(text: 'Resources'),
              Tab(text: 'Q&A'),
              Tab(text: 'Notes'),
            ],
            labelStyle: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
            unselectedLabelStyle:
                AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w400,
            ),
            indicatorSize: TabBarIndicatorSize.tab,
            dividerColor: Colors.transparent,
          ),
        ),

        // Tab content
        Expanded(
          child: Padding(
            padding: EdgeInsets.all(4.w),
            child: TabBarView(
              controller: _tabController,
              children: [
                // Transcript tab
                LessonTranscript(
                  transcriptData: _transcriptData,
                  currentPosition: _currentPosition,
                  onSeekToTimestamp: (timestamp) {
                    setState(() {
                      _currentPosition = timestamp;
                    });
                  },
                ),

                // Resources tab
                LessonResources(
                  resources: _resources,
                  assignments: _assignments,
                ),

                // Q&A tab
                CommunityQA(
                  questions: _questions,
                  currentVideoPosition: _currentPosition,
                  onAskQuestion: _onAskQuestion,
                ),

                // Notes tab (placeholder)
                Container(
                  padding: EdgeInsets.all(4.w),
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.surface,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Text(
                        'Personal Notes',
                        style:
                            AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                        ),
                      ),
                      SizedBox(height: 3.h),
                      Expanded(
                        child: TextField(
                          maxLines: null,
                          expands: true,
                          decoration: InputDecoration(
                            hintText: 'Take notes while watching the lesson...',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(
                                color: AppTheme.lightTheme.colorScheme.outline
                                    .withValues(alpha: 0.3),
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(
                                color: AppTheme.lightTheme.colorScheme.outline
                                    .withValues(alpha: 0.3),
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                              borderSide: BorderSide(
                                color: AppTheme.primaryLight,
                                width: 2,
                              ),
                            ),
                            contentPadding: EdgeInsets.all(3.w),
                          ),
                          style: AppTheme.lightTheme.textTheme.bodyMedium,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),

        // Quiz overlay
        if (_showQuiz)
          Positioned.fill(
            child: QuizOverlay(
              quizData: _quizData,
              onQuizComplete: _onQuizComplete,
              onSkip: _onSkipQuiz,
            ),
          ),
      ],
    );
  }
}
