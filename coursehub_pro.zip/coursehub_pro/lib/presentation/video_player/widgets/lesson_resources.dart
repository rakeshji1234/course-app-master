import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class LessonResources extends StatelessWidget {
  final List<Map<String, dynamic>> resources;
  final List<Map<String, dynamic>> assignments;

  const LessonResources({
    Key? key,
    required this.resources,
    required this.assignments,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Text(
            'Resources & Materials',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: AppTheme.lightTheme.colorScheme.onSurface,
            ),
          ),

          SizedBox(height: 3.h),

          // Downloadable Resources
          if (resources.isNotEmpty) ...[
            Row(
              children: [
                CustomIconWidget(
                  iconName: 'folder',
                  color: AppTheme.primaryLight,
                  size: 20,
                ),
                SizedBox(width: 2.w),
                Text(
                  'Downloadable Resources',
                  style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: AppTheme.lightTheme.colorScheme.onSurface,
                  ),
                ),
              ],
            ),
            SizedBox(height: 2.h),
            ...resources
                .map((resource) => _buildResourceItem(context, resource)),
            SizedBox(height: 3.h),
          ],

          // Assignments
          if (assignments.isNotEmpty) ...[
            Row(
              children: [
                CustomIconWidget(
                  iconName: 'assignment',
                  color: AppTheme.secondaryLight,
                  size: 20,
                ),
                SizedBox(width: 2.w),
                Text(
                  'Assignments',
                  style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: AppTheme.lightTheme.colorScheme.onSurface,
                  ),
                ),
              ],
            ),
            SizedBox(height: 2.h),
            ...assignments
                .map((assignment) => _buildAssignmentItem(context, assignment)),
          ],

          // Empty state
          if (resources.isEmpty && assignments.isEmpty)
            Center(
              child: Column(
                children: [
                  SizedBox(height: 4.h),
                  CustomIconWidget(
                    iconName: 'folder_open',
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    size: 48,
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    'No resources available',
                    style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  SizedBox(height: 1.h),
                  Text(
                    'Resources and assignments will appear here',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 4.h),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildResourceItem(
      BuildContext context, Map<String, dynamic> resource) {
    final String fileType = resource['type'] as String;
    final String fileName = resource['name'] as String;
    final String fileSize = resource['size'] as String;
    final bool isDownloaded = resource['downloaded'] == true;

    IconData getFileIcon() {
      switch (fileType.toLowerCase()) {
        case 'pdf':
          return Icons.picture_as_pdf;
        case 'doc':
        case 'docx':
          return Icons.description;
        case 'ppt':
        case 'pptx':
          return Icons.slideshow;
        case 'zip':
        case 'rar':
          return Icons.archive;
        case 'jpg':
        case 'png':
        case 'gif':
          return Icons.image;
        case 'mp3':
        case 'wav':
          return Icons.audiotrack;
        case 'mp4':
        case 'avi':
          return Icons.video_file;
        default:
          return Icons.insert_drive_file;
      }
    }

    Color getFileColor() {
      switch (fileType.toLowerCase()) {
        case 'pdf':
          return Colors.red;
        case 'doc':
        case 'docx':
          return Colors.blue;
        case 'ppt':
        case 'pptx':
          return Colors.orange;
        case 'zip':
        case 'rar':
          return Colors.purple;
        case 'jpg':
        case 'png':
        case 'gif':
          return Colors.green;
        case 'mp3':
        case 'wav':
          return Colors.pink;
        case 'mp4':
        case 'avi':
          return Colors.indigo;
        default:
          return AppTheme.lightTheme.colorScheme.onSurfaceVariant;
      }
    }

    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Row(
        children: [
          // File icon
          Container(
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: getFileColor().withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              getFileIcon(),
              color: getFileColor(),
              size: 24,
            ),
          ),

          SizedBox(width: 3.w),

          // File info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  fileName,
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                    color: AppTheme.lightTheme.colorScheme.onSurface,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                SizedBox(height: 0.5.h),
                Row(
                  children: [
                    Text(
                      fileType.toUpperCase(),
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: getFileColor(),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      '•',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      fileSize,
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    if (isDownloaded) ...[
                      SizedBox(width: 2.w),
                      Text(
                        '•',
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                      SizedBox(width: 2.w),
                      CustomIconWidget(
                        iconName: 'download_done',
                        color: AppTheme.successLight,
                        size: 14,
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),

          // Download button
          GestureDetector(
            onTap: () => _downloadResource(context, resource),
            child: Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: isDownloaded
                    ? AppTheme.successLight.withValues(alpha: 0.1)
                    : AppTheme.primaryLight.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(6),
              ),
              child: CustomIconWidget(
                iconName: isDownloaded ? 'download_done' : 'download',
                color: isDownloaded
                    ? AppTheme.successLight
                    : AppTheme.primaryLight,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAssignmentItem(
      BuildContext context, Map<String, dynamic> assignment) {
    final String title = assignment['title'] as String;
    final String description = assignment['description'] as String;
    final String dueDate = assignment['dueDate'] as String;
    final String status = assignment['status'] as String;
    final bool isSubmitted = status == 'submitted';
    final bool isOverdue = status == 'overdue';

    Color getStatusColor() {
      switch (status) {
        case 'submitted':
          return AppTheme.successLight;
        case 'overdue':
          return AppTheme.errorLight;
        case 'pending':
        default:
          return AppTheme.warningLight;
      }
    }

    String getStatusText() {
      switch (status) {
        case 'submitted':
          return 'Submitted';
        case 'overdue':
          return 'Overdue';
        case 'pending':
        default:
          return 'Pending';
      }
    }

    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: getStatusColor().withValues(alpha: 0.3),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  title,
                  style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: AppTheme.lightTheme.colorScheme.onSurface,
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  color: getStatusColor().withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  getStatusText(),
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: getStatusColor(),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            description,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              height: 1.4,
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              CustomIconWidget(
                iconName: 'schedule',
                color: isOverdue
                    ? AppTheme.errorLight
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 16,
              ),
              SizedBox(width: 1.w),
              Text(
                'Due: $dueDate',
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: isOverdue
                      ? AppTheme.errorLight
                      : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  fontWeight: isOverdue ? FontWeight.w600 : FontWeight.w400,
                ),
              ),
              const Spacer(),
              if (!isSubmitted)
                ElevatedButton(
                  onPressed: () => _startAssignment(context, assignment),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryLight,
                    padding:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6),
                    ),
                  ),
                  child: Text(
                    'Start Assignment',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                )
              else
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CustomIconWidget(
                      iconName: 'check_circle',
                      color: AppTheme.successLight,
                      size: 16,
                    ),
                    SizedBox(width: 1.w),
                    Text(
                      'Completed',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.successLight,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
            ],
          ),
        ],
      ),
    );
  }

  void _downloadResource(BuildContext context, Map<String, dynamic> resource) {
    // Simulate download process
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'download',
              color: Colors.white,
              size: 16,
            ),
            SizedBox(width: 2.w),
            Text('Downloading ${resource['name']}...'),
          ],
        ),
        backgroundColor: AppTheme.primaryLight,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _startAssignment(BuildContext context, Map<String, dynamic> assignment) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Start Assignment',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          content: Text(
            'You are about to start "${assignment['title']}". Make sure you have enough time to complete it.',
            style: AppTheme.lightTheme.textTheme.bodyMedium,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                // Navigate to assignment or quiz screen
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Assignment started!'),
                    backgroundColor: AppTheme.successLight,
                  ),
                );
              },
              child: Text('Start'),
            ),
          ],
        );
      },
    );
  }
}
