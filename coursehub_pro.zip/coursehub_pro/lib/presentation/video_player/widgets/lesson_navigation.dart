import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class LessonNavigation extends StatelessWidget {
  final Map<String, dynamic> currentLesson;
  final List<Map<String, dynamic>> lessons;
  final Function(Map<String, dynamic>) onLessonSelect;
  final VoidCallback? onPrevious;
  final VoidCallback? onNext;
  final bool autoPlay;
  final Function(bool) onAutoPlayToggle;

  const LessonNavigation({
    Key? key,
    required this.currentLesson,
    required this.lessons,
    required this.onLessonSelect,
    this.onPrevious,
    this.onNext,
    required this.autoPlay,
    required this.onAutoPlayToggle,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final currentIndex =
        lessons.indexWhere((lesson) => lesson['id'] == currentLesson['id']);
    final progress =
        currentIndex >= 0 ? (currentIndex + 1) / lessons.length : 0.0;

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Progress header
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Lesson Progress',
                      style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    Row(
                      children: [
                        Expanded(
                          child: LinearProgressIndicator(
                            value: progress,
                            backgroundColor: AppTheme
                                .lightTheme.colorScheme.outline
                                .withValues(alpha: 0.2),
                            valueColor: AlwaysStoppedAnimation<Color>(
                                AppTheme.primaryLight),
                            minHeight: 6,
                          ),
                        ),
                        SizedBox(width: 3.w),
                        Text(
                          '${currentIndex + 1}/${lessons.length}',
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            fontWeight: FontWeight.w500,
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),

          SizedBox(height: 3.h),

          // Current lesson info
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.primaryLight.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: AppTheme.primaryLight.withValues(alpha: 0.2),
                width: 1,
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryLight,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: CustomIconWidget(
                    iconName: 'play_circle_filled',
                    color: Colors.white,
                    size: 20,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        currentLesson['title'] as String,
                        style:
                            AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 0.5.h),
                      Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'access_time',
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                            size: 14,
                          ),
                          SizedBox(width: 1.w),
                          Text(
                            currentLesson['duration'] as String,
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                          SizedBox(width: 4.w),
                          if (currentLesson['completed'] == true) ...[
                            CustomIconWidget(
                              iconName: 'check_circle',
                              color: AppTheme.successLight,
                              size: 14,
                            ),
                            SizedBox(width: 1.w),
                            Text(
                              'Completed',
                              style: AppTheme.lightTheme.textTheme.bodySmall
                                  ?.copyWith(
                                color: AppTheme.successLight,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 3.h),

          // Navigation controls
          Row(
            children: [
              // Previous button
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: onPrevious,
                  icon: CustomIconWidget(
                    iconName: 'skip_previous',
                    color: onPrevious != null
                        ? Colors.white
                        : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    size: 18,
                  ),
                  label: Text(
                    'Previous',
                    style: TextStyle(
                      color: onPrevious != null
                          ? Colors.white
                          : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: onPrevious != null
                        ? AppTheme.primaryLight
                        : AppTheme.lightTheme.colorScheme.outline
                            .withValues(alpha: 0.2),
                    foregroundColor: onPrevious != null
                        ? Colors.white
                        : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    padding: EdgeInsets.symmetric(vertical: 1.5.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),

              SizedBox(width: 3.w),

              // Next button
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: onNext,
                  icon: CustomIconWidget(
                    iconName: 'skip_next',
                    color: onNext != null
                        ? Colors.white
                        : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    size: 18,
                  ),
                  label: Text(
                    'Next',
                    style: TextStyle(
                      color: onNext != null
                          ? Colors.white
                          : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: onNext != null
                        ? AppTheme.primaryLight
                        : AppTheme.lightTheme.colorScheme.outline
                            .withValues(alpha: 0.2),
                    foregroundColor: onNext != null
                        ? Colors.white
                        : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    padding: EdgeInsets.symmetric(vertical: 1.5.h),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
            ],
          ),

          SizedBox(height: 2.h),

          // Auto-play toggle
          Row(
            children: [
              Switch(
                value: autoPlay,
                onChanged: onAutoPlayToggle,
                activeColor: AppTheme.primaryLight,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: Text(
                  'Auto-play next lesson',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurface,
                  ),
                ),
              ),
            ],
          ),

          SizedBox(height: 3.h),

          // Chapter markers
          Text(
            'Chapter Outline',
            style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w600,
              color: AppTheme.lightTheme.colorScheme.onSurface,
            ),
          ),

          SizedBox(height: 2.h),

          Container(
            constraints: BoxConstraints(maxHeight: 25.h),
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: lessons.length,
              separatorBuilder: (context, index) => SizedBox(height: 1.h),
              itemBuilder: (context, index) {
                final lesson = lessons[index];
                final isCurrentLesson = lesson['id'] == currentLesson['id'];
                final isCompleted = lesson['completed'] == true;

                return GestureDetector(
                  onTap: () => onLessonSelect(lesson),
                  child: Container(
                    padding: EdgeInsets.all(3.w),
                    decoration: BoxDecoration(
                      color: isCurrentLesson
                          ? AppTheme.primaryLight.withValues(alpha: 0.1)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(8),
                      border: isCurrentLesson
                          ? Border.all(
                              color:
                                  AppTheme.primaryLight.withValues(alpha: 0.3))
                          : null,
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 6.w,
                          height: 6.w,
                          decoration: BoxDecoration(
                            color: isCompleted
                                ? AppTheme.successLight
                                : isCurrentLesson
                                    ? AppTheme.primaryLight
                                    : AppTheme.lightTheme.colorScheme.outline
                                        .withValues(alpha: 0.3),
                            shape: BoxShape.circle,
                          ),
                          child: Center(
                            child: isCompleted
                                ? CustomIconWidget(
                                    iconName: 'check',
                                    color: Colors.white,
                                    size: 14,
                                  )
                                : Text(
                                    '${index + 1}',
                                    style: AppTheme
                                        .lightTheme.textTheme.bodySmall
                                        ?.copyWith(
                                      color: isCurrentLesson
                                          ? Colors.white
                                          : AppTheme.lightTheme.colorScheme
                                              .onSurfaceVariant,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 10.sp,
                                    ),
                                  ),
                          ),
                        ),
                        SizedBox(width: 3.w),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                lesson['title'] as String,
                                style: AppTheme.lightTheme.textTheme.bodyMedium
                                    ?.copyWith(
                                  fontWeight: isCurrentLesson
                                      ? FontWeight.w600
                                      : FontWeight.w500,
                                  color: isCurrentLesson
                                      ? AppTheme.primaryLight
                                      : AppTheme
                                          .lightTheme.colorScheme.onSurface,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                              SizedBox(height: 0.5.h),
                              Text(
                                lesson['duration'] as String,
                                style: AppTheme.lightTheme.textTheme.bodySmall
                                    ?.copyWith(
                                  color: AppTheme
                                      .lightTheme.colorScheme.onSurfaceVariant,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (isCurrentLesson)
                          CustomIconWidget(
                            iconName: 'play_arrow',
                            color: AppTheme.primaryLight,
                            size: 20,
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
