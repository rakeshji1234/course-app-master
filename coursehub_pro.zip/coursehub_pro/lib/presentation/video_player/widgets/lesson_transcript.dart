import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class LessonTranscript extends StatefulWidget {
  final List<Map<String, dynamic>> transcriptData;
  final Duration currentPosition;
  final Function(Duration) onSeekToTimestamp;

  const LessonTranscript({
    Key? key,
    required this.transcriptData,
    required this.currentPosition,
    required this.onSeekToTimestamp,
  }) : super(key: key);

  @override
  State<LessonTranscript> createState() => _LessonTranscriptState();
}

class _LessonTranscriptState extends State<LessonTranscript> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  final ScrollController _scrollController = ScrollController();

  List<Map<String, dynamic>> get filteredTranscript {
    if (_searchQuery.isEmpty) return widget.transcriptData;
    return widget.transcriptData.where((item) {
      final text = (item['text'] as String).toLowerCase();
      return text.contains(_searchQuery.toLowerCase());
    }).toList();
  }

  String _formatTimestamp(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return "$twoDigitMinutes:$twoDigitSeconds";
  }

  bool _isCurrentSegment(Map<String, dynamic> segment) {
    final startTime = Duration(seconds: segment['startTime'] as int);
    final endTime = Duration(seconds: segment['endTime'] as int);
    return widget.currentPosition >= startTime &&
        widget.currentPosition <= endTime;
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with search
          Row(
            children: [
              Expanded(
                child: Text(
                  'Lesson Transcript',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: AppTheme.lightTheme.colorScheme.onSurface,
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                decoration: BoxDecoration(
                  color: AppTheme.primaryLight.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CustomIconWidget(
                      iconName: 'closed_caption',
                      color: AppTheme.primaryLight,
                      size: 16,
                    ),
                    SizedBox(width: 1.w),
                    Text(
                      'Auto-generated',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.primaryLight,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          SizedBox(height: 3.h),

          // Search bar
          Container(
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.3),
              ),
            ),
            child: TextField(
              controller: _searchController,
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
              },
              decoration: InputDecoration(
                hintText: 'Search transcript...',
                prefixIcon: Padding(
                  padding: EdgeInsets.all(3.w),
                  child: CustomIconWidget(
                    iconName: 'search',
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    size: 20,
                  ),
                ),
                suffixIcon: _searchQuery.isNotEmpty
                    ? GestureDetector(
                        onTap: () {
                          _searchController.clear();
                          setState(() {
                            _searchQuery = '';
                          });
                        },
                        child: Padding(
                          padding: EdgeInsets.all(3.w),
                          child: CustomIconWidget(
                            iconName: 'clear',
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                            size: 20,
                          ),
                        ),
                      )
                    : null,
                border: InputBorder.none,
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              ),
              style: AppTheme.lightTheme.textTheme.bodyMedium,
            ),
          ),

          SizedBox(height: 3.h),

          // Search results info
          if (_searchQuery.isNotEmpty) ...[
            Text(
              '${filteredTranscript.length} results found',
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                fontStyle: FontStyle.italic,
              ),
            ),
            SizedBox(height: 2.h),
          ],

          // Transcript content
          Expanded(
            child: filteredTranscript.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomIconWidget(
                          iconName: 'search_off',
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                          size: 48,
                        ),
                        SizedBox(height: 2.h),
                        Text(
                          'No results found',
                          style: AppTheme.lightTheme.textTheme.titleSmall
                              ?.copyWith(
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                        SizedBox(height: 1.h),
                        Text(
                          'Try different keywords',
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.separated(
                    controller: _scrollController,
                    itemCount: filteredTranscript.length,
                    separatorBuilder: (context, index) => SizedBox(height: 2.h),
                    itemBuilder: (context, index) {
                      final segment = filteredTranscript[index];
                      final isCurrentSegment = _isCurrentSegment(segment);
                      final startTime =
                          Duration(seconds: segment['startTime'] as int);

                      return GestureDetector(
                        onTap: () => widget.onSeekToTimestamp(startTime),
                        child: Container(
                          padding: EdgeInsets.all(3.w),
                          decoration: BoxDecoration(
                            color: isCurrentSegment
                                ? AppTheme.primaryLight.withValues(alpha: 0.1)
                                : Colors.transparent,
                            borderRadius: BorderRadius.circular(8),
                            border: isCurrentSegment
                                ? Border.all(
                                    color: AppTheme.primaryLight
                                        .withValues(alpha: 0.3),
                                    width: 1,
                                  )
                                : null,
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Timestamp
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 2.w, vertical: 0.5.h),
                                decoration: BoxDecoration(
                                  color: isCurrentSegment
                                      ? AppTheme.primaryLight
                                      : AppTheme.lightTheme.colorScheme.outline
                                          .withValues(alpha: 0.2),
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(
                                  _formatTimestamp(startTime),
                                  style: AppTheme.lightTheme.textTheme.bodySmall
                                      ?.copyWith(
                                    color: isCurrentSegment
                                        ? Colors.white
                                        : AppTheme.lightTheme.colorScheme
                                            .onSurfaceVariant,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 10.sp,
                                  ),
                                ),
                              ),

                              SizedBox(width: 3.w),

                              // Text content
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    RichText(
                                      text: TextSpan(
                                        style: AppTheme
                                            .lightTheme.textTheme.bodyMedium
                                            ?.copyWith(
                                          color: isCurrentSegment
                                              ? AppTheme.primaryLight
                                              : AppTheme.lightTheme.colorScheme
                                                  .onSurface,
                                          height: 1.5,
                                        ),
                                        children: _buildHighlightedText(
                                          segment['text'] as String,
                                          _searchQuery,
                                          isCurrentSegment,
                                        ),
                                      ),
                                    ),
                                    if (segment['speaker'] != null) ...[
                                      SizedBox(height: 1.h),
                                      Text(
                                        'Speaker: ${segment['speaker']}',
                                        style: AppTheme
                                            .lightTheme.textTheme.bodySmall
                                            ?.copyWith(
                                          color: AppTheme.lightTheme.colorScheme
                                              .onSurfaceVariant,
                                          fontStyle: FontStyle.italic,
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ),

                              // Play icon for current segment
                              if (isCurrentSegment)
                                CustomIconWidget(
                                  iconName: 'play_circle_filled',
                                  color: AppTheme.primaryLight,
                                  size: 20,
                                ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),

          SizedBox(height: 2.h),

          // Download transcript button
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {
                // Download transcript functionality
                _downloadTranscript();
              },
              icon: CustomIconWidget(
                iconName: 'download',
                color: AppTheme.primaryLight,
                size: 18,
              ),
              label: Text('Download Transcript'),
              style: OutlinedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 1.5.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<TextSpan> _buildHighlightedText(
      String text, String query, bool isCurrentSegment) {
    if (query.isEmpty) {
      return [TextSpan(text: text)];
    }

    final List<TextSpan> spans = [];
    final String lowerText = text.toLowerCase();
    final String lowerQuery = query.toLowerCase();

    int start = 0;
    int index = lowerText.indexOf(lowerQuery);

    while (index != -1) {
      // Add text before match
      if (index > start) {
        spans.add(TextSpan(text: text.substring(start, index)));
      }

      // Add highlighted match
      spans.add(TextSpan(
        text: text.substring(index, index + query.length),
        style: TextStyle(
          backgroundColor: AppTheme.warningLight.withValues(alpha: 0.3),
          fontWeight: FontWeight.w600,
        ),
      ));

      start = index + query.length;
      index = lowerText.indexOf(lowerQuery, start);
    }

    // Add remaining text
    if (start < text.length) {
      spans.add(TextSpan(text: text.substring(start)));
    }

    return spans;
  }

  void _downloadTranscript() {
    // Generate transcript content
    final StringBuffer buffer = StringBuffer();
    buffer.writeln('Lesson Transcript');
    buffer.writeln('Generated on: ${DateTime.now().toString().split('.')[0]}');
    buffer.writeln('');

    for (final segment in widget.transcriptData) {
      final startTime = Duration(seconds: segment['startTime'] as int);
      buffer.writeln('[${_formatTimestamp(startTime)}] ${segment['text']}');
      if (segment['speaker'] != null) {
        buffer.writeln('Speaker: ${segment['speaker']}');
      }
      buffer.writeln('');
    }

    // Here you would implement actual file download
    // For now, we'll show a success message
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Transcript download started'),
        backgroundColor: AppTheme.successLight,
      ),
    );
  }
}
