import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class QuizOverlay extends StatefulWidget {
  final Map<String, dynamic> quizData;
  final Function(Map<String, dynamic>) onQuizComplete;
  final VoidCallback onSkip;

  const QuizOverlay({
    Key? key,
    required this.quizData,
    required this.onQuizComplete,
    required this.onSkip,
  }) : super(key: key);

  @override
  State<QuizOverlay> createState() => _QuizOverlayState();
}

class _QuizOverlayState extends State<QuizOverlay>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _opacityAnimation;

  int _currentQuestionIndex = 0;
  Map<int, dynamic> _selectedAnswers = {};
  bool _showResults = false;
  bool _quizPassed = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.elasticOut,
    ));

    _opacityAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeIn,
    ));

    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> get questions =>
      (widget.quizData['questions'] as List).cast<Map<String, dynamic>>();
  Map<String, dynamic> get currentQuestion => questions[_currentQuestionIndex];
  bool get isLastQuestion => _currentQuestionIndex == questions.length - 1;
  int get passingScore => widget.quizData['passingScore'] as int? ?? 70;

  void _selectAnswer(dynamic answer) {
    setState(() {
      _selectedAnswers[_currentQuestionIndex] = answer;
    });
  }

  void _nextQuestion() {
    if (isLastQuestion) {
      _submitQuiz();
    } else {
      setState(() {
        _currentQuestionIndex++;
      });
    }
  }

  void _previousQuestion() {
    if (_currentQuestionIndex > 0) {
      setState(() {
        _currentQuestionIndex--;
      });
    }
  }

  void _submitQuiz() {
    int correctAnswers = 0;

    for (int i = 0; i < questions.length; i++) {
      final question = questions[i];
      final selectedAnswer = _selectedAnswers[i];
      final correctAnswer = question['correctAnswer'];

      if (selectedAnswer == correctAnswer) {
        correctAnswers++;
      }
    }

    final score = (correctAnswers / questions.length * 100).round();
    _quizPassed = score >= passingScore;

    setState(() {
      _showResults = true;
    });

    // Call completion callback with results
    widget.onQuizComplete({
      'score': score,
      'correctAnswers': correctAnswers,
      'totalQuestions': questions.length,
      'passed': _quizPassed,
      'answers': _selectedAnswers,
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animationController,
      builder: (context, child) {
        return Container(
          color: Colors.black.withValues(alpha: 0.8 * _opacityAnimation.value),
          child: Center(
            child: Transform.scale(
              scale: _scaleAnimation.value,
              child: Container(
                width: 90.w,
                constraints: BoxConstraints(maxHeight: 80.h),
                margin: EdgeInsets.symmetric(horizontal: 5.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.3),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: _showResults ? _buildResultsView() : _buildQuizView(),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildQuizView() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Header
        Container(
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: AppTheme.primaryLight.withValues(alpha: 0.1),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(16),
              topRight: Radius.circular(16),
            ),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.quizData['title'] as String,
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    Row(
                      children: [
                        Text(
                          'Question ${_currentQuestionIndex + 1} of ${questions.length}',
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                        SizedBox(width: 4.w),
                        Text(
                          '•',
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                        SizedBox(width: 4.w),
                        Text(
                          'Passing Score: $passingScore%',
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: widget.onSkip,
                child: Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.outline
                        .withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: CustomIconWidget(
                    iconName: 'close',
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    size: 20,
                  ),
                ),
              ),
            ],
          ),
        ),

        // Progress bar
        Container(
          height: 4,
          child: LinearProgressIndicator(
            value: (_currentQuestionIndex + 1) / questions.length,
            backgroundColor:
                AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
            valueColor: AlwaysStoppedAnimation<Color>(AppTheme.primaryLight),
          ),
        ),

        // Question content
        Expanded(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(4.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Question text
                Text(
                  currentQuestion['question'] as String,
                  style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: AppTheme.lightTheme.colorScheme.onSurface,
                    height: 1.4,
                  ),
                ),

                SizedBox(height: 3.h),

                // Question type specific content
                if (currentQuestion['type'] == 'multiple_choice')
                  _buildMultipleChoiceOptions()
                else if (currentQuestion['type'] == 'true_false')
                  _buildTrueFalseOptions()
                else if (currentQuestion['type'] == 'text_input')
                  _buildTextInputField(),

                SizedBox(height: 4.h),

                // Navigation buttons
                Row(
                  children: [
                    if (_currentQuestionIndex > 0)
                      Expanded(
                        child: OutlinedButton(
                          onPressed: _previousQuestion,
                          style: OutlinedButton.styleFrom(
                            padding: EdgeInsets.symmetric(vertical: 1.5.h),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          child: Text('Previous'),
                        ),
                      ),
                    if (_currentQuestionIndex > 0) SizedBox(width: 3.w),
                    Expanded(
                      child: ElevatedButton(
                        onPressed:
                            _selectedAnswers.containsKey(_currentQuestionIndex)
                                ? _nextQuestion
                                : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.primaryLight,
                          padding: EdgeInsets.symmetric(vertical: 1.5.h),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: Text(
                          isLastQuestion ? 'Submit Quiz' : 'Next Question',
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMultipleChoiceOptions() {
    final List<String> options =
        (currentQuestion['options'] as List).cast<String>();

    return Column(
      children: options.asMap().entries.map((entry) {
        final int index = entry.key;
        final String option = entry.value;
        final bool isSelected =
            _selectedAnswers[_currentQuestionIndex] == index;

        return GestureDetector(
          onTap: () => _selectAnswer(index),
          child: Container(
            width: double.infinity,
            margin: EdgeInsets.only(bottom: 2.h),
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: isSelected
                  ? AppTheme.primaryLight.withValues(alpha: 0.1)
                  : AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: isSelected
                    ? AppTheme.primaryLight
                    : AppTheme.lightTheme.colorScheme.outline
                        .withValues(alpha: 0.3),
                width: isSelected ? 2 : 1,
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 6.w,
                  height: 6.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color:
                        isSelected ? AppTheme.primaryLight : Colors.transparent,
                    border: Border.all(
                      color: isSelected
                          ? AppTheme.primaryLight
                          : AppTheme.lightTheme.colorScheme.outline
                              .withValues(alpha: 0.5),
                      width: 2,
                    ),
                  ),
                  child: isSelected
                      ? Center(
                          child: CustomIconWidget(
                            iconName: 'check',
                            color: Colors.white,
                            size: 16,
                          ),
                        )
                      : null,
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Text(
                    option,
                    style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                      color: isSelected
                          ? AppTheme.primaryLight
                          : AppTheme.lightTheme.colorScheme.onSurface,
                      fontWeight:
                          isSelected ? FontWeight.w500 : FontWeight.w400,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildTrueFalseOptions() {
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: () => _selectAnswer(true),
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 2.h),
              decoration: BoxDecoration(
                color: _selectedAnswers[_currentQuestionIndex] == true
                    ? AppTheme.successLight.withValues(alpha: 0.1)
                    : AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: _selectedAnswers[_currentQuestionIndex] == true
                      ? AppTheme.successLight
                      : AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.3),
                  width:
                      _selectedAnswers[_currentQuestionIndex] == true ? 2 : 1,
                ),
              ),
              child: Column(
                children: [
                  CustomIconWidget(
                    iconName: 'check_circle',
                    color: _selectedAnswers[_currentQuestionIndex] == true
                        ? AppTheme.successLight
                        : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    size: 32,
                  ),
                  SizedBox(height: 1.h),
                  Text(
                    'True',
                    style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                      color: _selectedAnswers[_currentQuestionIndex] == true
                          ? AppTheme.successLight
                          : AppTheme.lightTheme.colorScheme.onSurface,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        SizedBox(width: 4.w),
        Expanded(
          child: GestureDetector(
            onTap: () => _selectAnswer(false),
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 2.h),
              decoration: BoxDecoration(
                color: _selectedAnswers[_currentQuestionIndex] == false
                    ? AppTheme.errorLight.withValues(alpha: 0.1)
                    : AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: _selectedAnswers[_currentQuestionIndex] == false
                      ? AppTheme.errorLight
                      : AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.3),
                  width:
                      _selectedAnswers[_currentQuestionIndex] == false ? 2 : 1,
                ),
              ),
              child: Column(
                children: [
                  CustomIconWidget(
                    iconName: 'cancel',
                    color: _selectedAnswers[_currentQuestionIndex] == false
                        ? AppTheme.errorLight
                        : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    size: 32,
                  ),
                  SizedBox(height: 1.h),
                  Text(
                    'False',
                    style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                      color: _selectedAnswers[_currentQuestionIndex] == false
                          ? AppTheme.errorLight
                          : AppTheme.lightTheme.colorScheme.onSurface,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTextInputField() {
    return TextField(
      onChanged: (value) => _selectAnswer(value),
      decoration: InputDecoration(
        hintText: 'Enter your answer...',
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: AppTheme.primaryLight, width: 2),
        ),
        contentPadding: EdgeInsets.all(3.w),
      ),
      style: AppTheme.lightTheme.textTheme.bodyMedium,
      maxLines: 3,
    );
  }

  Widget _buildResultsView() {
    final score = (widget.quizData['score'] as int? ?? 0);
    final correctAnswers = (widget.quizData['correctAnswers'] as int? ?? 0);
    final totalQuestions = questions.length;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Header
        Container(
          padding: EdgeInsets.all(4.w),
          decoration: BoxDecoration(
            color: _quizPassed
                ? AppTheme.successLight.withValues(alpha: 0.1)
                : AppTheme.errorLight.withValues(alpha: 0.1),
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(16),
              topRight: Radius.circular(16),
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color:
                      _quizPassed ? AppTheme.successLight : AppTheme.errorLight,
                  shape: BoxShape.circle,
                ),
                child: CustomIconWidget(
                  iconName: _quizPassed ? 'check' : 'close',
                  color: Colors.white,
                  size: 24,
                ),
              ),
              SizedBox(width: 4.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _quizPassed ? 'Quiz Passed!' : 'Quiz Failed',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: _quizPassed
                            ? AppTheme.successLight
                            : AppTheme.errorLight,
                      ),
                    ),
                    Text(
                      _quizPassed
                          ? 'Congratulations! You can continue to the next lesson.'
                          : 'Don\'t worry, you can retake the quiz.',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        // Results content
        Padding(
          padding: EdgeInsets.all(4.w),
          child: Column(
            children: [
              // Score display
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surface
                      .withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: AppTheme.lightTheme.colorScheme.outline
                        .withValues(alpha: 0.2),
                  ),
                ),
                child: Column(
                  children: [
                    Text(
                      '$score%',
                      style:
                          AppTheme.lightTheme.textTheme.displaySmall?.copyWith(
                        fontWeight: FontWeight.w700,
                        color: _quizPassed
                            ? AppTheme.successLight
                            : AppTheme.errorLight,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      '$correctAnswers out of $totalQuestions correct',
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    SizedBox(height: 2.h),
                    LinearProgressIndicator(
                      value: score / 100,
                      backgroundColor: AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.2),
                      valueColor: AlwaysStoppedAnimation<Color>(
                        _quizPassed
                            ? AppTheme.successLight
                            : AppTheme.errorLight,
                      ),
                      minHeight: 8,
                    ),
                  ],
                ),
              ),

              SizedBox(height: 4.h),

              // Action buttons
              Row(
                children: [
                  if (!_quizPassed)
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () {
                          // Retake quiz
                          setState(() {
                            _currentQuestionIndex = 0;
                            _selectedAnswers.clear();
                            _showResults = false;
                          });
                        },
                        style: OutlinedButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 1.5.h),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: Text('Retake Quiz'),
                      ),
                    ),
                  if (!_quizPassed) SizedBox(width: 3.w),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        // Continue or close
                        Navigator.of(context).pop();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _quizPassed
                            ? AppTheme.successLight
                            : AppTheme.primaryLight,
                        padding: EdgeInsets.symmetric(vertical: 1.5.h),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: Text(
                        _quizPassed ? 'Continue Learning' : 'Close',
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}
