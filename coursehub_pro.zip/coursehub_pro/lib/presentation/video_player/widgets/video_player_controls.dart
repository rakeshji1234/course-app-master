import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class VideoPlayerControls extends StatefulWidget {
  final bool isPlaying;
  final bool isFullscreen;
  final Duration currentPosition;
  final Duration totalDuration;
  final double playbackSpeed;
  final String quality;
  final VoidCallback onPlayPause;
  final VoidCallback onFullscreen;
  final Function(double) onSeek;
  final Function(double) onSpeedChange;
  final Function(String) onQualityChange;
  final VoidCallback onRewind;
  final VoidCallback onForward;

  const VideoPlayerControls({
    Key? key,
    required this.isPlaying,
    required this.isFullscreen,
    required this.currentPosition,
    required this.totalDuration,
    required this.playbackSpeed,
    required this.quality,
    required this.onPlayPause,
    required this.onFullscreen,
    required this.onSeek,
    required this.onSpeedChange,
    required this.onQualityChange,
    required this.onRewind,
    required this.onForward,
  }) : super(key: key);

  @override
  State<VideoPlayerControls> createState() => _VideoPlayerControlsState();
}

class _VideoPlayerControlsState extends State<VideoPlayerControls> {
  bool _showControls = true;
  bool _showSpeedMenu = false;
  bool _showQualityMenu = false;

  final List<double> _speedOptions = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
  final List<String> _qualityOptions = [
    'Auto',
    '1080p',
    '720p',
    '480p',
    '360p'
  ];

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
    String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
    return duration.inHours > 0
        ? "${twoDigits(duration.inHours)}:$twoDigitMinutes:$twoDigitSeconds"
        : "$twoDigitMinutes:$twoDigitSeconds";
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: _showControls ? 1.0 : 0.0,
      duration: const Duration(milliseconds: 300),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.black.withValues(alpha: 0.7),
              Colors.transparent,
              Colors.black.withValues(alpha: 0.7),
            ],
          ),
        ),
        child: Column(
          children: [
            // Top controls
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: EdgeInsets.all(2.w),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.5),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: CustomIconWidget(
                        iconName: 'arrow_back',
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                  SizedBox(width: 4.w),
                  Expanded(
                    child: Text(
                      'Introduction to Flutter Development',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  // Quality selector
                  GestureDetector(
                    onTap: () =>
                        setState(() => _showQualityMenu = !_showQualityMenu),
                    child: Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.5),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            widget.quality,
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          SizedBox(width: 1.w),
                          CustomIconWidget(
                            iconName: _showQualityMenu
                                ? 'keyboard_arrow_up'
                                : 'keyboard_arrow_down',
                            color: Colors.white,
                            size: 16,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Quality menu
            if (_showQualityMenu)
              Positioned(
                top: 8.h,
                right: 4.w,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.8),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: _qualityOptions.map((quality) {
                      return GestureDetector(
                        onTap: () {
                          widget.onQualityChange(quality);
                          setState(() => _showQualityMenu = false);
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 4.w, vertical: 1.5.h),
                          child: Text(
                            quality,
                            style: AppTheme.lightTheme.textTheme.bodyMedium
                                ?.copyWith(
                              color: widget.quality == quality
                                  ? AppTheme.primaryLight
                                  : Colors.white,
                              fontWeight: widget.quality == quality
                                  ? FontWeight.w600
                                  : FontWeight.w400,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),

            const Spacer(),

            // Center play/pause button
            Center(
              child: GestureDetector(
                onTap: widget.onPlayPause,
                child: Container(
                  padding: EdgeInsets.all(4.w),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.6),
                    shape: BoxShape.circle,
                  ),
                  child: CustomIconWidget(
                    iconName: widget.isPlaying ? 'pause' : 'play_arrow',
                    color: Colors.white,
                    size: 32,
                  ),
                ),
              ),
            ),

            const Spacer(),

            // Bottom controls
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              child: Column(
                children: [
                  // Progress bar
                  Row(
                    children: [
                      Text(
                        _formatDuration(widget.currentPosition),
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: Colors.white,
                          fontSize: 10.sp,
                        ),
                      ),
                      SizedBox(width: 2.w),
                      Expanded(
                        child: SliderTheme(
                          data: SliderTheme.of(context).copyWith(
                            activeTrackColor: AppTheme.primaryLight,
                            inactiveTrackColor:
                                Colors.white.withValues(alpha: 0.3),
                            thumbColor: AppTheme.primaryLight,
                            thumbShape: const RoundSliderThumbShape(
                                enabledThumbRadius: 6),
                            overlayShape: const RoundSliderOverlayShape(
                                overlayRadius: 12),
                            trackHeight: 3,
                          ),
                          child: Slider(
                            value: widget.totalDuration.inMilliseconds > 0
                                ? widget.currentPosition.inMilliseconds /
                                    widget.totalDuration.inMilliseconds
                                : 0.0,
                            onChanged: (value) {
                              final position = Duration(
                                milliseconds: (value *
                                        widget.totalDuration.inMilliseconds)
                                    .round(),
                              );
                              widget.onSeek(value);
                            },
                          ),
                        ),
                      ),
                      SizedBox(width: 2.w),
                      Text(
                        _formatDuration(widget.totalDuration),
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color: Colors.white,
                          fontSize: 10.sp,
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 2.h),

                  // Control buttons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          // Rewind button
                          GestureDetector(
                            onTap: widget.onRewind,
                            child: Container(
                              padding: EdgeInsets.all(2.w),
                              child: CustomIconWidget(
                                iconName: 'replay_10',
                                color: Colors.white,
                                size: 24,
                              ),
                            ),
                          ),

                          SizedBox(width: 4.w),

                          // Forward button
                          GestureDetector(
                            onTap: widget.onForward,
                            child: Container(
                              padding: EdgeInsets.all(2.w),
                              child: CustomIconWidget(
                                iconName: 'forward_10',
                                color: Colors.white,
                                size: 24,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          // Speed control
                          GestureDetector(
                            onTap: () => setState(
                                () => _showSpeedMenu = !_showSpeedMenu),
                            child: Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 3.w, vertical: 1.h),
                              decoration: BoxDecoration(
                                color: Colors.black.withValues(alpha: 0.5),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Text(
                                '${widget.playbackSpeed}x',
                                style: AppTheme.lightTheme.textTheme.bodySmall
                                    ?.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),

                          SizedBox(width: 4.w),

                          // Fullscreen button
                          GestureDetector(
                            onTap: widget.onFullscreen,
                            child: Container(
                              padding: EdgeInsets.all(2.w),
                              child: CustomIconWidget(
                                iconName: widget.isFullscreen
                                    ? 'fullscreen_exit'
                                    : 'fullscreen',
                                color: Colors.white,
                                size: 24,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Speed menu
            if (_showSpeedMenu)
              Positioned(
                bottom: 12.h,
                right: 4.w,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.8),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: _speedOptions.map((speed) {
                      return GestureDetector(
                        onTap: () {
                          widget.onSpeedChange(speed);
                          setState(() => _showSpeedMenu = false);
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 4.w, vertical: 1.5.h),
                          child: Text(
                            '${speed}x',
                            style: AppTheme.lightTheme.textTheme.bodyMedium
                                ?.copyWith(
                              color: widget.playbackSpeed == speed
                                  ? AppTheme.primaryLight
                                  : Colors.white,
                              fontWeight: widget.playbackSpeed == speed
                                  ? FontWeight.w600
                                  : FontWeight.w400,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
