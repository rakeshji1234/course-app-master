import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/account_summary_widget.dart';
import './widgets/achievements_widget.dart';
import './widgets/course_card_widget.dart';
import './widgets/notification_center_widget.dart';
import './widgets/quick_access_widget.dart';
import './widgets/recent_activity_widget.dart';
import './widgets/upcoming_deadlines_widget.dart';

class StudentDashboard extends StatefulWidget {
  const StudentDashboard({Key? key}) : super(key: key);

  @override
  State<StudentDashboard> createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> {
  // Mock data for enrolled courses
  final List<Map<String, dynamic>> enrolledCourses = [
    {
      "id": 1,
      "title": "Complete Flutter Development Bootcamp",
      "instructor": "Dr. Angela Yu",
      "thumbnail":
          "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "progress": 75,
      "nextLesson": "State Management with Provider",
      "lastAccessed": "2 hours ago",
    },
    {
      "id": 2,
      "title": "Advanced React Native Development",
      "instructor": "Maximilian Schwarzmüller",
      "thumbnail":
          "https://images.unsplash.com/photo-1555066931-4365d14bab8c?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "progress": 45,
      "nextLesson": "Navigation Patterns",
      "lastAccessed": "1 day ago",
    },
    {
      "id": 3,
      "title": "UI/UX Design Fundamentals",
      "instructor": "Sarah Johnson",
      "thumbnail":
          "https://images.unsplash.com/photo-1561070791-2526d30994b5?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3",
      "progress": 100,
      "nextLesson": "",
      "lastAccessed": "3 days ago",
    },
  ];

  // Mock data for upcoming deadlines
  final List<Map<String, dynamic>> upcomingDeadlines = [
    {
      "id": 1,
      "title": "Flutter State Management Quiz",
      "course": "Complete Flutter Development",
      "type": "quiz",
      "dueDate": "Tomorrow, 11:59 PM",
      "priority": "high",
    },
    {
      "id": 2,
      "title": "React Native Project Submission",
      "course": "Advanced React Native",
      "type": "assignment",
      "dueDate": "Dec 8, 2024",
      "priority": "medium",
    },
  ];

  // Mock data for recent activities
  final List<Map<String, dynamic>> recentActivities = [
    {
      "id": 1,
      "type": "lesson_completed",
      "title": "Completed: Introduction to Widgets",
      "description": "Complete Flutter Development Bootcamp",
      "timestamp": "2 hours ago",
      "score": null,
    },
    {
      "id": 2,
      "type": "quiz_completed",
      "title": "Flutter Basics Quiz",
      "description": "Scored 85% on first attempt",
      "timestamp": "1 day ago",
      "score": 85,
    },
    {
      "id": 3,
      "type": "certificate",
      "title": "Certificate Earned",
      "description": "UI/UX Design Fundamentals",
      "timestamp": "3 days ago",
      "score": null,
    },
    {
      "id": 4,
      "type": "discussion",
      "title": "Replied to discussion",
      "description": "Best practices for state management",
      "timestamp": "1 week ago",
      "score": null,
    },
  ];

  // Mock data for account summary
  final Map<String, dynamic> accountData = {
    "walletBalance": "\\₹2,450",
    "storeCredits": "\\₹500",
    "recentTransactions": [
      {
        "id": 1,
        "type": "debit",
        "description": "Flutter Course Purchase",
        "amount": "\\₹1,999",
        "date": "Dec 1, 2024",
      },
      {
        "id": 2,
        "type": "credit",
        "description": "Referral Bonus",
        "amount": "\\₹200",
        "date": "Nov 28, 2024",
      },
      {
        "id": 3,
        "type": "debit",
        "description": "React Native Course",
        "amount": "\\₹2,499",
        "date": "Nov 25, 2024",
      },
    ],
  };

  // Mock data for achievements
  final List<Map<String, dynamic>> achievements = [
    {
      "id": 1,
      "title": "First Course",
      "description": "Completed your first course",
      "earnedDate": "Nov 20, 2024",
    },
    {
      "id": 2,
      "title": "Quiz Master",
      "description": "Scored 90%+ on 5 quizzes",
      "earnedDate": "Nov 25, 2024",
    },
    {
      "id": 3,
      "title": "Active Learner",
      "description": "7-day learning streak",
      "earnedDate": "Dec 1, 2024",
    },
  ];

  // Mock data for certificates
  final List<Map<String, dynamic>> certificates = [
    {
      "id": 1,
      "courseName": "UI/UX Design Fundamentals",
      "completedDate": "Nov 30, 2024",
      "certificateUrl": "https://example.com/certificate/1",
    },
  ];

  // Mock data for notifications
  final List<Map<String, dynamic>> notifications = [
    {
      "id": 1,
      "type": "quiz_reminder",
      "title": "Quiz Due Tomorrow",
      "message": "Flutter State Management Quiz is due tomorrow at 11:59 PM",
      "timestamp": "1 hour ago",
      "isRead": false,
    },
    {
      "id": 2,
      "type": "course_update",
      "title": "New Lesson Available",
      "message": "Advanced Navigation has been added to React Native course",
      "timestamp": "3 hours ago",
      "isRead": false,
    },
    {
      "id": 3,
      "type": "certificate",
      "title": "Certificate Ready",
      "message": "Your UI/UX Design certificate is ready for download",
      "timestamp": "2 days ago",
      "isRead": true,
    },
    {
      "id": 4,
      "type": "system",
      "title": "Maintenance Notice",
      "message": "Scheduled maintenance on Dec 10, 2024 from 2-4 AM",
      "timestamp": "1 week ago",
      "isRead": true,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      appBar: AppBar(
        title: Text('Dashboard'),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.pushNamed(context, '/device-management');
            },
            icon: CustomIconWidget(
              iconName: 'devices',
              color: AppTheme.textPrimaryLight,
              size: 24,
            ),
          ),
          IconButton(
            onPressed: () {
              // Handle profile navigation
            },
            icon: CustomIconWidget(
              iconName: 'account_circle',
              color: AppTheme.textPrimaryLight,
              size: 24,
            ),
          ),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          // Web/Desktop layout
          if (constraints.maxWidth > 768) {
            return _buildWebLayout();
          }
          // Mobile layout
          return _buildMobileLayout();
        },
      ),
    );
  }

  Widget _buildWebLayout() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Main content area
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildWelcomeSection(),
                SizedBox(height: 3.h),
                _buildEnrolledCoursesSection(),
                SizedBox(height: 3.h),
                RecentActivityWidget(activities: recentActivities),
                SizedBox(height: 3.h),
                AchievementsWidget(
                  achievements: achievements,
                  certificates: certificates,
                ),
              ],
            ),
          ),

          SizedBox(width: 4.w),

          // Sidebar
          Expanded(
            flex: 1,
            child: Column(
              children: [
                UpcomingDeadlinesWidget(deadlines: upcomingDeadlines),
                SizedBox(height: 3.h),
                QuickAccessWidget(
                  onBookmarksPressed: () {
                    // Handle bookmarks
                  },
                  onDownloadsPressed: () {
                    // Handle downloads
                  },
                  onDiscussionsPressed: () {
                    // Handle discussions
                  },
                ),
                SizedBox(height: 3.h),
                AccountSummaryWidget(accountData: accountData),
                SizedBox(height: 3.h),
                NotificationCenterWidget(notifications: notifications),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMobileLayout() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildWelcomeSection(),
          SizedBox(height: 3.h),
          _buildEnrolledCoursesSection(),
          SizedBox(height: 3.h),
          UpcomingDeadlinesWidget(deadlines: upcomingDeadlines),
          SizedBox(height: 3.h),
          QuickAccessWidget(
            onBookmarksPressed: () {
              // Handle bookmarks
            },
            onDownloadsPressed: () {
              // Handle downloads
            },
            onDiscussionsPressed: () {
              // Handle discussions
            },
          ),
          SizedBox(height: 3.h),
          RecentActivityWidget(activities: recentActivities),
          SizedBox(height: 3.h),
          AccountSummaryWidget(accountData: accountData),
          SizedBox(height: 3.h),
          AchievementsWidget(
            achievements: achievements,
            certificates: certificates,
          ),
          SizedBox(height: 3.h),
          NotificationCenterWidget(notifications: notifications),
          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  Widget _buildWelcomeSection() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.primaryLight,
            AppTheme.primaryVariantLight,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Welcome back, Alex!',
            style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.w700,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Continue your learning journey. You have 2 pending assignments.',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: Colors.white.withValues(alpha: 0.9),
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/course-catalog');
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: AppTheme.primaryLight,
                    padding: EdgeInsets.symmetric(vertical: 1.5.h),
                  ),
                  child: Text(
                    'Browse Courses',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
              ),
              SizedBox(width: 3.w),
              OutlinedButton(
                onPressed: () {
                  // Handle view progress
                },
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: BorderSide(color: Colors.white),
                  padding:
                      EdgeInsets.symmetric(vertical: 1.5.h, horizontal: 4.w),
                ),
                child: Text(
                  'View Progress',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEnrolledCoursesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Continue Learning',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w700,
              ),
            ),
            TextButton(
              onPressed: () {
                // Handle view all courses
              },
              child: Text(
                'View All',
                style: TextStyle(
                  color: AppTheme.primaryLight,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 2.h),
        SizedBox(
          height: 45.h,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: enrolledCourses.length,
            itemBuilder: (context, index) {
              final course = enrolledCourses[index];
              return CourseCardWidget(
                course: course,
                onTap: () {
                  Navigator.pushNamed(context, '/course-details');
                },
              );
            },
          ),
        ),
      ],
    );
  }
}
