import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class RecentActivityWidget extends StatelessWidget {
  final List<Map<String, dynamic>> activities;

  const RecentActivityWidget({
    Key? key,
    required this.activities,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'history',
                color: AppTheme.primaryLight,
                size: 20,
              ),
              SizedBox(width: 2.w),
              Text(
                'Recent Activity',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          activities.isEmpty
              ? Container(
                  padding: EdgeInsets.symmetric(vertical: 3.h),
                  child: Center(
                    child: Column(
                      children: [
                        CustomIconWidget(
                          iconName: 'inbox',
                          color: AppTheme.textDisabledLight,
                          size: 32,
                        ),
                        SizedBox(height: 1.h),
                        Text(
                          'No recent activity',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: AppTheme.textSecondaryLight,
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : Column(
                  children: activities.take(5).map((activity) {
                    return Container(
                      margin: EdgeInsets.only(bottom: 2.h),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: EdgeInsets.all(2.w),
                            decoration: BoxDecoration(
                              color:
                                  _getActivityColor(activity['type'] as String)
                                      .withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: CustomIconWidget(
                              iconName:
                                  _getActivityIcon(activity['type'] as String),
                              color:
                                  _getActivityColor(activity['type'] as String),
                              size: 16,
                            ),
                          ),
                          SizedBox(width: 3.w),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  activity['title'] as String,
                                  style: AppTheme
                                      .lightTheme.textTheme.bodyMedium
                                      ?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                SizedBox(height: 0.5.h),
                                if (activity['description'] != null)
                                  Text(
                                    activity['description'] as String,
                                    style: AppTheme
                                        .lightTheme.textTheme.bodySmall
                                        ?.copyWith(
                                      color: AppTheme.textSecondaryLight,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                SizedBox(height: 0.5.h),
                                Text(
                                  activity['timestamp'] as String,
                                  style: AppTheme.lightTheme.textTheme.bodySmall
                                      ?.copyWith(
                                    color: AppTheme.textDisabledLight,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          if (activity['score'] != null)
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 2.w, vertical: 0.5.h),
                              decoration: BoxDecoration(
                                color: _getScoreColor(activity['score'] as int),
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                '${activity['score']}%',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10.sp,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
        ],
      ),
    );
  }

  String _getActivityIcon(String type) {
    switch (type) {
      case 'lesson_completed':
        return 'play_circle_filled';
      case 'quiz_completed':
        return 'quiz';
      case 'discussion':
        return 'forum';
      case 'certificate':
        return 'workspace_premium';
      default:
        return 'check_circle';
    }
  }

  Color _getActivityColor(String type) {
    switch (type) {
      case 'lesson_completed':
        return AppTheme.primaryLight;
      case 'quiz_completed':
        return AppTheme.secondaryLight;
      case 'discussion':
        return AppTheme.accentLight;
      case 'certificate':
        return AppTheme.successLight;
      default:
        return AppTheme.textSecondaryLight;
    }
  }

  Color _getScoreColor(int score) {
    if (score >= 80) return AppTheme.successLight;
    if (score >= 60) return AppTheme.warningLight;
    return AppTheme.errorLight;
  }
}
