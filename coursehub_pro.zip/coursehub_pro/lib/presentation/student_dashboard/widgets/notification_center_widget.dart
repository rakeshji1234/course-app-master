import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class NotificationCenterWidget extends StatelessWidget {
  final List<Map<String, dynamic>> notifications;

  const NotificationCenterWidget({
    Key? key,
    required this.notifications,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final unreadCount =
        notifications.where((n) => !(n['isRead'] as bool)).length;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  CustomIconWidget(
                    iconName: 'notifications',
                    color: AppTheme.primaryLight,
                    size: 20,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Notifications',
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              if (unreadCount > 0)
                Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                  decoration: BoxDecoration(
                    color: AppTheme.errorLight,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '$unreadCount new',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
            ],
          ),
          SizedBox(height: 2.h),
          notifications.isEmpty
              ? Container(
                  padding: EdgeInsets.symmetric(vertical: 3.h),
                  child: Center(
                    child: Column(
                      children: [
                        CustomIconWidget(
                          iconName: 'notifications_none',
                          color: AppTheme.textDisabledLight,
                          size: 32,
                        ),
                        SizedBox(height: 1.h),
                        Text(
                          'No notifications',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: AppTheme.textSecondaryLight,
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : Column(
                  children: notifications.take(4).map((notification) {
                    final isRead = notification['isRead'] as bool;
                    final type = notification['type'] as String;

                    return Container(
                      margin: EdgeInsets.only(bottom: 2.h),
                      padding: EdgeInsets.all(3.w),
                      decoration: BoxDecoration(
                        color: isRead
                            ? AppTheme.backgroundLight
                            : AppTheme.primaryLight.withValues(alpha: 0.05),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: isRead
                              ? AppTheme.dividerLight
                              : AppTheme.primaryLight.withValues(alpha: 0.2),
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: EdgeInsets.all(2.w),
                            decoration: BoxDecoration(
                              color: _getNotificationColor(type)
                                  .withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: CustomIconWidget(
                              iconName: _getNotificationIcon(type),
                              color: _getNotificationColor(type),
                              size: 16,
                            ),
                          ),
                          SizedBox(width: 3.w),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  notification['title'] as String,
                                  style: AppTheme
                                      .lightTheme.textTheme.bodyMedium
                                      ?.copyWith(
                                    fontWeight: isRead
                                        ? FontWeight.w500
                                        : FontWeight.w600,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                SizedBox(height: 0.5.h),
                                Text(
                                  notification['message'] as String,
                                  style: AppTheme.lightTheme.textTheme.bodySmall
                                      ?.copyWith(
                                    color: AppTheme.textSecondaryLight,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                SizedBox(height: 0.5.h),
                                Text(
                                  notification['timestamp'] as String,
                                  style: AppTheme.lightTheme.textTheme.bodySmall
                                      ?.copyWith(
                                    color: AppTheme.textDisabledLight,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          if (!isRead)
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: AppTheme.primaryLight,
                                shape: BoxShape.circle,
                              ),
                            ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
          if (notifications.length > 4)
            Center(
              child: TextButton(
                onPressed: () {
                  // Handle view all notifications
                },
                child: Text(
                  'View All Notifications',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.primaryLight,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  String _getNotificationIcon(String type) {
    switch (type) {
      case 'course_update':
        return 'update';
      case 'quiz_reminder':
        return 'quiz';
      case 'certificate':
        return 'workspace_premium';
      case 'system':
        return 'info';
      case 'payment':
        return 'payment';
      default:
        return 'notifications';
    }
  }

  Color _getNotificationColor(String type) {
    switch (type) {
      case 'course_update':
        return AppTheme.primaryLight;
      case 'quiz_reminder':
        return AppTheme.warningLight;
      case 'certificate':
        return AppTheme.successLight;
      case 'system':
        return AppTheme.secondaryLight;
      case 'payment':
        return AppTheme.accentLight;
      default:
        return AppTheme.textSecondaryLight;
    }
  }
}
