import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class UpcomingDeadlinesWidget extends StatelessWidget {
  final List<Map<String, dynamic>> deadlines;

  const UpcomingDeadlinesWidget({
    Key? key,
    required this.deadlines,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'schedule',
                color: AppTheme.warningLight,
                size: 20,
              ),
              SizedBox(width: 2.w),
              Text(
                'Upcoming Deadlines',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          deadlines.isEmpty
              ? Container(
                  padding: EdgeInsets.symmetric(vertical: 3.h),
                  child: Center(
                    child: Column(
                      children: [
                        CustomIconWidget(
                          iconName: 'check_circle_outline',
                          color: AppTheme.successLight,
                          size: 32,
                        ),
                        SizedBox(height: 1.h),
                        Text(
                          'All caught up!',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: AppTheme.textSecondaryLight,
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : Column(
                  children: deadlines.take(3).map((deadline) {
                    final priority = deadline['priority'] as String;
                    final isUrgent = priority == 'high';

                    return Container(
                      margin: EdgeInsets.only(bottom: 2.h),
                      padding: EdgeInsets.all(3.w),
                      decoration: BoxDecoration(
                        color: isUrgent
                            ? AppTheme.errorLight.withValues(alpha: 0.1)
                            : AppTheme.backgroundLight,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: isUrgent
                              ? AppTheme.errorLight.withValues(alpha: 0.3)
                              : AppTheme.dividerLight,
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: EdgeInsets.all(2.w),
                            decoration: BoxDecoration(
                              color: isUrgent
                                  ? AppTheme.errorLight
                                  : AppTheme.primaryLight,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: CustomIconWidget(
                              iconName: deadline['type'] == 'quiz'
                                  ? 'quiz'
                                  : 'assignment',
                              color: Colors.white,
                              size: 16,
                            ),
                          ),
                          SizedBox(width: 3.w),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  deadline['title'] as String,
                                  style: AppTheme
                                      .lightTheme.textTheme.bodyMedium
                                      ?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                SizedBox(height: 0.5.h),
                                Text(
                                  deadline['course'] as String,
                                  style: AppTheme.lightTheme.textTheme.bodySmall
                                      ?.copyWith(
                                    color: AppTheme.textSecondaryLight,
                                  ),
                                ),
                                SizedBox(height: 0.5.h),
                                Row(
                                  children: [
                                    CustomIconWidget(
                                      iconName: 'access_time',
                                      color: isUrgent
                                          ? AppTheme.errorLight
                                          : AppTheme.textSecondaryLight,
                                      size: 12,
                                    ),
                                    SizedBox(width: 1.w),
                                    Text(
                                      deadline['dueDate'] as String,
                                      style: AppTheme
                                          .lightTheme.textTheme.bodySmall
                                          ?.copyWith(
                                        color: isUrgent
                                            ? AppTheme.errorLight
                                            : AppTheme.textSecondaryLight,
                                        fontWeight: isUrgent
                                            ? FontWeight.w600
                                            : FontWeight.w400,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          if (isUrgent)
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 2.w, vertical: 0.5.h),
                              decoration: BoxDecoration(
                                color: AppTheme.errorLight,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                'URGENT',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 8.sp,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                        ],
                      ),
                    );
                  }).toList(),
                ),
        ],
      ),
    );
  }
}
