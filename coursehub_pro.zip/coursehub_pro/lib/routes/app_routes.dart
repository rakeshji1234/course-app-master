import 'package:flutter/material.dart';
import '../presentation/login/login.dart';
import '../presentation/course_details/course_details.dart';
import '../presentation/student_dashboard/student_dashboard.dart';
import '../presentation/video_player/video_player.dart';
import '../presentation/device_management/device_management.dart';
import '../presentation/course_catalog/course_catalog.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String login = '/login';
  static const String courseDetails = '/course-details';
  static const String studentDashboard = '/student-dashboard';
  static const String videoPlayer = '/video-player';
  static const String deviceManagement = '/device-management';
  static const String courseCatalog = '/course-catalog';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const Login(),
    login: (context) => const Login(),
    courseDetails: (context) => const CourseDetails(),
    studentDashboard: (context) => const StudentDashboard(),
    videoPlayer: (context) => const VideoPlayer(),
    deviceManagement: (context) => const DeviceManagement(),
    courseCatalog: (context) => const CourseCatalog(),
    // TODO: Add your other routes here
  };
}
